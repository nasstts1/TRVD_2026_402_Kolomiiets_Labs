import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import swaggerUi from "swagger-ui-express";
import { swaggerSpec } from "./swagger";
import prisma from "./lib/prisma";

import authRoutes from "./routes/auth";
import doctorRoutes from "./routes/doctors";
import appointmentRoutes from "./routes/appointments";
import symptomRoutes from "./routes/symptoms";
import adminRoutes from "./routes/admin";
import userRoutes from "./routes/users";
import reviewRoutes from "./routes/reviews";
import { startReminderJob } from "./jobs/reminderJob";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

app.use((req, res, next) => {
  console.log(`>>> ${req.method} ${req.path}`, req.body);
  next();
});

// маршрути
app.use("/api/auth", authRoutes);
app.use("/api/doctors", doctorRoutes);
app.use("/api/appointments", appointmentRoutes);
app.use("/api/symptoms", symptomRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/users", userRoutes);
app.use("/api/reviews", reviewRoutes);
app.get("/api/specializations", async (req, res) => {
  try {
    const specializations = await prisma.specialization.findMany();
    res.json(specializations);
  } catch (error: unknown) {
    if (error instanceof Error) {
      res.status(500).json({ message: error.message });
    }
  }
});
app.use("/api/docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));

app.get("/api/services/categories", async (req, res) => {
  try {
    const categories = await prisma.serviceCategory.findMany({
      include: {
        services: {
          take: 3,
          select: {
            id: true,
            name: true,
            price: true,
            duration: true,
          },
        },
      },
    });
    res.json(categories);
  } catch (error: unknown) {
    if (error instanceof Error) res.status(500).json({ message: error.message });
  }
});


app.get("/api/services/categories/:id/services", async (req, res) => {
  try {
    const services = await prisma.service.findMany({
      where: { categoryId: Number(req.params.id) },
      include: {
        category: true,
        specialization: true,
      },
    });
    res.json(services);
  } catch (error: unknown) {
    if (error instanceof Error) res.status(500).json({ message: error.message });
  }
});

app.get("/", (req, res) => {
  res.json({ message: "Clinic API працює!" });
});

app.listen(PORT, () => {
  console.log(`Сервер запущено на порті ${PORT}`);
}).on('error', (err) => {
  console.error('SERVER ERROR:', err);
});

startReminderJob();

app.get("/api/quiz/symptoms", async (req, res) => {
  try {
    const symptoms = await prisma.symptom.findMany({
      include: {
        questions: {
          include: {
            options: true,
          },
          orderBy: { order: "asc" },
        },
      },
    });
    res.json(symptoms);
  } catch (error: unknown) {
    if (error instanceof Error) res.status(500).json({ message: error.message });
  }
});

app.post("/api/quiz/recommend", async (req, res) => {
  try {
    const { selectedOptionIds }: { selectedOptionIds: number[] } = req.body;

    const weights = await prisma.recommendationWeight.findMany({
      where: { optionId: { in: selectedOptionIds } },
      include: { specialization: true },
    });

    const scores: Record<number, { name: string; score: number; id: number }> = {};
    weights.forEach((w) => {
      if (!scores[w.specializationId]) {
        scores[w.specializationId] = {
          id: w.specializationId,
          name: w.specialization.name,
          score: 0,
        };
      }
      scores[w.specializationId].score += w.weight;
    });

    const result = Object.values(scores)
      .sort((a, b) => b.score - a.score)
      .slice(0, 3);

    const doctors = await prisma.doctor.findMany({
      where: {
        specializationId: { in: result.map((r) => r.id) },
      },
      include: { specialization: true },
      take: 6,
    });

    res.json({ specializations: result, doctors });
  } catch (error: unknown) {
    if (error instanceof Error) res.status(500).json({ message: error.message });
  }
});