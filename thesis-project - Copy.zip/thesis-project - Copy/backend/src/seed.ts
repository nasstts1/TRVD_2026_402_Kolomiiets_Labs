import prisma from "./lib/prisma";

async function main() {
  // 1. Симптоми
  const headache = await prisma.symptom.create({
    data: { name: "Головний біль", description: "Біль або дискомфорт у ділянці голови" },
  });

  const heartPain = await prisma.symptom.create({
    data: { name: "Біль у серці", description: "Болі, тиск або дискомфорт у грудях" },
  });

  const skinProblems = await prisma.symptom.create({
    data: { name: "Проблеми зі шкірою", description: "Висипання, свербіж, зміна кольору шкіри" },
  });

  const stomachPain = await prisma.symptom.create({
    data: { name: "Болі в животі", description: "Болі, спазми або дискомфорт у животі" },
  });

  const gynProblems = await prisma.symptom.create({
    data: { name: "Гінекологічні проблеми", description: "Порушення циклу, болі внизу живота" },
  });

  const visionProblems = await prisma.symptom.create({
    data: { name: "Проблеми із зором", description: "Зниження гостроти, біль в очах" },
  });

  const jointPain = await prisma.symptom.create({
    data: { name: "Болі в суглобах", description: "Біль, набряк або скутість суглобів" },
  });

  const throatEar = await prisma.symptom.create({
    data: { name: "Горло та вуха", description: "Біль у горлі, закладеність вух" },
  });

  // 2. Знаходимо спеціалізації
  const therapist = await prisma.specialization.findFirst({ where: { name: { contains: "Терапевт" } } });
  const cardiologist = await prisma.specialization.findFirst({ where: { name: { contains: "Кардіолог" } } });
  const neurologist = await prisma.specialization.findFirst({ where: { name: { contains: "Невролог" } } });
  const dermatologist = await prisma.specialization.findFirst({ where: { name: { contains: "Дерматолог" } } });
  const gastroenterologist = await prisma.specialization.findFirst({ where: { name: { contains: "Гастроентеролог" } } });
  const gynecologist = await prisma.specialization.findFirst({ where: { name: { contains: "Гінеколог" } } });
  const ophthalmologist = await prisma.specialization.findFirst({ where: { name: { contains: "Офтальмолог" } } });
  const orthopedist = await prisma.specialization.findFirst({ where: { name: { contains: "Ортопед" } } });
  const ent = await prisma.specialization.findFirst({ where: { name: { contains: "ЛОР" } } });

  // 3. Питання та варіанти для ГОЛОВНОГО БОЛЮ
  const q1 = await prisma.symptomQuestion.create({
    data: {
      symptomId: headache.id,
      question: "Де саме болить голова?",
      type: "SINGLE",
      order: 1,
      options: {
        create: [
          { text: "Лоб і скроні", order: 1 },
          { text: "Потилиця", order: 2 },
          { text: "Вся голова", order: 3 },
          { text: "Одна сторона", order: 4 },
        ],
      },
    },
    include: { options: true },
  });

  const q2 = await prisma.symptomQuestion.create({
    data: {
      symptomId: headache.id,
      question: "Як давно турбує біль?",
      type: "SINGLE",
      order: 2,
      options: {
        create: [
          { text: "Вперше сьогодні", order: 1 },
          { text: "Кілька днів", order: 2 },
          { text: "Більше тижня", order: 3 },
          { text: "Постійно турбує", order: 4 },
        ],
      },
    },
    include: { options: true },
  });

  const q3 = await prisma.symptomQuestion.create({
    data: {
      symptomId: headache.id,
      question: "Які додаткові симптоми є?",
      type: "MULTIPLE",
      order: 3,
      options: {
        create: [
          { text: "Нудота або блювання", order: 1 },
          { text: "Запаморочення", order: 2 },
          { text: "Підвищена температура", order: 3 },
          { text: "Світлочутливість", order: 4 },
          { text: "Оніміння кінцівок", order: 5 },
          { text: "Порушення зору", order: 6 },
        ],
      },
    },
    include: { options: true },
  });

  // 4. Ваги для головного болю
  if (neurologist) {
    await prisma.recommendationWeight.createMany({
      data: [
        { optionId: q1.options[0].id, specializationId: neurologist.id, weight: 3 },
        { optionId: q1.options[1].id, specializationId: neurologist.id, weight: 3 },
        { optionId: q1.options[2].id, specializationId: neurologist.id, weight: 2 },
        { optionId: q1.options[3].id, specializationId: neurologist.id, weight: 3 },
        { optionId: q3.options[0].id, specializationId: neurologist.id, weight: 2 },
        { optionId: q3.options[3].id, specializationId: neurologist.id, weight: 3 },
        { optionId: q3.options[4].id, specializationId: neurologist.id, weight: 3 },
      ],
    });
  }
  if (therapist) {
    await prisma.recommendationWeight.createMany({
      data: [
        { optionId: q1.options[2].id, specializationId: therapist.id, weight: 1 },
        { optionId: q3.options[2].id, specializationId: therapist.id, weight: 2 },
      ],
    });
  }
  if (ophthalmologist) {
    await prisma.recommendationWeight.createMany({
      data: [
        { optionId: q3.options[5].id, specializationId: ophthalmologist.id, weight: 3 },
      ],
    });
  }

  // 5. Питання для БОЛЮ В СЕРЦІ
  const q4 = await prisma.symptomQuestion.create({
    data: {
      symptomId: heartPain.id,
      question: "Де локалізується біль?",
      type: "SINGLE",
      order: 1,
      options: {
        create: [
          { text: "За грудиною", order: 1 },
          { text: "Ліва половина грудей", order: 2 },
          { text: "Віддає в руку або щелепу", order: 3 },
          { text: "По всіх грудях", order: 4 },
        ],
      },
    },
    include: { options: true },
  });

  const q5 = await prisma.symptomQuestion.create({
    data: {
      symptomId: heartPain.id,
      question: "Коли виникає біль?",
      type: "SINGLE",
      order: 2,
      options: {
        create: [
          { text: "У спокої", order: 1 },
          { text: "При фізичному навантаженні", order: 2 },
          { text: "При стресі", order: 3 },
          { text: "Вночі", order: 4 },
        ],
      },
    },
    include: { options: true },
  });

  const q6 = await prisma.symptomQuestion.create({
    data: {
      symptomId: heartPain.id,
      question: "Які супутні симптоми?",
      type: "MULTIPLE",
      order: 3,
      options: {
        create: [
          { text: "Задишка", order: 1 },
          { text: "Серцебиття", order: 2 },
          { text: "Набряки ніг", order: 3 },
          { text: "Запаморочення", order: 4 },
          { text: "Слабкість", order: 5 },
        ],
      },
    },
    include: { options: true },
  });

  if (cardiologist) {
    await prisma.recommendationWeight.createMany({
      data: [
        { optionId: q4.options[0].id, specializationId: cardiologist.id, weight: 3 },
        { optionId: q4.options[1].id, specializationId: cardiologist.id, weight: 3 },
        { optionId: q4.options[2].id, specializationId: cardiologist.id, weight: 3 },
        { optionId: q4.options[3].id, specializationId: cardiologist.id, weight: 2 },
        { optionId: q6.options[0].id, specializationId: cardiologist.id, weight: 2 },
        { optionId: q6.options[1].id, specializationId: cardiologist.id, weight: 3 },
        { optionId: q6.options[2].id, specializationId: cardiologist.id, weight: 2 },
      ],
    });
  }

  // 6. Питання для ШКІРИ
  const q7 = await prisma.symptomQuestion.create({
    data: {
      symptomId: skinProblems.id,
      question: "Де розташоване ураження?",
      type: "SINGLE",
      order: 1,
      options: {
        create: [
          { text: "Обличчя", order: 1 },
          { text: "Тіло", order: 2 },
          { text: "Кінцівки", order: 3 },
          { text: "Волосиста частина голови", order: 4 },
        ],
      },
    },
    include: { options: true },
  });

  const q8 = await prisma.symptomQuestion.create({
    data: {
      symptomId: skinProblems.id,
      question: "Як виглядає ураження?",
      type: "SINGLE",
      order: 2,
      options: {
        create: [
          { text: "Почервоніння", order: 1 },
          { text: "Висипання або прищі", order: 2 },
          { text: "Лущення", order: 3 },
          { text: "Пігментні плями", order: 4 },
          { text: "Виразки або рани", order: 5 },
        ],
      },
    },
    include: { options: true },
  });

  if (dermatologist) {
    await prisma.recommendationWeight.createMany({
      data: q7.options.map((o) => ({
        optionId: o.id,
        specializationId: dermatologist.id,
        weight: 3,
      })).concat(q8.options.map((o) => ({
        optionId: o.id,
        specializationId: dermatologist.id,
        weight: 3,
      }))),
    });
  }

  // 7. Питання для БОЛЮ В ЖИВОТІ
  const q9 = await prisma.symptomQuestion.create({
    data: {
      symptomId: stomachPain.id,
      question: "Де локалізується біль?",
      type: "SINGLE",
      order: 1,
      options: {
        create: [
          { text: "Верхня частина (під ребрами)", order: 1 },
          { text: "Навколо пупка", order: 2 },
          { text: "Нижня частина живота", order: 3 },
          { text: "Права сторона", order: 4 },
          { text: "Ліва сторона", order: 5 },
        ],
      },
    },
    include: { options: true },
  });

  const q10 = await prisma.symptomQuestion.create({
    data: {
      symptomId: stomachPain.id,
      question: "Коли виникає біль?",
      type: "SINGLE",
      order: 2,
      options: {
        create: [
          { text: "Після їжі", order: 1 },
          { text: "Натщесерце", order: 2 },
          { text: "Постійно", order: 3 },
          { text: "Нападами", order: 4 },
        ],
      },
    },
    include: { options: true },
  });

  const q11 = await prisma.symptomQuestion.create({
    data: {
      symptomId: stomachPain.id,
      question: "Які супутні симптоми?",
      type: "MULTIPLE",
      order: 3,
      options: {
        create: [
          { text: "Нудота або блювання", order: 1 },
          { text: "Діарея або запор", order: 2 },
          { text: "Здуття", order: 3 },
          { text: "Підвищена температура", order: 4 },
          { text: "Втрата апетиту", order: 5 },
        ],
      },
    },
    include: { options: true },
  });

  if (gastroenterologist) {
    await prisma.recommendationWeight.createMany({
      data: [
        { optionId: q9.options[0].id, specializationId: gastroenterologist.id, weight: 3 },
        { optionId: q9.options[1].id, specializationId: gastroenterologist.id, weight: 3 },
        { optionId: q9.options[3].id, specializationId: gastroenterologist.id, weight: 2 },
        { optionId: q10.options[0].id, specializationId: gastroenterologist.id, weight: 3 },
        { optionId: q10.options[1].id, specializationId: gastroenterologist.id, weight: 3 },
        { optionId: q11.options[1].id, specializationId: gastroenterologist.id, weight: 3 },
        { optionId: q11.options[2].id, specializationId: gastroenterologist.id, weight: 2 },
      ],
    });
  }
  if (gynecologist) {
    await prisma.recommendationWeight.createMany({
      data: [
        { optionId: q9.options[2].id, specializationId: gynecologist.id, weight: 2 },
      ],
    });
  }

  // 8. Питання для ГІНЕКОЛОГІЇ
  const q12 = await prisma.symptomQuestion.create({
    data: {
      symptomId: gynProblems.id,
      question: "Що саме турбує?",
      type: "SINGLE",
      order: 1,
      options: {
        create: [
          { text: "Порушення менструального циклу", order: 1 },
          { text: "Болі внизу живота", order: 2 },
          { text: "Незвичні виділення", order: 3 },
          { text: "Планування вагітності", order: 4 },
        ],
      },
    },
    include: { options: true },
  });

  if (gynecologist) {
    await prisma.recommendationWeight.createMany({
      data: q12.options.map((o) => ({
        optionId: o.id,
        specializationId: gynecologist.id,
        weight: 3,
      })),
    });
  }

  // 9. Питання для ЗОРУ
  const q13 = await prisma.symptomQuestion.create({
    data: {
      symptomId: visionProblems.id,
      question: "Що саме турбує?",
      type: "SINGLE",
      order: 1,
      options: {
        create: [
          { text: "Погіршення гостроти зору", order: 1 },
          { text: "Біль або різь в очах", order: 2 },
          { text: "Почервоніння очей", order: 3 },
          { text: "Мухи або спалахи перед очима", order: 4 },
        ],
      },
    },
    include: { options: true },
  });

  if (ophthalmologist) {
    await prisma.recommendationWeight.createMany({
      data: q13.options.map((o) => ({
        optionId: o.id,
        specializationId: ophthalmologist.id,
        weight: 3,
      })),
    });
  }

  // 10. Питання для СУГЛОБІВ
  const q14 = await prisma.symptomQuestion.create({
    data: {
      symptomId: jointPain.id,
      question: "Який суглоб турбує?",
      type: "SINGLE",
      order: 1,
      options: {
        create: [
          { text: "Коліно", order: 1 },
          { text: "Тазостегновий суглоб", order: 2 },
          { text: "Плечовий суглоб", order: 3 },
          { text: "Дрібні суглоби рук", order: 4 },
          { text: "Хребет", order: 5 },
        ],
      },
    },
    include: { options: true },
  });

  if (orthopedist) {
    await prisma.recommendationWeight.createMany({
      data: q14.options.map((o) => ({
        optionId: o.id,
        specializationId: orthopedist.id,
        weight: 3,
      })),
    });
  }

  // 11. Питання для ГОРЛА ТА ВУШЕЙ
  const q15 = await prisma.symptomQuestion.create({
    data: {
      symptomId: throatEar.id,
      question: "Що саме турбує?",
      type: "SINGLE",
      order: 1,
      options: {
        create: [
          { text: "Біль у горлі", order: 1 },
          { text: "Закладеність або біль у вухах", order: 2 },
          { text: "Закладеність носа", order: 3 },
          { text: "Охриплість голосу", order: 4 },
        ],
      },
    },
    include: { options: true },
  });

  if (ent) {
    await prisma.recommendationWeight.createMany({
      data: q15.options.map((o) => ({
        optionId: o.id,
        specializationId: ent.id,
        weight: 3,
      })),
    });
  }

  console.log("✅ Дані успішно додано!");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });   