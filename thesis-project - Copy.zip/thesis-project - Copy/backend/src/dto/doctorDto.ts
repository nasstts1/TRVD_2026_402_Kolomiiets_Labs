export interface DoctorEducationDTO {
  id: number;
  type: "EDUCATION" | "TRAINING";
  institution: string;
  degree: string | null;
  year: number | null;
  order: number;
}

export interface DoctorDTO {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone: string | null;
  photoUrl: string | null;
  workDays: number[];
  breakStart: string;
  breakEnd: string;
  experience: number | null;
  bio: string | null;
  category: string | null;
  specialization: {
    id: number;
    name: string;
  };
  education: DoctorEducationDTO[];
  reviews: {
    id: number;
    rating: number;
    comment: string;
    createdAt: Date;
    isVisible: boolean;
    user: { firstName: string; lastName: string };
  }[];
}

export const toDoctorDTO = (doctor: any): DoctorDTO => ({
  id: doctor.id,
  firstName: doctor.firstName,
  lastName: doctor.lastName,
  email: doctor.email,
  phone: doctor.phone,
  photoUrl: doctor.photoUrl ?? null,
  workDays: doctor.workDays,
  breakStart: doctor.breakStart,
  breakEnd: doctor.breakEnd,
  experience: doctor.experience ?? null,
  bio: doctor.bio ?? null,
  category: doctor.category ?? null,
  specialization: {
    id: doctor.specialization.id,
    name: doctor.specialization.name,
  },
  education: (doctor.education ?? []).map((e: any) => ({
    id: e.id,
    type: e.type,
    institution: e.institution,
    degree: e.degree ?? null,
    year: e.year ?? null,
    order: e.order,
  })),
  reviews: (doctor.reviews ?? []).map((r: any) => ({
    id: r.id,
    rating: r.rating,
    comment: r.comment,
    createdAt: r.createdAt,
    isVisible: r.isVisible,
    user: {
      firstName: r.user.firstName,
      lastName: r.user.lastName,
    },
  })),
});