import prisma from "../lib/prisma";

export const getAllDoctors = () => {
  return prisma.doctor.findMany({
    include: {
      specialization: true,
      education: { orderBy: { order: "asc" } },
      reviews: {
        where: { isVisible: true },
        include: { user: { select: { firstName: true, lastName: true } } },
      },
    },
  });
};

export const getDoctorById = (id: number) => {
  return prisma.doctor.findUnique({
    where: { id },
    include: {
      specialization: true,
      symptoms: { include: { symptom: true } },
      education: { orderBy: { order: "asc" } },
      reviews: {
        include: { user: { select: { firstName: true, lastName: true } } },
        orderBy: { createdAt: "desc" },
      },
    },
  });
};

export const createDoctor = (data: {
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  specializationId: number;
}) => {
  return prisma.doctor.create({
    data,
    include: {
      specialization: true,
      education: true,
      reviews: true,
    },
  });
};

export const getDoctorsBySpecialization = (specializationId: number) => {
  return prisma.doctor.findMany({
    where: { specializationId },
    include: {
      specialization: true,
      education: { orderBy: { order: "asc" } },
      reviews: {
        where: { isVisible: true },
        include: { user: { select: { firstName: true, lastName: true } } },
      },
    },
  });
};