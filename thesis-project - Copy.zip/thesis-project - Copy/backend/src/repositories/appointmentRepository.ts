import prisma from "../lib/prisma";
import { Status } from "@prisma/client";

export const createAppointment = async (data: {
  userId?: number | null;
  doctorId: number;
  appointmentDate: Date;
  notes?: string | null;
  guestName?: string | null;
  guestPhone?: string | null;
}) => {
  try {
    // Перевірка чи слот вже зайнятий
    const existing = await prisma.appointment.findFirst({
      where: {
        doctorId: data.doctorId,
        appointmentDate: new Date(data.appointmentDate),
        status: { not: "CANCELLED" },
      },
    });

    if (existing) {
      throw new Error("Цей час вже зайнятий");
    }

    return await prisma.appointment.create({
      data: {
        userId: data.userId ?? null,
        doctorId: data.doctorId,
        appointmentDate: data.appointmentDate,
        notes: data.notes,
        guestName: data.guestName ?? null,
        guestPhone: data.guestPhone ?? null,
      },
      include: {
        doctor: { include: { specialization: true } },
        user: true,
      },
    });
  } catch (error) {
    console.error("PRISMA ERROR:", error);
    throw error;
  }
};

export const getAppointmentsByUser = (userId: number) => {  
  return prisma.appointment.findMany({
    where: { userId },
    include: {
      doctor: { include: { specialization: true } },
      review: true,
    },
    orderBy: { appointmentDate: "asc" },
  });
};

export const getAppointmentsByDoctor = (doctorId: number) => {
  return prisma.appointment.findMany({
    where: { doctorId },
    include: { user: true },
    orderBy: { appointmentDate: "asc" },
  });
};

export const updateAppointmentStatus = (id: number, status: Status) => {
  return prisma.appointment.update({
    where: { id },
    data: { status },
  });
};

export const getAppointmentById = (id: number) => {
  return prisma.appointment.findUnique({
    where: { id },
    include: {
      doctor: { include: { specialization: true } },
      user: true,
    },
  });
};