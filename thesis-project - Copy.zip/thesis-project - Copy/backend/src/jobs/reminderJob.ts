import cron from "node-cron";
import prisma from "../lib/prisma";
import { sendAppointmentReminder } from "../services/emailService";

export const startReminderJob = () => {
  // Запускається щодня о 10:00
  cron.schedule("0 10 * * *", async () => {
    console.log("Перевірка нагадувань...");

    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);

    const dayAfterTomorrow = new Date(tomorrow);
    dayAfterTomorrow.setDate(dayAfterTomorrow.getDate() + 1);

    try {
      const appointments = await prisma.appointment.findMany({
        where: {
          appointmentDate: { gte: tomorrow, lt: dayAfterTomorrow },
          status: { not: "CANCELLED" },
          user: { isNot: null }, // тільки зареєстровані користувачі
        },
        include: {
          user: true,
          doctor: { include: { specialization: true } },
        },
      });

      for (const appointment of appointments) {
        if (!appointment.user?.email) continue;

        const date = new Date(appointment.appointmentDate).toLocaleDateString("uk-UA");
        const time = new Date(appointment.appointmentDate).toLocaleTimeString("uk-UA", {
          hour: "2-digit",
          minute: "2-digit",
        });

        try {
          await sendAppointmentReminder({
            to: appointment.user.email,
            patientName: `${appointment.user.firstName} ${appointment.user.lastName}`,
            doctorName: `${appointment.doctor.firstName} ${appointment.doctor.lastName}`,
            specialization: appointment.doctor.specialization.name,
            date,
            time,
          });
          console.log(`Нагадування надіслано: ${appointment.user.email}`);
        } catch (err) {
          console.error(`Помилка нагадування для ${appointment.user.email}:`, err);
        }
      }
    } catch (err) {
      console.error("Помилка cron job:", err);
    }
  });

  console.log("Cron job для нагадувань запущено");
};