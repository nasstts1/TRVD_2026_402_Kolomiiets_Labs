import nodemailer from "nodemailer";

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

// Підтвердження запису
export const sendAppointmentConfirmation = async (data: {
  to: string;
  patientName: string;
  doctorName: string;
  specialization: string;
  date: string;
  time: string;
}) => {
  await transporter.sendMail({
    from: `"Клініка" <${process.env.EMAIL_USER}>`,
    to: data.to,
    subject: "Підтвердження запису на прийом",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #2563eb; padding: 24px; border-radius: 12px 12px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">Запис підтверджено ✓</h1>
        </div>
        <div style="background: #f9fafb; padding: 24px; border-radius: 0 0 12px 12px;">
          <p style="color: #374151;">Шановний(а) <strong>${data.patientName}</strong>,</p>
          <p style="color: #374151;">Ваш запис успішно створено. Деталі прийому:</p>
          
          <div style="background: white; border-radius: 8px; padding: 16px; margin: 16px 0; border: 1px solid #e5e7eb;">
            <p style="margin: 8px 0; color: #374151;">👨‍⚕️ <strong>Лікар:</strong> ${data.doctorName}</p>
            <p style="margin: 8px 0; color: #374151;">🏥 <strong>Спеціалізація:</strong> ${data.specialization}</p>
            <p style="margin: 8px 0; color: #374151;">📅 <strong>Дата:</strong> ${data.date}</p>
            <p style="margin: 8px 0; color: #374151;">🕐 <strong>Час:</strong> ${data.time}</p>
          </div>

          <a href="${process.env.FRONTEND_URL}/appointments" 
             style="display: inline-block; background: #2563eb; color: white; padding: 12px 24px; border-radius: 8px; text-decoration: none; margin-top: 8px;">
            Переглянути мої записи
          </a>

          <p style="color: #9ca3af; font-size: 12px; margin-top: 24px;">
            Якщо у вас виникли питання, зв'яжіться з нами.
          </p>
        </div>
      </div>
    `,
  });
};

// Нагадування за день до прийому
export const sendAppointmentReminder = async (data: {
  to: string;
  patientName: string;
  doctorName: string;
  specialization: string;
  date: string;
  time: string;
}) => {
  await transporter.sendMail({
    from: `"Клініка" <${process.env.EMAIL_USER}>`,
    to: data.to,
    subject: "Нагадування про прийом завтра",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #f59e0b; padding: 24px; border-radius: 12px 12px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">Нагадування 🔔</h1>
        </div>
        <div style="background: #f9fafb; padding: 24px; border-radius: 0 0 12px 12px;">
          <p style="color: #374151;">Шановний(а) <strong>${data.patientName}</strong>,</p>
          <p style="color: #374151;">Нагадуємо що завтра у вас запланований прийом:</p>
          
          <div style="background: white; border-radius: 8px; padding: 16px; margin: 16px 0; border: 1px solid #e5e7eb;">
            <p style="margin: 8px 0; color: #374151;">👨‍⚕️ <strong>Лікар:</strong> ${data.doctorName}</p>
            <p style="margin: 8px 0; color: #374151;">🏥 <strong>Спеціалізація:</strong> ${data.specialization}</p>
            <p style="margin: 8px 0; color: #374151;">📅 <strong>Дата:</strong> ${data.date}</p>
            <p style="margin: 8px 0; color: #374151;">🕐 <strong>Час:</strong> ${data.time}</p>
          </div>

          <p style="color: #374151;">Будь ласка, приходьте вчасно. У разі неможливості відвідати прийом — скасуйте запис заздалегідь.</p>

          <a href="${process.env.FRONTEND_URL}/appointments"
             style="display: inline-block; background: #f59e0b; color: white; padding: 12px 24px; border-radius: 8px; text-decoration: none; margin-top: 8px;">
            Переглянути мої записи
          </a>
        </div>
      </div>
    `,
  });
};

// Скасування адміном
export const sendCancellationByAdmin = async (data: {
  to: string;
  patientName: string;
  doctorName: string;
  specialization: string;
  date: string;
  time: string;
  reason: string;
}) => {
  await transporter.sendMail({
    from: `"Клініка" <${process.env.EMAIL_USER}>`,
    to: data.to,
    subject: "Ваш запис скасовано",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #ef4444; padding: 24px; border-radius: 12px 12px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">Запис скасовано</h1>
        </div>
        <div style="background: #f9fafb; padding: 24px; border-radius: 0 0 12px 12px;">
          <p style="color: #374151;">Шановний(а) <strong>${data.patientName}</strong>,</p>
          <p style="color: #374151;">На жаль, ваш запис було скасовано адміністратором.</p>
          
          <div style="background: white; border-radius: 8px; padding: 16px; margin: 16px 0; border: 1px solid #e5e7eb;">
            <p style="margin: 8px 0; color: #374151;">👨‍⚕️ <strong>Лікар:</strong> ${data.doctorName}</p>
            <p style="margin: 8px 0; color: #374151;">🏥 <strong>Спеціалізація:</strong> ${data.specialization}</p>
            <p style="margin: 8px 0; color: #374151;">📅 <strong>Дата:</strong> ${data.date}</p>
            <p style="margin: 8px 0; color: #374151;">🕐 <strong>Час:</strong> ${data.time}</p>
            <p style="margin: 8px 0; color: #ef4444;">❗ <strong>Причина:</strong> ${data.reason}</p>
          </div>

          <p style="color: #374151;">Запишіться на інший зручний час:</p>
          <a href="${process.env.FRONTEND_URL}/doctors"
             style="display: inline-block; background: #2563eb; color: white; padding: 12px 24px; border-radius: 8px; text-decoration: none; margin-top: 8px;">
            Записатись знову
          </a>
        </div>
      </div>
    `,
  });
};

// Скасування пацієнтом — сповіщення адміну
export const sendCancellationNotifyAdmin = async (data: {
  adminEmail: string;
  patientName: string;
  doctorName: string;
  date: string;
  time: string;
}) => {
  await transporter.sendMail({
    from: `"Клініка" <${process.env.EMAIL_USER}>`,
    to: data.adminEmail,
    subject: "Пацієнт скасував запис",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #6b7280; padding: 24px; border-radius: 12px 12px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">Запис скасовано пацієнтом</h1>
        </div>
        <div style="background: #f9fafb; padding: 24px; border-radius: 0 0 12px 12px;">
          <div style="background: white; border-radius: 8px; padding: 16px; border: 1px solid #e5e7eb;">
            <p style="margin: 8px 0; color: #374151;">👤 <strong>Пацієнт:</strong> ${data.patientName}</p>
            <p style="margin: 8px 0; color: #374151;">👨‍⚕️ <strong>Лікар:</strong> ${data.doctorName}</p>
            <p style="margin: 8px 0; color: #374151;">📅 <strong>Дата:</strong> ${data.date}</p>
            <p style="margin: 8px 0; color: #374151;">🕐 <strong>Час:</strong> ${data.time}</p>
          </div>
        </div>
      </div>
    `,
  });
};