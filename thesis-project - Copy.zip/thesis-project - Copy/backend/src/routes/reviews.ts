import { Router, Request, Response } from "express";
import { authMiddleware, AuthRequest } from "../middleware/authMiddleware";
import { roleMiddleware } from "../middleware/roleMiddleware";
import prisma from "../lib/prisma";

const router = Router();

// Створити відгук (тільки PATIENT)
router.post(
  "/",
  authMiddleware,
  roleMiddleware("PATIENT"),
  async (req: AuthRequest, res: Response) => {
    try {
      const { appointmentId, rating, comment } = req.body;

      // Перевірка що запис належить цьому користувачу
      const appointment = await prisma.appointment.findFirst({
        where: {
          id: Number(appointmentId),
          userId: req.user!.id,
        },
      });

      if (!appointment) {
        res.status(404).json({ message: "Запис не знайдено" });
        return;
      }

      // Перевірка що запис вже пройшов
      if (new Date(appointment.appointmentDate) > new Date()) {
        res.status(400).json({ message: "Можна залишити відгук лише після прийому" });
        return;
      }

      // Перевірка що відгук ще не залишено
      const existing = await prisma.review.findUnique({
        where: { appointmentId: Number(appointmentId) },
      });

      if (existing) {
        res.status(400).json({ message: "Відгук вже залишено" });
        return;
      }

      const review = await prisma.review.create({
        data: {
          appointmentId: Number(appointmentId),
          userId: req.user!.id,
          doctorId: appointment.doctorId,
          rating: Number(rating),
          comment,
          isVisible: false,
        },
      });

      res.status(201).json(review);
    } catch (error: unknown) {
      if (error instanceof Error) res.status(400).json({ message: error.message });
    }
  }
);

// Отримати видимі відгуки для головної сторінки
router.get("/visible", async (req: Request, res: Response) => {
  try {
    const reviews = await prisma.review.findMany({
      where: { isVisible: true },
      include: {
        user: { select: { firstName: true, lastName: true } },
        doctor: { select: { firstName: true, lastName: true, specialization: { select: { name: true } } } },
      },
      orderBy: { createdAt: "desc" },
    });
    res.json(reviews);
  } catch (error: unknown) {
    if (error instanceof Error) res.status(500).json({ message: error.message });
  }
});

// Отримати всі відгуки (тільки ADMIN)
router.get(
  "/all",
  authMiddleware,
  roleMiddleware("ADMIN"),
  async (req: AuthRequest, res: Response) => {
    try {
      const reviews = await prisma.review.findMany({
        include: {
          user: { select: { firstName: true, lastName: true } },
          doctor: { select: { firstName: true, lastName: true, specialization: { select: { name: true } } } },
        },
        orderBy: { createdAt: "desc" },
      });
      res.json(reviews);
    } catch (error: unknown) {
      if (error instanceof Error) res.status(500).json({ message: error.message });
    }
  }
);

// Змінити видимість відгуку (тільки ADMIN)
router.patch(
  "/:id/visibility",
  authMiddleware,
  roleMiddleware("ADMIN"),
  async (req: AuthRequest, res: Response) => {
    try {
      const review = await prisma.review.update({
        where: { id: Number(req.params.id) },
        data: { isVisible: req.body.isVisible },
      });
      res.json(review);
    } catch (error: unknown) {
      if (error instanceof Error) res.status(400).json({ message: error.message });
    }
  }
);

// Видалити відгук (тільки ADMIN)
router.delete(
  "/:id",
  authMiddleware,
  roleMiddleware("ADMIN"),
  async (req: AuthRequest, res: Response) => {
    try {
      await prisma.review.delete({ where: { id: Number(req.params.id) } });
      res.status(200).json({ message: "Відгук видалено" });
    } catch (error: unknown) {
      if (error instanceof Error) res.status(400).json({ message: error.message });
    }
  }
);

export default router;