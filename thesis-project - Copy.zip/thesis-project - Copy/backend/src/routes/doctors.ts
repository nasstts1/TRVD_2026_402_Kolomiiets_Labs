import { Router, Request, Response } from "express";
import {
  getAllDoctors,
  getDoctorById,
  createDoctor,
} from "../repositories/doctorRepository";
import { authMiddleware } from "../middleware/authMiddleware";
import { roleMiddleware } from "../middleware/roleMiddleware";
import { toDoctorDTO } from "../dto/doctorDto";
import prisma from "../lib/prisma";

const router = Router();

router.get("/", async (req: Request, res: Response) => {
  try {
    const doctors = await getAllDoctors();
    res.json(doctors.map(toDoctorDTO));
  } catch (error: unknown) {
    if (error instanceof Error) {
      res.status(500).json({ message: error.message });
    }
  }
});

router.get("/:id", async (req: Request, res: Response) => {
  try {
    const doctor = await getDoctorById(Number(req.params.id));
    if (!doctor) {
      res.status(404).json({ message: "Лікаря не знайдено" });
      return;
    }
    res.json(toDoctorDTO(doctor));
  } catch (error: unknown) {
    if (error instanceof Error) {
      res.status(500).json({ message: error.message });
    }
  }
});

router.post(
  "/",
  authMiddleware,
  roleMiddleware("ADMIN"),
  async (req: Request, res: Response) => {
    try {
      const doctor = await createDoctor(req.body);
      res.status(201).json(toDoctorDTO(doctor));
    } catch (error: unknown) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      }
    } 
  }
);

router.patch(
  "/:id",
  authMiddleware,
  roleMiddleware("ADMIN"),
  async (req: Request, res: Response) => {
    try {
      const doctor = await getDoctorById(Number(req.params.id));
      if (!doctor) {
        res.status(404).json({ message: "Лікаря не знайдено" });
        return;
      }

      const { education, ...doctorData } = req.body;

      const updated = await prisma.doctor.update({
        where: { id: Number(req.params.id) },
        data: {
          firstName: doctorData.firstName,
          lastName: doctorData.lastName,
          phone: doctorData.phone || null,
          photoUrl: doctorData.photoUrl || null,
          experience: doctorData.experience ? Number(doctorData.experience) : null,
          bio: doctorData.bio || null,
          category: doctorData.category || null,
        },
        include: {
          specialization: true,
          education: { orderBy: { order: "asc" } },
          reviews: {
            include: { user: { select: { firstName: true, lastName: true } } },
          },
        },
      });

      // Оновлюємо освіту — видаляємо старі і створюємо нові
      if (education && Array.isArray(education)) {
        await prisma.doctorEducation.deleteMany({
          where: { doctorId: Number(req.params.id) },
        });
        await prisma.doctorEducation.createMany({
          data: education.map((e: any, index: number) => ({
            doctorId: Number(req.params.id),
            type: e.type,
            institution: e.institution,
            degree: e.degree || null,
            year: e.year ? Number(e.year) : null,
            order: index,
          })),
        });

        // Перезавантажуємо з новою освітою
        const updatedWithEducation = await getDoctorById(Number(req.params.id));
        return res.json(toDoctorDTO(updatedWithEducation));
      }

      res.json(toDoctorDTO(updated));
    } catch (error: unknown) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      }
    }
  }
);

router.delete(
  "/:id",
  authMiddleware,
  roleMiddleware("ADMIN"),
  async (req: Request, res: Response) => {
    try {
      const doctor = await getDoctorById(Number(req.params.id));
      if (!doctor) {
        res.status(404).json({ message: "Лікаря не знайдено" });
        return;
      }

      // Знаходимо email лікаря щоб потім видалити акаунт
      const doctorEmail = doctor.email;

      // Видаляємо лікаря
      await prisma.doctor.delete({ where: { id: Number(req.params.id) } });

      // Видаляємо акаунт користувача з роллю DOCTOR
      await prisma.user.deleteMany({
        where: {
          email: doctorEmail,
          role: "DOCTOR",
        },
      });

      res.status(200).json({ message: "Лікаря видалено" });
    } catch (error: unknown) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      }
    }
  }
);

export default router;