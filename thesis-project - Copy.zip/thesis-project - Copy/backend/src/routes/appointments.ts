  import { Router, Request, Response } from "express";
  import {
    createAppointment,
    getAppointmentsByUser,
    getAppointmentsByDoctor,
    updateAppointmentStatus,
    getAppointmentById,
  } from "../repositories/appointmentRepository";

  import {
    sendCancellationByAdmin,
    sendCancellationNotifyAdmin,
    sendAppointmentConfirmation,
  } from "../services/emailService";

  import { toAppointmentDTO } from "../dto/appointmentDto";
  import { authMiddleware, AuthRequest } from "../middleware/authMiddleware";
  import { roleMiddleware } from "../middleware/roleMiddleware";
  import { Status } from "@prisma/client";
  import prisma from "../lib/prisma";

  const router = Router();

  router.get("/booked", async (req: Request, res: Response) => {
    try {
      const { doctorId, date } = req.query;
      const start = new Date(date as string);
      start.setHours(0, 0, 0, 0);
      const end = new Date(date as string);
      end.setHours(23, 59, 59, 999);

      const appointments = await prisma.appointment.findMany({
        where: {
          doctorId: Number(doctorId),
          appointmentDate: { gte: start, lte: end },
          status: { not: "CANCELLED" },
        },
        select: { appointmentDate: true },
      });

      const booked = appointments.map((a) => {
        const date = new Date(a.appointmentDate);
        const h = String(date.getUTCHours()).padStart(2, "0");
        const m = String(date.getUTCMinutes()).padStart(2, "0");
        return `${h}:${m}`;
      });
      res.json(booked);
    } catch (error: unknown) {
      if (error instanceof Error) res.status(500).json({ message: error.message });
    }
  });

  router.get("/slot", authMiddleware, async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      const { doctorId, date, time } = req.query as {
        doctorId: string; date: string; time: string;
      };

      console.log("SLOT REQUEST:", { doctorId, date, time }); 

      const start = new Date(date);
      start.setHours(0, 0, 0, 0);
      const end = new Date(date);
      end.setHours(23, 59, 59, 999);

      const appointments = await prisma.appointment.findMany({
        where: {
          doctorId: Number(doctorId),
          appointmentDate: { gte: start, lte: end },
          status: { not: "CANCELLED" },
        },
        include: {
          user: {
            select: { id: true, firstName: true, lastName: true, email: true },
          },
        },
      });

    console.log("FOUND APPOINTMENTS:", appointments.length); // додай
    console.log("APPOINTMENTS TIMES:", appointments.map(a => { // додай
      const h = String(a.appointmentDate.getUTCHours()).padStart(2, "0");
      const m = String(a.appointmentDate.getUTCMinutes()).padStart(2, "0");
      return `${h}:${m}`;
    }));

      const appointment = appointments.find((a) => {
        const h = String(a.appointmentDate.getUTCHours()).padStart(2, "0");
        const m = String(a.appointmentDate.getUTCMinutes()).padStart(2, "0");
        return `${h}:${m}` === time;
      });

      if (!appointment) {
        res.status(404).json({ message: "Запис не знайдено" });
        return;
      }
      res.json(appointment);
    } catch (error: unknown) {
      if (error instanceof Error) res.status(500).json({ message: error.message });
    }
  });


router.post(
  "/admin",
  authMiddleware,
  roleMiddleware("ADMIN"),
  async (req: AuthRequest, res: Response) => {
    const { doctorId, serviceId, appointmentDate, notes, guestName, guestPhone, userId } = req.body;

    const appointmentData: any = {
      doctorId: Number(doctorId),
      appointmentDate: new Date(appointmentDate),
      notes: notes || null,
      serviceId: serviceId ? Number(serviceId) : null,
      guestName: guestName || null,
      guestPhone: guestPhone || null,
      userId: userId ? Number(userId) : null,
    };

    try {
      const appointment = await createAppointment(appointmentData);
      res.status(201).json(toAppointmentDTO(appointment));
    } catch (error: unknown) {
      if (error instanceof Error) res.status(400).json({ message: error.message });
    }
  }
);

router.post(
  "/guest",
  async (req: Request, res: Response) => {
    const { doctorId, serviceId, appointmentDate, notes, guestName, guestPhone } = req.body;

    if (!guestName || guestName.trim() === "") {
      return res.status(400).json({ message: "Вкажіть ваше ім'я" });
    }
    if (!guestPhone || guestPhone.trim() === "") {
      return res.status(400).json({ message: "Вкажіть номер телефону" });
    }

    const appointmentData = {
      doctorId: Number(doctorId),
      appointmentDate: new Date(appointmentDate),
      notes: notes || null,
      serviceId: serviceId ? Number(serviceId) : null,
      userId: null,
      guestName: guestName.trim(),
      guestPhone: guestPhone.trim(),
    };

    try {
      const appointment = await createAppointment(appointmentData);
      res.status(201).json(toAppointmentDTO(appointment));
    } catch (error: unknown) {
      if (error instanceof Error) res.status(400).json({ message: error.message });
    }
  }
);

router.post(
  "/",
  authMiddleware,
  roleMiddleware("PATIENT"),
  async (req: AuthRequest, res: Response) => {
    const { doctorId, serviceId, appointmentDate, notes } = req.body;

    const appointmentData = {
      doctorId: Number(doctorId),
      appointmentDate: new Date(appointmentDate),
      notes: notes || null,
      serviceId: serviceId ? Number(serviceId) : null,
      userId: req.user!.id,
      guestName: null,
      guestPhone: null,
    };

    try {
      const appointment = await createAppointment(appointmentData);

      // Відправляємо лист підтвердження
      try {
        const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
        if (user?.email) {
          await sendAppointmentConfirmation({
            to: user.email,
            patientName: `${user.firstName} ${user.lastName}`,
            doctorName: `${appointment.doctor.firstName} ${appointment.doctor.lastName}`,
            specialization: appointment.doctor.specialization.name,
            date: new Date(appointment.appointmentDate).toLocaleDateString("uk-UA", { timeZone: "UTC" }),
              time: new Date(appointment.appointmentDate).toLocaleTimeString("uk-UA", {
                hour: "2-digit",
                minute: "2-digit",
                timeZone: "UTC",
              }),
          });
        }
      } catch (emailError) {
        console.error("Помилка відправки листа:", emailError);
      }

      res.status(201).json(toAppointmentDTO(appointment));
    } catch (error: unknown) {
      if (error instanceof Error) res.status(400).json({ message: error.message });
    }
  }
);

  router.get("/my", authMiddleware, roleMiddleware("PATIENT"), async (req: AuthRequest, res: Response) => {
    try {
      const appointments = await getAppointmentsByUser(req.user!.id);
      res.json(appointments.map(toAppointmentDTO));
    } catch (error: unknown) {
      if (error instanceof Error) res.status(500).json({ message: error.message });
    }
  });

  router.get("/doctor", authMiddleware, roleMiddleware("DOCTOR"), async (req: AuthRequest, res: Response) => {
    try {
      const appointments = await getAppointmentsByDoctor(req.user!.id);
      res.json(appointments.map(toAppointmentDTO));
    } catch (error: unknown) {
      if (error instanceof Error) res.status(500).json({ message: error.message });
    }
  });

// Оновлений PATCH /:id/status
router.patch("/:id/status", authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const appointment = await getAppointmentById(Number(req.params.id));
    if (!appointment) {
      res.status(404).json({ message: "Запис не знайдено" });
      return;
    }

    const { status, cancelReason } = req.body;

    // Якщо адмін скасовує — відправляємо лист пацієнту
    if (status === "CANCELLED" && req.user?.role === "ADMIN") {
      const patientEmail = appointment.user?.email;
      const patientName = appointment.user
        ? `${appointment.user.firstName} ${appointment.user.lastName}`
        : appointment.guestName ?? "Пацієнт";

      const date = new Date(appointment.appointmentDate).toLocaleDateString("uk-UA", { timeZone: "UTC" });
      const time = new Date(appointment.appointmentDate).toLocaleTimeString("uk-UA", {
        hour: "2-digit",
        minute: "2-digit",
        timeZone: "UTC",
      });

      if (patientEmail) {
        try {
          await sendCancellationByAdmin({
            to: patientEmail,
            patientName,
            doctorName: `${appointment.doctor.firstName} ${appointment.doctor.lastName}`,
            specialization: appointment.doctor.specialization.name,
            date,
            time,
            reason: cancelReason || "Не вказано",
          });
        } catch (emailError) {
          console.error("Помилка відправки листа:", emailError);
        }
      }

      // Оновлюємо статус і причину
      const updated = await prisma.appointment.update({
        where: { id: Number(req.params.id) },
        data: { status: "CANCELLED", cancelReason: cancelReason || null },
      });
      res.json(updated);
      return;
    }

    const updated = await updateAppointmentStatus(Number(req.params.id), status as Status);
    res.json(updated);
  } catch (error: unknown) {
    if (error instanceof Error) res.status(400).json({ message: error.message });
  }
});

// Оновлений DELETE /:id — для пацієнта з сповіщенням адміну
router.delete("/:id", authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const appointment = await getAppointmentById(Number(req.params.id));
    if (!appointment) {
      res.status(404).json({ message: "Запис не знайдено" });
      return;
    }
    if (req.user!.role === "PATIENT" && appointment.userId !== req.user!.id) {
      res.status(403).json({ message: "Недостатньо прав доступу" });
      return;
    }

    const patientName = appointment.user
      ? `${appointment.user.firstName} ${appointment.user.lastName}`
      : appointment.guestName ?? "Пацієнт";

    const date = new Date(appointment.appointmentDate).toLocaleDateString("uk-UA", { timeZone: "UTC" });
    const time = new Date(appointment.appointmentDate).toLocaleTimeString("uk-UA", {
      hour: "2-digit",
      minute: "2-digit",
      timeZone: "UTC",
    });
    // Сповіщаємо адміна
    try {
      await sendCancellationNotifyAdmin({
        adminEmail: process.env.EMAIL_USER!,
        patientName,
        doctorName: `${appointment.doctor.firstName} ${appointment.doctor.lastName}`,
        date,
        time,
      });
    } catch (emailError) {
      console.error("Помилка відправки листа адміну:", emailError);
    }

    await prisma.appointment.delete({ where: { id: Number(req.params.id) } });
    res.status(200).json({ message: "Запис скасовано" });
  } catch (error: unknown) {
    if (error instanceof Error) res.status(400).json({ message: error.message });
  }
});

  export default router;