import { Router, Request, Response } from "express";
import { authMiddleware } from "../middleware/authMiddleware";
import { roleMiddleware } from "../middleware/roleMiddleware";
import { getAllDoctors, createDoctor } from "../repositories/doctorRepository";
import { getAllSymptoms, createSymptom } from "../repositories/symptomRepository";
import prisma from "../lib/prisma";


const router = Router();

// всі маршрути захищені — тільки ADMIN
router.use(authMiddleware, roleMiddleware("ADMIN"));

// публічний маршрут для спеціалізацій
router.get("/specializations", async (req: Request, res: Response) => {
  try {
    const specializations =
      await prisma.specialization.findMany();

    res.json(specializations);
  } catch (error: unknown) {
    if (error instanceof Error) {
      res.status(500).json({
        message: error.message,
      });
    }
  }
});

router.put(
  "/specializations/:id",
  authMiddleware,
  roleMiddleware("ADMIN"),
  async (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);

      const updated =
        await prisma.specialization.update({
          where: { id },
          data: req.body,
        });

      res.json(updated);
    } catch (error: unknown) {
      if (error instanceof Error) {
        res.status(500).json({
          message: error.message,
        });
      }
    }
  }
);

router.delete("/specializations/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);

    const doctorsCount = await prisma.doctor.count({
      where: { specializationId: id },
    });

    if (doctorsCount > 0) {
      return res.status(400).json({
        message: "Спочатку видаліть або змініть лікарів цієї спеціалізації",
      });
    }

    await prisma.specialization.delete({
      where: { id },
    });

    res.json({ message: "Видалено" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Помилка видалення" });
  }
}); 

// отримати всіх лікарів
router.get("/doctors", async (req: Request, res: Response) => {
  try {
    const doctors = await getAllDoctors();
    res.json(doctors);
  } catch (error: unknown) {
    if (error instanceof Error) {
      res.status(500).json({ message: error.message });
    }
  }
});

// додати лікаря
router.post("/doctors", async (req: Request, res: Response) => {
  try {
    const doctor = await createDoctor(req.body);
    res.status(201).json(doctor);
  } catch (error: unknown) {
    if (error instanceof Error) {
      res.status(400).json({ message: error.message });
    }
  }
});

// отримати всі записи
router.get("/appointments", async (req: Request, res: Response) => {
  try {
    const appointments = await prisma.appointment.findMany({
      include: {
        user: true,
        doctor: {
          include: {
            specialization: true,
          },
        },
      },
      orderBy: {
        appointmentDate: "asc",
      },
    });
    res.json(appointments);
  } catch (error: unknown) {
    if (error instanceof Error) {
      res.status(500).json({ message: error.message });
    }
  }
});

router.post("/appointments", async (req: Request, res: Response) => {
  try {
    const { userId, doctorId, appointmentDate, notes } = req.body;
    const appointment = await prisma.appointment.create({
      data: {
        userId: Number(userId),
        doctorId: Number(doctorId),
        appointmentDate: new Date(appointmentDate),
        notes,
        status: "CONFIRMED",
      },
      include: {
        user: true,
        doctor: { include: { specialization: true } },
      },
    });
    res.status(201).json(appointment);
  } catch (error: unknown) {
    if (error instanceof Error) {
      res.status(400).json({ message: error.message });
    }
  }
});

// додати спеціалізацію
router.post(
  "/specializations",
  authMiddleware,
  roleMiddleware("ADMIN"),
  async (req: Request, res: Response) => {
    try {
      const specialization =
        await prisma.specialization.create({
          data: req.body,
        });

      res.status(201).json(specialization);
    } catch (error: unknown) {
      if (error instanceof Error) {
        res.status(400).json({
          message: error.message,
        });
      }
    }
  }
);

// Категорії послуг
router.get("/service-categories", async (req: Request, res: Response) => {
  try {
    const categories = await prisma.serviceCategory.findMany();
    res.json(categories);
  } catch (error: unknown) {
    if (error instanceof Error) res.status(500).json({ message: error.message });
  }
});

router.post("/service-categories", async (req: Request, res: Response) => {
  try {
    const { name, description, imageUrl } = req.body;
    if (!name) return res.status(400).json({ message: "Назва обов'язкова" });

    const category = await prisma.serviceCategory.create({
      data: {
        name,
        description: description || null,
        imageUrl: imageUrl || null,
      },
    });
    res.status(201).json(category);
  } catch (error: unknown) {
    if (error instanceof Error) res.status(400).json({ message: error.message });
  }
});

router.put("/service-categories/:id", async (req: Request, res: Response) => {
  try {
    const { name, description, imageUrl } = req.body;
    const category = await prisma.serviceCategory.update({
      where: { id: Number(req.params.id) },
      data: {
        name,
        description: description || null,
        imageUrl: imageUrl || null,
      },
    });
    res.json(category);
  } catch (error: unknown) {
    if (error instanceof Error) res.status(400).json({ message: error.message });
  }
});

router.delete("/service-categories/:id", async (req: Request, res: Response) => {
  try {
    await prisma.serviceCategory.delete({ where: { id: Number(req.params.id) } });
    res.json({ message: "Категорію видалено" });
  } catch (error: unknown) {
    if (error instanceof Error) res.status(400).json({ message: error.message });
  }
});

// Послуги
router.get("/services", async (req: Request, res: Response) => {
  try {
    const services = await prisma.service.findMany({
      include: {
        category: true,
        specialization: true, 
      },
      orderBy: {
        id: "asc",
      },
    });

    res.json(services);
  } catch (error: unknown) {
    if (error instanceof Error) {
      res.status(500).json({ message: error.message });
    }
  }
});

router.post("/services", async (req: Request, res: Response) => {
  try {
    const service = await prisma.service.create({
      data: {
        name: req.body.name,
        description: req.body.description,
        price: req.body.price ? Number(req.body.price) : null,
        duration: req.body.duration ? Number(req.body.duration) : null,
        categoryId: Number(req.body.categoryId),
        specializationId: req.body.specializationId
          ? Number(req.body.specializationId)
          : null,
      },
      include: {
        category: true,
        specialization: true,
      },
    });

    res.status(201).json(service);
  } catch (error: unknown) {
    if (error instanceof Error)
      res.status(400).json({ message: error.message });
  }
});

router.put("/services/:id", async (req: Request, res: Response) => {
  try {
    const service = await prisma.service.update({
      where: { id: Number(req.params.id) },
      data: {
        name: req.body.name,
        description: req.body.description,
        price: req.body.price ? Number(req.body.price) : null,
        duration: req.body.duration ? Number(req.body.duration) : null,
        categoryId: Number(req.body.categoryId),
        specializationId: req.body.specializationId
          ? Number(req.body.specializationId)
          : null,
      },
      include: {
        category: true,
        specialization: true,
      },
    });

    res.json(service);
  } catch (error: unknown) {
    if (error instanceof Error)
      res.status(400).json({ message: error.message });
  }
});

router.delete("/services/:id", async (req: Request, res: Response) => {
  try {
    await prisma.service.delete({ where: { id: Number(req.params.id) } });
    res.json({ message: "Послугу видалено" });
  } catch (error: unknown) {
    if (error instanceof Error) res.status(400).json({ message: error.message });
  }
});

// додати симптом
router.post("/symptoms", async (req: Request, res: Response) => {
  try {
    const symptom = await createSymptom(req.body);
    res.status(201).json(symptom);
  } catch (error: unknown) {
    if (error instanceof Error) {
      res.status(400).json({ message: error.message });
    }
  }
});

router.get("/users", async (req: Request, res: Response) => {
  try {
    const users = await prisma.user.findMany({
      select: {
        id: true,
        firstName: true,
        lastName: true,
        email: true,
        role: true,
        createdAt: true,
      },
    });
    res.json(users);
  } catch (error: unknown) {
    if (error instanceof Error) {
      res.status(500).json({ message: error.message });
    }
  }
});

router.get("/analytics", async (req: Request, res: Response) => {
  try {
    const now = new Date();

    const dateFrom = req.query.dateFrom
      ? new Date(req.query.dateFrom as string)
      : new Date(now.getFullYear(), now.getMonth() - 1, 1);

    const dateTo = req.query.dateTo
      ? new Date(req.query.dateTo as string)
      : new Date(now);

    dateTo.setHours(23, 59, 59, 999);

    const dateFilter = {
      appointmentDate: { gte: dateFrom, lte: dateTo },
    };

    const [
      totalPatients,
      totalGuests,
      appointmentsInPeriod,
      appointmentsConfirmed,
      pendingAppointments,
      appointmentsByStatus,
      appointmentsByMonth,
      topDoctors,
      avgRating,
      pendingReviews,
      topSpecializations,
      peakHours,
    ] = await Promise.all([

      prisma.user.count({ where: { role: "PATIENT" } }),

      prisma.appointment.count({
        where: { ...dateFilter, userId: null, guestName: { not: null } },
      }),

      prisma.appointment.count({ where: dateFilter }),

      prisma.appointment.count({
        where: { ...dateFilter, status: "CONFIRMED" },
      }),

      prisma.appointment.count({ where: { status: "PENDING" } }),

      prisma.appointment.groupBy({
        by: ["status"],
        _count: { status: true },
        where: dateFilter,
      }),

      prisma.appointment.findMany({
        where: dateFilter,
        select: { appointmentDate: true },
      }),

      prisma.appointment.groupBy({
        by: ["doctorId"],
        _count: { doctorId: true },
        orderBy: { _count: { doctorId: "desc" } },
        take: 5,
        where: dateFilter,
      }),

      prisma.review.aggregate({
        _avg: { rating: true },
        where: { isVisible: true },
      }),

      prisma.review.count({ where: { isVisible: false } }),

      prisma.appointment.groupBy({
        by: ["doctorId"],
        _count: { doctorId: true },
        where: dateFilter,
      }),

      prisma.appointment.findMany({
        select: { appointmentDate: true },
        where: { ...dateFilter, status: { not: "CANCELLED" } },
      }),
    ]);

    // Місячна динаміка
    const monthlyData = Array.from({ length: 6 }, (_, i) => {
      const date = new Date(now.getFullYear(), now.getMonth() - 5 + i, 1);
      const month = date.toLocaleString("uk-UA", { month: "short" });
      const count = appointmentsByMonth.filter((a: any) => {
        const d = new Date(a.appointmentDate);
        return d.getMonth() === date.getMonth() && d.getFullYear() === date.getFullYear();
      }).length;
      return { month, count };
    });

    // Пікові години
    const hoursMap: Record<number, number> = {};
    peakHours.forEach((a: any) => {
      const hour = new Date(a.appointmentDate).getUTCHours();
      hoursMap[hour] = (hoursMap[hour] || 0) + 1;
    });
    const peakHoursData = Object.entries(hoursMap)
      .map(([hour, count]) => ({ hour: `${hour}:00`, count: count as number }))
      .sort((a, b) => parseInt(a.hour) - parseInt(b.hour));

    // Топ лікарів
    const doctorIds = topDoctors.map((d: any) => d.doctorId);
    const doctorsInfo = await prisma.doctor.findMany({
      where: { id: { in: doctorIds } },
      select: { id: true, firstName: true, lastName: true, specialization: { select: { name: true } } },
    });
    const topDoctorsData = topDoctors.map((d: any) => {
      const info = doctorsInfo.find((doc) => doc.id === d.doctorId);
      return {
        name: info ? `${info.firstName} ${info.lastName}` : "—",
        specialization: info?.specialization.name ?? "—",
        count: d._count.doctorId,
      };
    });

    // Топ спеціалізацій
    const allDoctorIds = topSpecializations.map((d: any) => d.doctorId);
    const allDoctorsInfo = await prisma.doctor.findMany({
      where: { id: { in: allDoctorIds } },
      select: { id: true, specialization: { select: { name: true } } },
    });
    const specMap: Record<string, number> = {};
    topSpecializations.forEach((d: any) => {
      const doc = allDoctorsInfo.find((doc) => doc.id === d.doctorId);
      const specName = doc?.specialization.name ?? "Інше";
      specMap[specName] = (specMap[specName] || 0) + d._count.doctorId;
    });
    const topSpecData = Object.entries(specMap)
      .map(([name, count]) => ({ name, count: count as number }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    res.json({
      kpi: {
        totalPatients,
        totalGuests,
        appointmentsInPeriod,
        appointmentsConfirmed,
        pendingAppointments,
        avgRating: avgRating._avg.rating?.toFixed(1) ?? "—",
        pendingReviews,
      },
      appointmentsByStatus: appointmentsByStatus.map((s: any) => ({
        status: s.status,
        count: s._count.status,
      })),
      monthlyData,
      topDoctors: topDoctorsData,
      topSpecializations: topSpecData,
      peakHours: peakHoursData,
    });
  } catch (error: unknown) {
    if (error instanceof Error) res.status(500).json({ message: error.message });
  }
});

export default router;  