-- AlterTable
ALTER TABLE "Specialization" ADD COLUMN     "text" TEXT;
