/*
  Warnings:

  - You are about to drop the column `text` on the `Specialization` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Specialization" DROP COLUMN "text",
ADD COLUMN     "fullDesc" TEXT,
ADD COLUMN     "imageUrl" TEXT,
ADD COLUMN     "shortDesc" TEXT;
