/*
  Warnings:

  - You are about to drop the column `specializationId` on the `Service` table. All the data in the column will be lost.

*/
-- DropForeignKey
ALTER TABLE "Service" DROP CONSTRAINT "Service_specializationId_fkey";

-- AlterTable
ALTER TABLE "Service" DROP COLUMN "specializationId";

-- CreateTable
CREATE TABLE "_ServiceToSpecialization" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "_ServiceToSpecialization_AB_unique" ON "_ServiceToSpecialization"("A", "B");

-- CreateIndex
CREATE INDEX "_ServiceToSpecialization_B_index" ON "_ServiceToSpecialization"("B");

-- AddForeignKey
ALTER TABLE "_ServiceToSpecialization" ADD CONSTRAINT "_ServiceToSpecialization_A_fkey" FOREIGN KEY ("A") REFERENCES "Service"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_ServiceToSpecialization" ADD CONSTRAINT "_ServiceToSpecialization_B_fkey" FOREIGN KEY ("B") REFERENCES "Specialization"("id") ON DELETE CASCADE ON UPDATE CASCADE;
