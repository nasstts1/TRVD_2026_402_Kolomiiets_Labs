-- CreateEnum
CREATE TYPE "QuestionType" AS ENUM ('SINGLE', 'MULTIPLE');

-- CreateTable
CREATE TABLE "SymptomQuestion" (
    "id" SERIAL NOT NULL,
    "symptomId" INTEGER NOT NULL,
    "question" TEXT NOT NULL,
    "type" "QuestionType" NOT NULL,
    "order" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "SymptomQuestion_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SymptomOption" (
    "id" SERIAL NOT NULL,
    "questionId" INTEGER NOT NULL,
    "text" TEXT NOT NULL,
    "order" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "SymptomOption_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RecommendationWeight" (
    "id" SERIAL NOT NULL,
    "optionId" INTEGER NOT NULL,
    "specializationId" INTEGER NOT NULL,
    "weight" INTEGER NOT NULL DEFAULT 1,

    CONSTRAINT "RecommendationWeight_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "SymptomQuestion" ADD CONSTRAINT "SymptomQuestion_symptomId_fkey" FOREIGN KEY ("symptomId") REFERENCES "Symptom"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SymptomOption" ADD CONSTRAINT "SymptomOption_questionId_fkey" FOREIGN KEY ("questionId") REFERENCES "SymptomQuestion"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RecommendationWeight" ADD CONSTRAINT "RecommendationWeight_optionId_fkey" FOREIGN KEY ("optionId") REFERENCES "SymptomOption"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RecommendationWeight" ADD CONSTRAINT "RecommendationWeight_specializationId_fkey" FOREIGN KEY ("specializationId") REFERENCES "Specialization"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
