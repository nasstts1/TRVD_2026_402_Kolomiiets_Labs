-- CreateEnum
CREATE TYPE "EducationType" AS ENUM ('EDUCATION', 'TRAINING');

-- AlterTable
ALTER TABLE "Doctor" ADD COLUMN     "bio" TEXT,
ADD COLUMN     "category" TEXT,
ADD COLUMN     "experience" INTEGER;

-- CreateTable
CREATE TABLE "DoctorEducation" (
    "id" SERIAL NOT NULL,
    "doctorId" INTEGER NOT NULL,
    "type" "EducationType" NOT NULL DEFAULT 'EDUCATION',
    "institution" TEXT NOT NULL,
    "degree" TEXT,
    "year" INTEGER,
    "order" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "DoctorEducation_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "DoctorEducation" ADD CONSTRAINT "DoctorEducation_doctorId_fkey" FOREIGN KEY ("doctorId") REFERENCES "Doctor"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
