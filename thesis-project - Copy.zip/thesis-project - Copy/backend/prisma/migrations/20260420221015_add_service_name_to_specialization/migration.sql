-- AlterTable
ALTER TABLE "Specialization" ADD COLUMN     "serviceName" TEXT;
