/*
  Warnings:

  - You are about to drop the `_ServiceToSpecialization` table. If the table is not empty, all the data it contains will be lost.

*/
-- CreateEnum
CREATE TYPE "ServiceType" AS ENUM ('CONSULTATION', 'PROCEDURE', 'LABORATORY', 'CHECKUP');

-- DropForeignKey
ALTER TABLE "_ServiceToSpecialization" DROP CONSTRAINT "_ServiceToSpecialization_A_fkey";

-- DropForeignKey
ALTER TABLE "_ServiceToSpecialization" DROP CONSTRAINT "_ServiceToSpecialization_B_fkey";

-- AlterTable
ALTER TABLE "Appointment" ADD COLUMN     "serviceId" INTEGER;

-- AlterTable
ALTER TABLE "Service" ADD COLUMN     "requiresBooking" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "serviceType" "ServiceType" NOT NULL DEFAULT 'CONSULTATION',
ADD COLUMN     "specializationId" INTEGER;

-- DropTable
DROP TABLE "_ServiceToSpecialization";

-- AddForeignKey
ALTER TABLE "Service" ADD CONSTRAINT "Service_specializationId_fkey" FOREIGN KEY ("specializationId") REFERENCES "Specialization"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Appointment" ADD CONSTRAINT "Appointment_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "Service"("id") ON DELETE SET NULL ON UPDATE CASCADE;
