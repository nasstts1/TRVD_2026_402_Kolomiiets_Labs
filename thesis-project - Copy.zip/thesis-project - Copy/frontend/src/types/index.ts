export interface User {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  role: "PATIENT" | "DOCTOR" | "ADMIN";
  createdAt: string;
}

export interface Doctor {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone: string | null;
  specialization: {
    id: number;
    name: string;
  };
}

export interface Appointment {
  id: number;
  appointmentDate: string;
  status: "PENDING" | "CONFIRMED" | "CANCELLED";
  notes: string | null;
  doctor: {
    id: number;
    firstName: string;
    lastName: string;
    specialization?: {
      name: string;
    };
  };
  user: {
    id: number;
    firstName: string;
    lastName: string;
  };
}

export interface Symptom {
  id: number;
  name: string;
  description: string | null;
}

export interface AuthResponse {
  user: User;
  token: string;
}