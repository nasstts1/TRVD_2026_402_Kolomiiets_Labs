export interface User {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  role: "PATIENT" | "DOCTOR" | "ADMIN";
  createdAt: string;
  phone?: string | null; 
}

export interface DoctorEducation {
  id: number;
  type: "EDUCATION" | "TRAINING";
  institution: string;
  degree: string | null;
  year: number | null;
  order: number;
}

export interface Doctor {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone: string | null;
  photoUrl: string | null;
  workDays: number[];
  breakStart: string;
  breakEnd: string;
  experience: number | null;
  bio: string | null;
  category: string | null;
  specialization: {
    id: number;
    name: string;
  };
  education: DoctorEducation[];
  reviews: {
    id: number;
    rating: number;
    comment: string;
    createdAt: string;
    isVisible: boolean;
    user: { firstName: string; lastName: string };
  }[];
}

export interface Appointment {
  id: number;
  appointmentDate: string;
  status: "PENDING" | "CONFIRMED" | "CANCELLED";
  notes: string | null;
  hasReview: boolean; // додай
  doctor: {
    id: number;
    firstName: string;
    lastName: string;
    specialization?: { name: string };
  };
  user: {
    id: number;
    firstName: string;
    lastName: string;
  };
}

export interface Symptom {
  id: number;
  name: string;
  description: string | null;
}

export interface AuthResponse {
  user: User;
  token: string;
}