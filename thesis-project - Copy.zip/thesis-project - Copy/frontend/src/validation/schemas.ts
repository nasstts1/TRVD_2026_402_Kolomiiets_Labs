import { z } from "zod";

export const adminSchema = z.object({
  firstName: z.string().min(2, "Ім'я має бути мінімум 2 символи"),
  lastName: z.string().min(2, "Прізвище має бути мінімум 2 символи"),
  email: z.string().min(1, "Email обов'язковий").email("Невірний формат email"),
  password: z.string().min(8, "Пароль має бути мінімум 8 символів"),
});

export const loginSchema = z.object({
  email: z
    .string()
    .min(1, "Email обов'язковий")
    .email("Невірний формат email"),
  password: z
    .string()
    .min(1, "Пароль обов'язковий"),
});

export const registerSchema = z.object({
  firstName: z.string().min(2, "Ім'я має бути мінімум 2 символи"),
  lastName: z.string().min(2, "Прізвище має бути мінімум 2 символи"),
  email: z.string().min(1, "Email обов'язковий").email("Невірний формат email"),
  phone: z.string().min(10, "Введіть коректний номер телефону"),
  password: z.string().min(8, "Пароль має бути мінімум 8 символів"),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Паролі не співпадають",
  path: ["confirmPassword"],
});

export const doctorSchema = z.object({
  firstName: z.string().min(2, "Ім'я має бути мінімум 2 символи"),
  lastName: z.string().min(2, "Прізвище має бути мінімум 2 символи"),
  email: z.string().min(1, "Email обов'язковий").email("Невірний формат email"),
  phone: z
    .string()
    .regex(/^\+380\d{9}$/, "Формат: +380XXXXXXXXX")
    .optional()
    .or(z.literal("")),
  specializationId: z.string().min(1, "Оберіть спеціалізацію"),
  password: z.string().min(8, "Пароль має бути мінімум 8 символів"),
});

export const specializationSchema = z.object({
  name: z.string().min(2, "Назва має бути мінімум 2 символи"),
  serviceName: z.string().optional(),
  description: z.string().optional(),
  shortDesc: z.string().optional(),
  fullDesc: z.string().optional(),
  imageUrl: z.string().optional(),
});

export type LoginForm = z.infer<typeof loginSchema>;
export type RegisterForm = z.infer<typeof registerSchema>;
export type DoctorForm = z.infer<typeof doctorSchema>;
export type SpecializationForm = z.infer<typeof specializationSchema>;
export type AdminForm = z.infer<typeof adminSchema>;