import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import Navbar from "./components/Navbar";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import DoctorsPage from "./pages/DoctorsPage";
import AdminPage from "./pages/AdminPage";
import ProtectedRoute from "./components/ProtectedRoute";
import Footer from "./components/Footer";
import DoctorProfilePage from "./pages/DoctorProfilePage";

const AppContent = () => {
  const location = useLocation();
  const hideNavbar = location.pathname.startsWith("/admin");

  return (
    <div className="flex flex-col min-h-screen">
      {!hideNavbar && <Navbar />}
      <main className="flex-1">
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/doctors" element={<DoctorsPage />} />
          <Route path="/profile" element={
            <ProtectedRoute>
              <div>Профіль</div>
            </ProtectedRoute>
          } />
          <Route path="/appointments" element={
            <ProtectedRoute role="PATIENT">
              <div>Мої записи</div>
            </ProtectedRoute>
          } />
          <Route path="/admin" element={
            <ProtectedRoute role="ADMIN">
              <AdminPage />
            </ProtectedRoute>
          } />
          <Route path="/doctor" element={
            <ProtectedRoute role="DOCTOR">
              <AdminPage />
            </ProtectedRoute>
          } />
          <Route path="/doctor/profile" element={
            <ProtectedRoute role="DOCTOR">
              <DoctorProfilePage />
            </ProtectedRoute>
          } />
          <Route path="*" element={<Navigate to="/doctors" />} />
        </Routes>
      </main>
      {!hideNavbar && <Footer />}
    </div>
  );
};

const App = () => {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppContent />
      </BrowserRouter>
    </AuthProvider>
  );
};

export default App;