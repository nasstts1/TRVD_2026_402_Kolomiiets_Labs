import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import Navbar from "./components/Navbar/Navbar";
import LoginPage from "./pages/Auth/LoginPage";
import RegisterPage from "./pages/Auth/RegisterPage";
import DoctorsPage from "./pages/Doctors/DoctorsPage";
import AdminPage from "./pages/AdminPage/AdminPage";
import ProtectedRoute from "./components/ProtectedRoute";
import Footer from "./components/Footer/Footer";
import DoctorProfilePage from "./pages/DoctorProfilePage";
import MainPage from "./pages/MainPage/MainPage";
import ServicesPage from "./pages/Services/Services";
import AboutUsPage from "./pages/AboutUs/AboutUsPage"
import ServiceCategoryPage from "./pages/ServiceCategoryPage/ServiceCategoryPage";
import FloatingQuizButton from "./components/FloatingQuizButton/FloatingQuizButton";
import MyAppointmentsPage from "./pages/MyAppointmentsPage";
import PatientProfilePage from "./pages/PatientProfilePage";
import DoctorPage from "./pages/DoctorPage/DoctorPage";


  const AppContent = () => {
    const location = useLocation();
    const hideNavbar = location.pathname === "/admin" || location.pathname === "/doctor" || location.pathname.startsWith("/admin/") || location.pathname.startsWith("/doctor/");

    return (
      <div className="flex flex-col min-h-screen">
        {!hideNavbar && <Navbar />}
        <main className="flex-1">
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/all_services" element={<ServicesPage />} />
          <Route path="/doctors" element={<DoctorsPage />} />
          <Route path="/doctors/:id" element={<DoctorPage />} />
          <Route path="/about_us" element={<AboutUsPage />} />
          <Route path="/" element={<MainPage />} />
          <Route path="/services/:id" element={<ServiceCategoryPage />} />
          <Route path="/profile" element={
            <ProtectedRoute>
              <PatientProfilePage />
            </ProtectedRoute>
          } />
          <Route path="/appointments" element={
            <ProtectedRoute role="PATIENT">
              <MyAppointmentsPage />
            </ProtectedRoute>
          } />
          <Route path="/admin" element={
            <ProtectedRoute role="ADMIN">
              <AdminPage />
            </ProtectedRoute>
          } />
          <Route path="/doctor" element={
            <ProtectedRoute role="DOCTOR">
              <AdminPage />
            </ProtectedRoute>
          } />
          <Route path="/doctor/profile" element={
            <ProtectedRoute role="DOCTOR">
              <DoctorProfilePage />
            </ProtectedRoute>
          } />
          <Route path="*" element={<Navigate to="/doctors" />} />
        </Routes>

        <FloatingQuizButton />
      </main>
      {!hideNavbar && <Footer />}
    </div>
  );
};

const App = () => {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppContent />
      </BrowserRouter>
    </AuthProvider>
  );
};

export default App;