import api from "./api";

export interface ServiceCategory {
  id: number;
  name: string;
  description: string | null;
  imageUrl?: string | null;
}

export interface Service {
  id: number;
  name: string;
  description: string | null;
  price: number | null;
  duration: number | null;
  serviceType: string;
  requiresBooking: boolean;
  imageUrl?: string | null;
  category: ServiceCategory;
  specialization?: { id: number; name: string } | null;
}

export const getServiceCategories = async (): Promise<ServiceCategory[]> => {
  const response = await api.get("/services/categories");
  return response.data;
};

export const getServicesByCategory = async (categoryId: number): Promise<Service[]> => {
  const response = await api.get(`/services/categories/${categoryId}/services`);
  return response.data;
};