import api from "./api";
import type { Doctor } from "../types";

export const getDoctors = async (): Promise<Doctor[]> => {
  const response = await api.get("/doctors");
  return response.data;
};

export const getDoctorById = async (id: number): Promise<Doctor> => {
  const response = await api.get(`/doctors/${id}`);
  return response.data;
};