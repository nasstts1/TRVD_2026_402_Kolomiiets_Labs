import api from "./api";
import type { Doctor, User } from "../types";

export const getAdminDoctors = async (): Promise<Doctor[]> => {
  const response = await api.get("/admin/doctors");
  return response.data;
};

export const deleteDoctor = async (id: number): Promise<void> => {
  await api.delete(`/doctors/${id}`);
};

export const getAdminUsers = async (): Promise<User[]> => {
  const response = await api.get("/admin/users");
  return response.data;
};

export const deleteUser = async (id: number): Promise<void> => {
  await api.delete(`/users/${id}`);
};

export const getAdminAppointments = async () => {
  const response = await api.get("/admin/appointments");
  return response.data;
};