import api from "./api";

export interface Specialization {
  id: number;
  name: string;
  description: string | null;
}

export const getSpecializations = async (): Promise<Specialization[]> => {
  const response = await api.get("/specializations");
  return response.data;
};