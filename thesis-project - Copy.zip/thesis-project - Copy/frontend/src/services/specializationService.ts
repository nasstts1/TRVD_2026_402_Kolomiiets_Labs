import api from "./api";

export interface Specialization {
  id: number;
  name: string;
  description?: string | null;
  shortDesc?: string | null;
  imageUrl?: string | null;
}

export const getSpecializations = async (): Promise<Specialization[]> => {
  const response = await api.get("/specializations");
  return response.data;
};

export const updateSpecialization = async (
  id: number,
  data: any
): Promise<Specialization> => {
  const response = await api.put(
    `/admin/specializations/${id}`,
    data
  );

  return response.data;
};