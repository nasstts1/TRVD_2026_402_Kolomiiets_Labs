import { useEffect, useState } from "react";
import api from "../../services/api";
import s from "../styles/DoctorAppointmentsTable.module.scss";

const DoctorAppointmentsTable = () => {
  const [appointments, setAppointments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get("/appointments/doctor")
      .then((res) => setAppointments(res.data))
      .finally(() => setLoading(false));
  }, []);

  const formatDate = (d: string) => new Date(d).toLocaleDateString("uk-UA", { timeZone: "UTC" });
  const formatTime = (d: string) => new Date(d).toLocaleTimeString("uk-UA", { hour: "2-digit", minute: "2-digit", timeZone: "UTC" });

  const getStatusClass = (status: string) => {
    if (status === "CONFIRMED") return s.statusConfirmed;
    if (status === "CANCELLED") return s.statusCancelled;
    return s.statusPending;
  };

  const getStatusLabel = (status: string) => {
    if (status === "CONFIRMED") return "Підтверджено";
    if (status === "CANCELLED") return "Скасовано";
    return "Очікує";
  };

  const renderPatient = (a: any) => a.guestName ? (
    <div>
      <p className={s.name}>{a.guestName}</p>
      <p className={s.sub}>{a.guestPhone ?? "—"}</p>
    </div>
  ) : a.user ? (
    <div>
      <p className={s.name}>{a.user.firstName} {a.user.lastName}</p>
      <p className={s.sub}>{a.user.email}</p>
    </div>
  ) : <span className={s.tdGray}>—</span>;

  if (loading) return <p className={s.tdGray}>Завантаження...</p>;

  return (
    <div className={s.wrap}>
      <div className={s.header}>
        <h2 className={s.title}>Мої записи</h2>
        <span className={s.total}>Всього: {appointments.length}</span>
      </div>

      {appointments.length === 0 ? (
        <div className={s.empty}>Записів немає</div>
      ) : (
        <>
          {/* Таблиця — десктоп */}
          <div className={s.tableWrap}>
            <table className={s.table}>
              <thead className={s.thead}>
                <tr>
                  <th className={s.th}>ID</th>
                  <th className={s.th}>Пацієнт</th>
                  <th className={s.th}>Дата і час</th>
                  <th className={s.th}>Статус</th>
                  <th className={s.th}>Нотатки</th>
                </tr>
              </thead>
              <tbody>
                {appointments.map((a) => (
                  <tr key={a.id} className={s.tr}>
                    <td className={`${s.td} ${s.tdGray}`}>{a.id}</td>
                    <td className={s.td}>{renderPatient(a)}</td>
                    <td className={s.td}>
                      <p>{formatDate(a.appointmentDate)}</p>
                      <p className={s.sub}>{formatTime(a.appointmentDate)}</p>
                    </td>
                    <td className={s.td}>
                      <span className={`${s.statusBadge} ${getStatusClass(a.status)}`}>
                        {getStatusLabel(a.status)}
                      </span>
                    </td>
                    <td className={`${s.td} ${s.tdGray}`}>{a.notes ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Картки — мобільний */}
          <div className={s.cards}>
            {appointments.map((a) => (
              <div key={a.id} className={s.card}>
                <div className={s.cardRow}>
                  <div>
                    <p className={s.cardLabel}>Пацієнт</p>
                    <p className={s.cardValue}>
                      {a.guestName ?? (a.user ? `${a.user.firstName} ${a.user.lastName}` : "—")}
                    </p>
                    {a.user && <p className={s.cardSub}>{a.user.email}</p>}
                  </div>
                  <span className={`${s.statusBadge} ${getStatusClass(a.status)}`}>
                    {getStatusLabel(a.status)}
                  </span>
                </div>
                <div className={s.cardRow}>
                  <div>
                    <p className={s.cardLabel}>Дата і час</p>
                    <p className={s.cardValue}>{formatDate(a.appointmentDate)}</p>
                    <p className={s.cardSub}>{formatTime(a.appointmentDate)}</p>
                  </div>
                  {a.notes && (
                    <div style={{ textAlign: "right", maxWidth: "55%" }}>
                      <p className={s.cardLabel}>Нотатки</p>
                      <p className={s.cardSub}>{a.notes}</p>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default DoctorAppointmentsTable;