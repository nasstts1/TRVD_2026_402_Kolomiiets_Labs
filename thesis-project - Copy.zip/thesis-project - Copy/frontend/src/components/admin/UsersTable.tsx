import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { adminSchema, type AdminForm } from "../../validation/schemas";
import { getAdminUsers, deleteUser } from "../../services/adminService";
import type { User } from "../../types";
import api from "../../services/api";
import toast from "react-hot-toast";

const ROLES = ["Всі", "ADMIN", "PATIENT"];  

const UsersTable = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [activeRole, setActiveRole] = useState("Всі");

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<AdminForm>({
    resolver: zodResolver(adminSchema),
  });

  useEffect(() => {
    getAdminUsers()
      .then(setUsers)
      .finally(() => setLoading(false));
  }, []);

  const handleDelete = async (id: number) => {
    try {
      await deleteUser(id);
      setUsers(users.filter((u) => u.id !== id));
      setConfirmId(null);
      toast.success("Користувача видалено!");
    } catch {
      toast.error("Помилка при видаленні");
    }
  };

  const onSubmit = async (data: AdminForm) => {
    try {
      await api.post("/auth/register", { ...data, role: "ADMIN" });
      const updated = await getAdminUsers();
      setUsers(updated);
      setShowModal(false);
      reset();
      toast.success("Адміністратора додано!");
    } catch {
      toast.error("Помилка. Можливо email вже використовується.");
    }
  };

  const filtered = activeRole === "Всі"
    ? users.filter((u) => u.role !== "DOCTOR")
    : users.filter((u) => u.role === activeRole);

  if (loading) return <p className="text-gray-500">Завантаження...</p>;

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Користувачі</h2>
        <button
          onClick={() => setShowModal(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
        >
          + Додати адміна
        </button>
      </div>

      {/* Фільтр по ролях */}
      <div className="flex gap-2 mb-6">
        {ROLES.map((role) => (
          <button
            key={role}
            onClick={() => setActiveRole(role)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition ${
              activeRole === role
                ? "bg-blue-600 text-white"
                : "bg-gray-100 text-gray-600 hover:bg-gray-200"
            }`}
          >
            {role === "Всі" ? `Всі (${users.filter(u => u.role !== "DOCTOR").length})` :
            role === "ADMIN" ? `Адміни (${users.filter(u => u.role === "ADMIN").length})` :
            `Пацієнти (${users.filter(u => u.role === "PATIENT").length})`}
          </button>
        ))}
      </div>

      {/* Модальне вікно */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-8 w-full max-w-md shadow-xl">
            <h3 className="text-xl font-bold mb-6">Новий адміністратор</h3>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div>
                <input
                  type="text"
                  placeholder="Ім'я"
                  {...register("firstName")}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.firstName ? "border-red-500" : "border-gray-300"}`}
                />
                {errors.firstName && <p className="text-red-500 text-sm mt-1">{errors.firstName.message}</p>}
              </div>
              <div>
                <input
                  type="text"
                  placeholder="Прізвище"
                  {...register("lastName")}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.lastName ? "border-red-500" : "border-gray-300"}`}
                />
                {errors.lastName && <p className="text-red-500 text-sm mt-1">{errors.lastName.message}</p>}
              </div>
              <div>
                <input
                  type="email"
                  placeholder="Email"
                  {...register("email")}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.email ? "border-red-500" : "border-gray-300"}`}
                />
                {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>}
              </div>
              <div>
                <input
                  type="password"
                  placeholder="Пароль (мінімум 8 символів)"
                  {...register("password")}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.password ? "border-red-500" : "border-gray-300"}`}
                />
                {errors.password && <p className="text-red-500 text-sm mt-1">{errors.password.message}</p>}
              </div>
              <div className="flex gap-3 mt-6">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  {isSubmitting ? "Збереження..." : "Зберегти"}
                </button>
                <button
                  type="button"
                  onClick={() => { setShowModal(false); reset(); }}
                  className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300"
                >
                  Скасувати
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="text-left px-6 py-4 text-gray-500 font-medium">ID</th>
              <th className="text-left px-6 py-4 text-gray-500 font-medium">Ім'я</th>
              <th className="text-left px-6 py-4 text-gray-500 font-medium">Email</th>
              <th className="text-left px-6 py-4 text-gray-500 font-medium">Роль</th>
              <th className="text-left px-6 py-4 text-gray-500 font-medium">Дата реєстрації</th>
              <th className="text-left px-6 py-4 text-gray-500 font-medium">Дії</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((user) => (
              <tr key={user.id} className="border-b hover:bg-gray-50">
                <td className="px-6 py-4 text-gray-500">{user.id}</td>
                <td className="px-6 py-4 font-medium">
                  {user.firstName} {user.lastName}
                </td>
                <td className="px-6 py-4 text-gray-600">{user.email}</td>
                <td className="px-6 py-4">
                  <span className={`px-3 py-1 rounded-full text-sm ${
                    user.role === "ADMIN"
                      ? "bg-purple-100 text-purple-700"
                      : user.role === "DOCTOR"
                      ? "bg-green-100 text-green-700"
                      : "bg-blue-100 text-blue-700"
                  }`}>
                    {user.role === "ADMIN" ? "Адмін" : user.role === "DOCTOR" ? "Лікар" : "Пацієнт"}
                  </span>
                </td>
                <td className="px-6 py-4 text-gray-600">
                  {new Date(user.createdAt).toLocaleDateString("uk-UA")}
                </td>
                <td className="px-6 py-4">
                  {confirmId === user.id ? (
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleDelete(user.id)}
                        className="bg-red-500 text-white px-3 py-1 rounded-lg text-sm hover:bg-red-600"
                      >
                        Підтвердити
                      </button>
                      <button
                        onClick={() => setConfirmId(null)}
                        className="bg-gray-200 text-gray-700 px-3 py-1 rounded-lg text-sm"
                      >
                        Скасувати
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setConfirmId(user.id)}
                      className="text-red-500 hover:text-red-700 text-sm"
                    >
                      Видалити
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default UsersTable;