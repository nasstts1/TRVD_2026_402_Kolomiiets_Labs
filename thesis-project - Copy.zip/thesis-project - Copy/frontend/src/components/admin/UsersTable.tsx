import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { adminSchema, type AdminForm } from "../../validation/schemas";
import { getAdminUsers, deleteUser } from "../../services/adminService";
import type { User } from "../../types";
import api from "../../services/api";
import toast from "react-hot-toast";
import s from "../styles/UsersTable.module.scss";

const ROLES = ["Всі", "ADMIN", "PATIENT"];

const UsersTable = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [activeRole, setActiveRole] = useState("Всі");

  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } =
    useForm<AdminForm>({ resolver: zodResolver(adminSchema) });

  useEffect(() => {
    getAdminUsers().then(setUsers).finally(() => setLoading(false));
  }, []);

  const handleDelete = async (id: number) => {
    try {
      await deleteUser(id);
      setUsers(users.filter((u) => u.id !== id));
      setConfirmId(null);
      toast.success("Користувача видалено!");
    } catch {
      toast.error("Помилка при видаленні");
    }
  };

  const onSubmit = async (data: AdminForm) => {
    try {
      await api.post("/auth/register", { ...data, role: "ADMIN" });
      const updated = await getAdminUsers();
      setUsers(updated);
      setShowModal(false);
      reset();
      toast.success("Адміністратора додано!");
    } catch {
      toast.error("Помилка. Можливо email вже використовується.");
    }
  };

  const getRoleClass = (role: string) => {
    if (role === "ADMIN") return s.roleAdmin;
    if (role === "DOCTOR") return s.roleDoctor;
    return s.rolePatient;
  };

  const getRoleLabel = (role: string) => {
    if (role === "ADMIN") return "Адмін";
    if (role === "DOCTOR") return "Лікар";
    return "Пацієнт";
  };

  const filtered = activeRole === "Всі"
    ? users.filter((u) => u.role !== "DOCTOR")
    : users.filter((u) => u.role === activeRole);

  if (loading) return <p className={s.tdGray}>Завантаження...</p>;

  return (
    <div className={s.wrap}>
      <div className={s.header}>
        <h2 className={s.title}>Користувачі</h2>
        <button onClick={() => setShowModal(true)} className={s.btnAdd}>
          + Додати адміна
        </button>
      </div>

      {/* Фільтри */}
      <div className={s.filters}>
        {ROLES.map((role) => (
          <button
            key={role}
            onClick={() => setActiveRole(role)}
            className={`${s.filterBtn} ${activeRole === role ? s.filterBtnActive : ""}`}
          >
            {role === "Всі"
              ? `Всі (${users.filter(u => u.role !== "DOCTOR").length})`
              : role === "ADMIN"
              ? `Адміни (${users.filter(u => u.role === "ADMIN").length})`
              : `Пацієнти (${users.filter(u => u.role === "PATIENT").length})`}
          </button>
        ))}
      </div>

      {/* Модалка */}
      {showModal && (
        <div className={s.modal}>
          <div className={s.modalCard}>
            <h3 className={s.modalTitle}>Новий адміністратор</h3>
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className={s.formGroup}>
                <input type="text" placeholder="Ім'я" {...register("firstName")}
                  className={`${s.input} ${errors.firstName ? s.inputError : ""}`} />
                {errors.firstName && <p className={s.errorMsg}>{errors.firstName.message}</p>}
              </div>
              <div className={s.formGroup}>
                <input type="text" placeholder="Прізвище" {...register("lastName")}
                  className={`${s.input} ${errors.lastName ? s.inputError : ""}`} />
                {errors.lastName && <p className={s.errorMsg}>{errors.lastName.message}</p>}
              </div>
              <div className={s.formGroup}>
                <input type="email" placeholder="Email" {...register("email")}
                  className={`${s.input} ${errors.email ? s.inputError : ""}`} />
                {errors.email && <p className={s.errorMsg}>{errors.email.message}</p>}
              </div>
              <div className={s.formGroup}>
                <input type="password" placeholder="Пароль (мінімум 8 символів)" {...register("password")}
                  className={`${s.input} ${errors.password ? s.inputError : ""}`} />
                {errors.password && <p className={s.errorMsg}>{errors.password.message}</p>}
              </div>
              <div className={s.modalBtns}>
                <button type="submit" disabled={isSubmitting} className={s.btnSave}>
                  {isSubmitting ? "Збереження..." : "Зберегти"}
                </button>
                <button type="button" onClick={() => { setShowModal(false); reset(); }} className={s.btnCancelForm}>
                  Скасувати
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Таблиця — десктоп */}
      <div className={s.tableWrap}>
        <table className={s.table}>
          <thead className={s.thead}>
            <tr>
              <th className={s.th}>ID</th>
              <th className={s.th}>Ім'я</th>
              <th className={s.th}>Email</th>
              <th className={s.th}>Роль</th>
              <th className={s.th}>Дата реєстрації</th>
              <th className={s.th}>Дії</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((user) => (
              <tr key={user.id} className={s.tr}>
                <td className={`${s.td} ${s.tdGray}`}>{user.id}</td>
                <td className={s.td}>
                  <span className={s.name}>{user.firstName} {user.lastName}</span>
                </td>
                <td className={`${s.td} ${s.tdGray}`}>{user.email}</td>
                <td className={s.td}>
                  <span className={getRoleClass(user.role)}>{getRoleLabel(user.role)}</span>
                </td>
                <td className={`${s.td} ${s.tdGray}`}>
                  {new Date(user.createdAt).toLocaleDateString("uk-UA")}
                </td>
                <td className={s.td}>
                  <div className={s.actions}>
                    {confirmId === user.id ? (
                      <>
                        <button onClick={() => handleDelete(user.id)} className={s.btnConfirm}>Підтвердити</button>
                        <button onClick={() => setConfirmId(null)} className={s.btnCancelDel}>Скасувати</button>
                      </>
                    ) : (
                      <button onClick={() => setConfirmId(user.id)} className={s.btnDelete}>Видалити</button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Картки — мобільний */}
      <div className={s.cards}>
        {filtered.map((user) => (
          <div key={user.id} className={s.card}>
            <div className={s.cardTop}>
              <div>
                <p className={s.cardName}>{user.firstName} {user.lastName}</p>
                <p className={s.cardEmail}>{user.email}</p>
                <p className={s.cardDate}>{new Date(user.createdAt).toLocaleDateString("uk-UA")}</p>
              </div>
              <span className={getRoleClass(user.role)}>{getRoleLabel(user.role)}</span>
            </div>
            <div className={s.cardActions}>
              <button onClick={() => setConfirmId(user.id)} className={s.cardBtnDelete}>
                Видалити
              </button>
              {confirmId === user.id && (
                <>
                  <button onClick={() => handleDelete(user.id)} className={s.btnConfirm}>Підтвердити</button>
                  <button onClick={() => setConfirmId(null)} className={s.btnCancelDel}>Скасувати</button>
                </>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default UsersTable;