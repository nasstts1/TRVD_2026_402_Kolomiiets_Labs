import { useEffect, useState } from "react";
import api from "../../services/api";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, BarChart, Bar,
} from "recharts";
import s from "../styles/AnalyticsDashboard.module.scss";

interface Analytics {
  kpi: {
    totalPatients: number;
    totalGuests: number;
    appointmentsInPeriod: number;
    appointmentsConfirmed: number;
    pendingAppointments: number;
    avgRating: string;
    pendingReviews: number;
  };
  appointmentsByStatus: { status: string; count: number }[];
  monthlyData: { month: string; count: number }[];
  topDoctors: { name: string; specialization: string; count: number }[];
  topSpecializations: { name: string; count: number }[];
  peakHours: { hour: string; count: number }[];
}

const STATUS_COLORS: Record<string, string> = {
  PENDING: "#f59e0b",
  CONFIRMED: "#10b981",
  CANCELLED: "#ef4444",
};

const STATUS_LABELS: Record<string, string> = {
  PENDING: "Очікує",
  CONFIRMED: "Підтверджено",
  CANCELLED: "Скасовано",
};

const COLORS = ["#2563eb", "#10b981", "#f59e0b", "#8b5cf6", "#ef4444"];

const AnalyticsDashboard = () => {
  const [data, setData] = useState<Analytics | null>(null);
  const [loading, setLoading] = useState(true);

  const [dateFrom, setDateFrom] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 30);
    return d.toISOString().split("T")[0];
  });
  const [dateTo, setDateTo] = useState(() => new Date().toISOString().split("T")[0]);

  const fetchData = (from = dateFrom, to = dateTo) => {
    setLoading(true);
    api.get(`/admin/analytics?dateFrom=${from}&dateTo=${to}`)
      .then((res) => setData(res.data))
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchData(); }, []);

  if (loading) return <div className={s.loading}>Завантаження аналітики...</div>;
  if (!data) return null;

  const kpiCards = [
    { label: "Пацієнтів", value: data.kpi.totalPatients, icon: "👥", bg: "#eff6ff", color: "#2563eb" },
    { label: "Гостьових записів за період", value: data.kpi.totalGuests, icon: "👤", bg: "#f5f3ff", color: "#7c3aed" },
    { label: "Записів за період", value: data.kpi.appointmentsInPeriod, icon: "📅", bg: "#f0fdf4", color: "#16a34a" },
    { label: "Підтверджених за період", value: data.kpi.appointmentsConfirmed, icon: "✅", bg: "#f0fdfa", color: "#0d9488" },
    { label: "Очікують підтвердження", value: data.kpi.pendingAppointments, icon: "⏳", bg: "#fff7ed", color: "#ea580c" },
    { label: "Середня оцінка", value: data.kpi.avgRating, icon: "⭐", bg: "#fefce8", color: "#ca8a04" },
    { label: "Відгуків на модерації", value: data.kpi.pendingReviews, icon: "💬", bg: "#fef2f2", color: "#dc2626" },
  ];

  return (
    <div className={s.dashboard}>
      {/* Header */}
      <div className={s.header}>
        <h2 className={s.title}>Аналітика</h2>
        <span className={s.updated}>
          Оновлено: {new Date().toLocaleString("uk-UA")}
        </span>
      </div>

      {/* Фільтр */}
      <div className={s.filter}>
        <span className={s.filterLabel}>Період:</span>
        <div className={s.filterDates}>
          <input
            type="date"
            value={dateFrom}
            onChange={(e) => setDateFrom(e.target.value)}
            className={s.filterInput}
          />
          <span className={s.filterSep}>—</span>
          <input
            type="date"
            value={dateTo}
            onChange={(e) => setDateTo(e.target.value)}
            className={s.filterInput}
          />
        </div>
        <button onClick={() => fetchData()} className={s.applyBtn}>
          Застосувати
        </button>
        <div className={s.presets}>
          {[
            { label: "Сьогодні", days: 0 },
            { label: "Тиждень", days: 7 },
            { label: "Місяць", days: 30 },
            { label: "3 місяці", days: 90 },
          ].map((preset) => (
            <button
              key={preset.label}
              onClick={() => {
                const to = new Date();
                const from = new Date();
                from.setDate(from.getDate() - preset.days);
                const newFrom = from.toISOString().split("T")[0];
                const newTo = to.toISOString().split("T")[0];
                setDateFrom(newFrom);
                setDateTo(newTo);
                fetchData(newFrom, newTo);
              }}
              className={s.presetBtn}
            >
              {preset.label}
            </button>
          ))}
        </div>
      </div>

      {/* KPI */}
      <div className={s.kpiGrid}>
        {kpiCards.map((card) => (
          <div key={card.label} className={s.kpiCard}>
            <div className={s.kpiTop}>
              <div
                className={s.kpiIcon}
                style={{ background: card.bg, color: card.color }}
              >
                {card.icon}
              </div>
              <span className={s.kpiLabel}>{card.label}</span>
            </div>
            <p className={s.kpiValue}>{card.value}</p>
          </div>
        ))}
      </div>

      {/* Графіки ряд 1 */}
      <div className={s.chartsRow}>
        <div className={s.chartCard}>
          <h3 className={s.chartTitle}>Записи по місяцях</h3>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={data.monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Line type="monotone" dataKey="count" stroke="#2563eb" strokeWidth={2.5}
                dot={{ fill: "#2563eb", r: 4 }} name="Записів" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className={s.chartCard}>
          <h3 className={s.chartTitle}>Статуси записів</h3>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={data.appointmentsByStatus} dataKey="count" nameKey="status"
                cx="50%" cy="50%" innerRadius={50} outerRadius={80}>
                {data.appointmentsByStatus.map((entry, index) => (
                  <Cell key={entry.status} fill={STATUS_COLORS[entry.status] || COLORS[index]} />
                ))}
              </Pie>
              <Tooltip formatter={(value, name) => [value, STATUS_LABELS[name as string] || name]} />
            </PieChart>
          </ResponsiveContainer>
          <div className={s.statusLegend}>
            {data.appointmentsByStatus.map((item) => (
              <div key={item.status} className={s.statusItem}>
                <div className={s.statusLeft}>
                  <div className={s.statusDot} style={{ background: STATUS_COLORS[item.status] }} />
                  <span className={s.statusLabel}>{STATUS_LABELS[item.status]}</span>
                </div>
                <span className={s.statusCount}>{item.count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Графіки ряд 2 */}
      <div className={s.chartsRow2}>
        <div className={s.chartCard}>
          <h3 className={s.chartTitle}>Топ лікарів за записами</h3>
          <div className={s.doctorsList}>
            {data.topDoctors.map((doc, index) => (
              <div key={doc.name} className={s.doctorItem}>
                <span className={s.doctorRank}>{index + 1}</span>
                <div className={s.doctorInfo}>
                  <p className={s.doctorName}>{doc.name}</p>
                  <p className={s.doctorSpec}>{doc.specialization}</p>
                </div>
                <span className={s.doctorCount}>{doc.count}</span>
              </div>
            ))}
          </div>
        </div>

        <div className={s.chartCard}>
          <h3 className={s.chartTitle}>Популярні спеціалізації</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={data.topSpecializations} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
              <XAxis type="number" tick={{ fontSize: 11 }} />
              <YAxis dataKey="name" type="category" tick={{ fontSize: 11 }} width={80} />
              <Tooltip />
              <Bar dataKey="count" fill="#2563eb" radius={[0, 6, 6, 0]} name="Записів" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className={s.chartCard}>
          <h3 className={s.chartTitle}>Пікові години запису</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={data.peakHours}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
              <XAxis dataKey="hour" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="count" fill="#10b981" radius={[4, 4, 0, 0]} name="Записів" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsDashboard;