import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { specializationSchema, type SpecializationForm } from "../../validation/schemas";
import { getSpecializations, type Specialization } from "../../services/specializationService";
import api from "../../services/api";
import toast from "react-hot-toast";
import s from "../styles/SpecializationsTable.module.scss";

const SpecializationsTable = () => {
  const [specializations, setSpecializations] = useState<Specialization[]>([]);
  const [loading, setLoading] = useState(true);
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);

  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } =
    useForm<SpecializationForm>({ resolver: zodResolver(specializationSchema) });

  useEffect(() => {
    getSpecializations().then(setSpecializations).finally(() => setLoading(false));
  }, []);

  const openCreateModal = () => {
    setEditingId(null);
    reset({ name: "", description: "", shortDesc: "", imageUrl: "" });
    setShowModal(true);
  };

  const handleEdit = (item: Specialization) => {
    setEditingId(item.id);
    reset({
      name: item.name,
      description: item.description || "",
      shortDesc: (item as any).shortDesc || "",
      imageUrl: (item as any).imageUrl || "",
    });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingId(null);
    reset();
  };

  const onSubmit = async (data: SpecializationForm) => {
    try {
      if (editingId) {
        const res = await api.put(`/admin/specializations/${editingId}`, data);
        setSpecializations((prev) => prev.map((item) => item.id === editingId ? res.data : item));
        toast.success("Спеціалізацію оновлено!");
      } else {
        const res = await api.post("/admin/specializations", data);
        setSpecializations((prev) => [...prev, res.data]);
        toast.success("Спеціалізацію додано!");
      }
      closeModal();
    } catch {
      toast.error("Помилка при збереженні");
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await api.delete(`/admin/specializations/${id}`);
      setSpecializations((prev) => prev.filter((item) => item.id !== id));
      setConfirmId(null);
      toast.success("Спеціалізацію видалено!");
    } catch {
      toast.error("Помилка при видаленні");
    }
  };

  if (loading) return <p className={s.tdGray}>Завантаження...</p>;

  return (
    <div className={s.wrap}>
      <div className={s.header}>
        <h2 className={s.title}>Спеціалізації</h2>
        <button onClick={openCreateModal} className={s.btnAdd}>+ Додати</button>
      </div>

      {/* Модалка */}
      {showModal && (
        <div className={s.modal}>
          <div className={s.modalCard}>
            <h3 className={s.modalTitle}>
              {editingId ? "Редагувати спеціалізацію" : "Нова спеціалізація"}
            </h3>
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className={s.formGroup}>
                <input placeholder="Медична назва" {...register("name")} className={s.input} />
                {errors.name && <p className={s.errorMsg}>{errors.name.message}</p>}
              </div>
              <div className={s.formGroup}>
                <input placeholder="UX-назва" {...register("description")} className={s.input} />
              </div>
              <div className={s.formGroup}>
                <input placeholder="Короткий опис" {...register("shortDesc")} className={s.input} />
              </div>
              <div className={s.formGroup}>
                <input placeholder="URL фото" {...register("imageUrl")} className={s.input} />
              </div>
              <div className={s.modalBtns}>
                <button type="submit" disabled={isSubmitting} className={s.btnSave}>
                  {editingId ? "Оновити" : "Зберегти"}
                </button>
                <button type="button" onClick={closeModal} className={s.btnCancelForm}>
                  Скасувати
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Таблиця — десктоп */}
      <div className={s.tableWrap}>
        <table className={s.table}>
          <thead className={s.thead}>
            <tr>
              <th className={s.th}>ID</th>
              <th className={s.th}>Назва</th>
              <th className={s.th}>UX-назва</th>
              <th className={s.th}>Короткий опис</th>
              <th className={s.th}>Фото</th>
              <th className={s.th}>Дії</th>
            </tr>
          </thead>
          <tbody>
            {specializations.map((item) => (
              <tr key={item.id} className={s.tr}>
                <td className={`${s.td} ${s.tdGray}`}>{item.id}</td>
                <td className={s.td}><span className={s.name}>{item.name}</span></td>
                <td className={`${s.td} ${s.tdGray}`}>{item.description || "—"}</td>
                <td className={`${s.td} ${s.tdGray}`}
                  style={{ maxWidth: 200, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {(item as any).shortDesc || "—"}
                </td>
                <td className={s.td}>
                  {(item as any).imageUrl ? (
                    <img src={(item as any).imageUrl} alt={item.name} className={s.img} />
                  ) : (
                    <span className={s.tdGray}>—</span>
                  )}
                </td>
                <td className={s.td}>
                  <div className={s.actions}>
                    {confirmId === item.id ? (
                      <>
                        <button onClick={() => handleDelete(item.id)} className={s.btnConfirm}>Підтвердити</button>
                        <button onClick={() => setConfirmId(null)} className={s.btnCancelDel}>Скасувати</button>
                      </>
                    ) : (
                      <>
                        <button onClick={() => handleEdit(item)} className={s.btnEdit}>Редагувати</button>
                        <button onClick={() => setConfirmId(item.id)} className={s.btnDelete}>Видалити</button>
                      </>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Картки — мобільний */}
      <div className={s.cards}>
        {specializations.map((item) => (
          <div key={item.id} className={s.card}>
            {(item as any).imageUrl ? (
              <img src={(item as any).imageUrl} alt={item.name} className={s.cardImg} />
            ) : (
              <div className={s.cardImgPlaceholder}>🏥</div>
            )}
            <div className={s.cardBody}>
              <p className={s.cardName}>{item.name}</p>
              {item.description && <p className={s.cardDesc}>{item.description}</p>}
              {(item as any).shortDesc && <p className={s.cardShort}>{(item as any).shortDesc}</p>}
              <div className={s.cardActions}>
                <button onClick={() => handleEdit(item)} className={s.cardBtnEdit}>Редагувати</button>
                <button onClick={() => setConfirmId(item.id)} className={s.cardBtnDelete}>Видалити</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SpecializationsTable;