import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { specializationSchema, type SpecializationForm } from "../../validation/schemas";
import { getSpecializations } from "../../services/specializationService";
import type { Specialization } from "../../services/specializationService";
import api from "../../services/api";
import toast from "react-hot-toast";

const SpecializationsTable = () => {
  const [specializations, setSpecializations] = useState<Specialization[]>([]);
  const [loading, setLoading] = useState(true);
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const [showModal, setShowModal] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<SpecializationForm>({
    resolver: zodResolver(specializationSchema),
  });

  useEffect(() => {
    getSpecializations()
      .then(setSpecializations)
      .finally(() => setLoading(false));
  }, []);

  const onSubmit = async (data: SpecializationForm) => {
    try {
      const response = await api.post("/admin/specializations", data);
      setSpecializations([...specializations, response.data]);
      setShowModal(false);
      reset();
      toast.success("Спеціалізацію додано!");
    } catch {
      toast.error("Помилка при додаванні");
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await api.delete(`/admin/specializations/${id}`);
      setSpecializations(specializations.filter((s) => s.id !== id));
      setConfirmId(null);
      toast.success("Спеціалізацію видалено!");
    } catch {
      toast.error("Помилка при видаленні");
    }
  };

  if (loading) return <p className="text-gray-500">Завантаження...</p>;

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Спеціалізації</h2>
        <button
          onClick={() => setShowModal(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
        >
          + Додати
        </button>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-8 w-full max-w-md shadow-xl">
            <h3 className="text-xl font-bold mb-6">Нова спеціалізація</h3>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div>
                <input
                  type="text"
                  placeholder="Назва"
                  {...register("name")}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.name ? "border-red-500" : "border-gray-300"}`}
                />
                {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name.message}</p>}
              </div>
              <div>
                <input
                  type="text"
                  placeholder="Опис"
                  {...register("description")}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="flex gap-3 mt-6">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  {isSubmitting ? "Збереження..." : "Зберегти"}
                </button>
                <button
                  type="button"
                  onClick={() => { setShowModal(false); reset(); }}
                  className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300"
                >
                  Скасувати
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="text-left px-6 py-4 text-gray-500 font-medium">ID</th>
              <th className="text-left px-6 py-4 text-gray-500 font-medium">Назва</th>
              <th className="text-left px-6 py-4 text-gray-500 font-medium">Опис</th>
              <th className="text-left px-6 py-4 text-gray-500 font-medium">Дії</th>
            </tr>
          </thead>
          <tbody>
            {specializations.map((s) => (
              <tr key={s.id} className="border-b hover:bg-gray-50">
                <td className="px-6 py-4 text-gray-500">{s.id}</td>
                <td className="px-6 py-4 font-medium">{s.name}</td>
                <td className="px-6 py-4 text-gray-600">{s.description ?? "—"}</td>
                <td className="px-6 py-4">
                  {confirmId === s.id ? (
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleDelete(s.id)}
                        className="bg-red-500 text-white px-3 py-1 rounded-lg text-sm"
                      >
                        Підтвердити
                      </button>
                      <button
                        onClick={() => setConfirmId(null)}
                        className="bg-gray-200 text-gray-700 px-3 py-1 rounded-lg text-sm"
                      >
                        Скасувати
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setConfirmId(s.id)}
                      className="text-red-500 hover:text-red-700 text-sm"
                    >
                      Видалити
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SpecializationsTable;