import { useEffect, useState } from "react";
import { getAdminAppointments } from "../../services/adminService";

const AppointmentsTable = () => {
  const [appointments, setAppointments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getAdminAppointments()
      .then(setAppointments)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p className="text-gray-500">Завантаження...</p>;

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Записи</h2>
      </div>

      <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="text-left px-6 py-4 text-gray-500 font-medium">ID</th>
              <th className="text-left px-6 py-4 text-gray-500 font-medium">Пацієнт</th>
              <th className="text-left px-6 py-4 text-gray-500 font-medium">Лікар</th>
              <th className="text-left px-6 py-4 text-gray-500 font-medium">Дата</th>
              <th className="text-left px-6 py-4 text-gray-500 font-medium">Статус</th>
            </tr>
          </thead>
          <tbody>
            {appointments.map((a) => (
              <tr key={a.id} className="border-b hover:bg-gray-50">
                <td className="px-6 py-4 text-gray-500">{a.id}</td>
                <td className="px-6 py-4 font-medium">
                  {a.user.firstName} {a.user.lastName}
                </td>
                <td className="px-6 py-4 text-gray-600">
                  {a.doctor.firstName} {a.doctor.lastName}
                </td>
                <td className="px-6 py-4 text-gray-600">
                  {new Date(a.appointmentDate).toLocaleDateString("uk-UA")}
                </td>
                <td className="px-6 py-4">
                  <span className={`px-3 py-1 rounded-full text-sm ${
                    a.status === "CONFIRMED"
                      ? "bg-green-100 text-green-700"
                      : a.status === "CANCELLED"
                      ? "bg-red-100 text-red-700"
                      : "bg-yellow-100 text-yellow-700"
                  }`}>
                    {a.status === "CONFIRMED" ? "Підтверджено" : a.status === "CANCELLED" ? "Скасовано" : "Очікує"}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AppointmentsTable;