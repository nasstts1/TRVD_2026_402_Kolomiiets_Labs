import { useEffect, useState } from "react";
import { getAdminAppointments } from "../../services/adminService";
import toast from "react-hot-toast";
import api from "../../services/api";
import s from "../styles/AppointmentsTable.module.scss";

const statusLabel: Record<string, { label: string; cls: string }> = {
  PENDING: { label: "Очікує", cls: s.statusPending },
  CONFIRMED: { label: "Підтверджено", cls: s.statusConfirmed },
  CANCELLED: { label: "Скасовано", cls: s.statusCancelled },
};

const AppointmentsTable = () => {
  const [appointments, setAppointments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState("ALL");
  const [cancelModal, setCancelModal] = useState<number | null>(null);
  const [cancelReason, setCancelReason] = useState("");

  useEffect(() => {
    getAdminAppointments().then(setAppointments).finally(() => setLoading(false));
  }, []);

  const handleStatusChange = async (id: number, status: string) => {
    try {
      await api.patch(`/appointments/${id}/status`, { status });
      setAppointments(appointments.map((a) => a.id === id ? { ...a, status } : a));
      toast.success("Статус оновлено!");
    } catch {
      toast.error("Помилка при оновленні статусу");
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await api.delete(`/appointments/${id}`);
      setAppointments(appointments.filter((a) => a.id !== id));
      toast.success("Запис видалено!");
    } catch {
      toast.error("Помилка при видаленні");
    }
  };

  const handleCancel = async () => {
    if (!cancelModal) return;
    try {
      await api.patch(`/appointments/${cancelModal}/status`, {
        status: "CANCELLED",
        cancelReason: cancelReason.trim() || "Не вказано",
      });
      setAppointments(appointments.map((a) =>
        a.id === cancelModal ? { ...a, status: "CANCELLED" } : a
      ));
      toast.success("Запис скасовано, пацієнту надіслано лист!");
      setCancelModal(null);
      setCancelReason("");
    } catch {
      toast.error("Помилка при скасуванні");
    }
  };

  const filtered = filterStatus === "ALL"
    ? appointments
    : appointments.filter((a) => a.status === filterStatus);

  const counts = {
    ALL: appointments.length,
    PENDING: appointments.filter((a) => a.status === "PENDING").length,
    CONFIRMED: appointments.filter((a) => a.status === "CONFIRMED").length,
    CANCELLED: appointments.filter((a) => a.status === "CANCELLED").length,
  };

  const formatDate = (d: string) => new Date(d).toLocaleDateString("uk-UA", { timeZone: "UTC" });
  const formatTime = (d: string) => new Date(d).toLocaleTimeString("uk-UA", { hour: "2-digit", minute: "2-digit", timeZone: "UTC" });

  const renderActions = (a: any) => (
    <div className={s.actions}>
      {a.status === "PENDING" && (
        <div className={s.btnRow}>
          <button onClick={() => handleStatusChange(a.id, "CONFIRMED")} className={s.btnConfirm}>✓ Підтвердити</button>
          <button onClick={() => { setCancelModal(a.id); setCancelReason(""); }} className={s.btnCancel}>✕ Скасувати</button>
        </div>
      )}
      {a.status === "CONFIRMED" && (
        <button onClick={() => { setCancelModal(a.id); setCancelReason(""); }} className={s.btnCancel}>✕ Скасувати</button>
      )}
      <button onClick={() => handleDelete(a.id)} className={s.btnDelete}>Видалити</button>
    </div>
  );

  const renderPatient = (a: any) => a.guestName ? (
    <div>
      <p className={s.name}>{a.guestName}</p>
      <p className={s.sub}>{a.guestPhone ?? "—"}</p>
      <span className={s.guestBadge}>Гість</span>
    </div>
  ) : a.user ? (
    <div>
      <p className={s.name}>{a.user.firstName} {a.user.lastName}</p>
      <p className={s.sub}>{a.user.email}</p>
    </div>
  ) : <span className={s.tdGray}>—</span>;

  if (loading) return <p className={s.tdGray}>Завантаження...</p>;

  return (
    <div className={s.wrap}>
      <div className={s.header}>
        <h2 className={s.title}>Всі записи</h2>
        <span className={s.total}>Всього: {appointments.length}</span>
      </div>

      {/* Фільтри */}
      <div className={s.filters}>
        {[
          { key: "ALL", label: "Всі", count: counts.ALL },
          { key: "PENDING", label: "Очікують", count: counts.PENDING },
          { key: "CONFIRMED", label: "Підтверджені", count: counts.CONFIRMED },
          { key: "CANCELLED", label: "Скасовані", count: counts.CANCELLED },
        ].map((f) => (
          <button
            key={f.key}
            onClick={() => setFilterStatus(f.key)}
            className={`${s.filterBtn} ${filterStatus === f.key ? s.filterBtnActive : ""}`}
          >
            {f.label}
            {f.count > 0 && (
              <span className={`${s.filterCount} ${filterStatus === f.key ? s.filterCountActive : ""}`}>
                {f.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Таблиця — десктоп */}
      <div className={s.tableWrap}>
        <table className={s.table}>
          <thead className={s.thead}>
            <tr>
              <th className={s.th}>ID</th>
              <th className={s.th}>Пацієнт</th>
              <th className={s.th}>Лікар</th>
              <th className={s.th}>Дата і час</th>
              <th className={s.th}>Статус</th>
              <th className={s.th}>Дії</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={6} className={s.empty}>Записів не знайдено</td>
              </tr>
            ) : filtered.map((a) => (
              <tr key={a.id} className={s.tr}>
                <td className={`${s.td} ${s.tdGray}`}>{a.id}</td>
                <td className={s.td}>{renderPatient(a)}</td>
                <td className={s.td}>
                  <p className={s.name}>{a.doctor.firstName} {a.doctor.lastName}</p>
                  <p className={s.sub}>{a.doctor.specialization?.name}</p>
                </td>
                <td className={s.td}>
                  <p>{formatDate(a.appointmentDate)}</p>
                  <p className={s.sub}>{formatTime(a.appointmentDate)}</p>
                </td>
                <td className={s.td}>
                  <span className={`${s.statusBadge} ${statusLabel[a.status].cls}`}>
                    {statusLabel[a.status].label}
                  </span>
                </td>
                <td className={s.td}>{renderActions(a)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Картки — мобільний */}
      <div className={s.cards}>
        {filtered.length === 0 ? (
          <p className={s.empty}>Записів не знайдено</p>
        ) : filtered.map((a) => (
          <div key={a.id} className={s.card}>
            <div className={s.cardRow}>
              <div>
                <p className={s.cardLabel}>Пацієнт</p>
                <p className={s.cardValue}>
                  {a.guestName ?? (a.user ? `${a.user.firstName} ${a.user.lastName}` : "—")}
                </p>
                {a.guestName && <span className={s.guestBadge}>Гість</span>}
              </div>
              <span className={`${s.statusBadge} ${statusLabel[a.status].cls}`}>
                {statusLabel[a.status].label}
              </span>
            </div>
            <div className={s.cardRow}>
              <div>
                <p className={s.cardLabel}>Лікар</p>
                <p className={s.cardValue}>{a.doctor.firstName} {a.doctor.lastName}</p>
                <p className={s.cardSub}>{a.doctor.specialization?.name}</p>
              </div>
              <div style={{ textAlign: "right" }}>
                <p className={s.cardLabel}>Дата</p>
                <p className={s.cardValue}>{formatDate(a.appointmentDate)}</p>
                <p className={s.cardSub}>{formatTime(a.appointmentDate)}</p>
              </div>
            </div>
            <div className={s.cardActions}>
              {renderActions(a)}
            </div>
          </div>
        ))}
      </div>

      {/* Модалка */}
      {cancelModal && (
        <div className={s.modal}>
          <div className={s.modalCard}>
            <h3 className={s.modalTitle}>Скасування запису</h3>
            <p className={s.modalDesc}>Пацієнту буде надіслано лист з причиною скасування.</p>
            <label className={s.modalLabel}>Причина скасування</label>
            <select
              value={cancelReason}
              onChange={(e) => setCancelReason(e.target.value)}
              className={s.modalSelect}
            >
              <option value="">Оберіть причину...</option>
              <option value="Лікар захворів">Лікар захворів</option>
              <option value="Лікар у відпустці">Лікар у відпустці</option>
              <option value="Технічні проблеми в клініці">Технічні проблеми в клініці</option>
              <option value="Запис створено помилково">Запис створено помилково</option>
              <option value="Інша причина">Інша причина</option>
            </select>
            <textarea
              placeholder="Або введіть власну причину..."
              value={cancelReason}
              onChange={(e) => setCancelReason(e.target.value)}
              rows={3}
              className={s.modalTextarea}
            />
            <div className={s.modalBtns}>
              <button onClick={handleCancel} className={s.modalBtnCancel}>Скасувати запис</button>
              <button onClick={() => { setCancelModal(null); setCancelReason(""); }} className={s.modalBtnBack}>Назад</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AppointmentsTable;