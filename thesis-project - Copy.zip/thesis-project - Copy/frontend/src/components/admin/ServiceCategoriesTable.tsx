import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import api from "../../services/api";
import toast from "react-hot-toast";
import s from "../styles/ServiceCategoriesTable.module.scss";

const schema = z.object({
  name: z.string().min(2, "Мінімум 2 символи"),
  description: z.string().optional(),
  imageUrl: z.string().optional(),
});

type CategoryForm = z.infer<typeof schema>;

interface Category {
  id: number;
  name: string;
  description: string | null;
  imageUrl: string | null;
}

const ServiceCategoriesTable = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [confirmId, setConfirmId] = useState<number | null>(null);

  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } =
    useForm<CategoryForm>({ resolver: zodResolver(schema) });

  useEffect(() => {
    api.get("/admin/service-categories")
      .then((res) => setCategories(res.data))
      .finally(() => setLoading(false));
  }, []);

  const openCreate = () => {
    setEditingId(null);
    reset({ name: "", description: "", imageUrl: "" });
    setShowModal(true);
  };

  const openEdit = (item: Category) => {
    setEditingId(item.id);
    reset({ name: item.name, description: item.description || "", imageUrl: item.imageUrl || "" });
    setShowModal(true);
  };

  const onSubmit = async (data: CategoryForm) => {
    try {
      if (editingId) {
        const res = await api.put(`/admin/service-categories/${editingId}`, data);
        setCategories((prev) => prev.map((c) => c.id === editingId ? res.data : c));
        toast.success("Категорію оновлено!");
      } else {
        const res = await api.post("/admin/service-categories", data);
        setCategories((prev) => [...prev, res.data]);
        toast.success("Категорію додано!");
      }
      setShowModal(false);
      reset();
    } catch {
      toast.error("Помилка при збереженні");
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await api.delete(`/admin/service-categories/${id}`);
      setCategories((prev) => prev.filter((c) => c.id !== id));
      setConfirmId(null);
      toast.success("Категорію видалено!");
    } catch {
      toast.error("Помилка при видаленні");
    }
  };

  if (loading) return <p className={s.tdGray}>Завантаження...</p>;

  return (
    <div className={s.wrap}>
      <div className={s.header}>
        <h2 className={s.title}>Категорії послуг</h2>
        <button onClick={openCreate} className={s.btnAdd}>+ Додати</button>
      </div>

      {/* Модалка */}
      {showModal && (
        <div className={s.modal}>
          <div className={s.modalCard}>
            <h3 className={s.modalTitle}>{editingId ? "Редагувати" : "Нова категорія"}</h3>
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className={s.formGroup}>
                <input placeholder="Назва (УЗД, Аналізи...)" {...register("name")}
                  className={`${s.input} ${errors.name ? s.inputError : ""}`} />
                {errors.name && <p className={s.errorMsg}>{errors.name.message}</p>}
              </div>
              <div className={s.formGroup}>
                <textarea placeholder="Опис" {...register("description")} rows={3} className={s.textarea} />
              </div>
              <div className={s.formGroup}>
                <input placeholder="URL зображення (/services/category-1.jpg)"
                  {...register("imageUrl")} className={s.input} />
                <p className={s.hint}>Збережи фото в public/services/ і введи шлях</p>
              </div>
              <div className={s.modalBtns}>
                <button type="submit" disabled={isSubmitting} className={s.btnSave}>
                  {editingId ? "Оновити" : "Зберегти"}
                </button>
                <button type="button" onClick={() => { setShowModal(false); reset(); }} className={s.btnCancelForm}>
                  Скасувати
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Таблиця — десктоп */}
      <div className={s.tableWrap}>
        <table className={s.table}>
          <thead className={s.thead}>
            <tr>
              <th className={s.th}>ID</th>
              <th className={s.th}>Фото</th>
              <th className={s.th}>Назва</th>
              <th className={s.th}>Опис</th>
              <th className={s.th}>Дії</th>
            </tr>
          </thead>
          <tbody>
            {categories.map((c) => (
              <tr key={c.id} className={s.tr}>
                <td className={`${s.td} ${s.tdGray}`}>{c.id}</td>
                <td className={s.td}>
                  {c.imageUrl ? (
                    <img src={c.imageUrl} alt={c.name} className={s.img} />
                  ) : (
                    <div className={s.imgPlaceholder}>—</div>
                  )}
                </td>
                <td className={s.td}><span className={s.name}>{c.name}</span></td>
                <td className={`${s.td} ${s.tdGray}`}>{c.description ?? "—"}</td>
                <td className={s.td}>
                  {confirmId === c.id ? (
                    <div className={s.actions}>
                      <button onClick={() => handleDelete(c.id)} className={s.btnConfirm}>Підтвердити</button>
                      <button onClick={() => setConfirmId(null)} className={s.btnCancelDel}>Скасувати</button>
                    </div>
                  ) : (
                    <div className={s.actions}>
                      <button onClick={() => openEdit(c)} className={s.btnEdit}>Редагувати</button>
                      <button onClick={() => setConfirmId(c.id)} className={s.btnDelete}>Видалити</button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Картки — мобільний */}
      <div className={s.cards}>
        {categories.map((c) => (
          <div key={c.id} className={s.card}>
            {c.imageUrl ? (
              <img src={c.imageUrl} alt={c.name} className={s.cardImg} />
            ) : (
              <div className={s.cardImgPlaceholder}>—</div>
            )}
            <div className={s.cardBody}>
              <p className={s.cardName}>{c.name}</p>
              <p className={s.cardDesc}>{c.description ?? "Без опису"}</p>
              <div className={s.cardActions}>
                <button onClick={() => openEdit(c)} className={s.cardBtnEdit}>Редагувати</button>
                <button onClick={() => setConfirmId(c.id)} className={s.cardBtnDelete}>Видалити</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ServiceCategoriesTable;