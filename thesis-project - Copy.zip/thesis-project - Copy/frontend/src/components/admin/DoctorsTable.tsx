import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { doctorSchema, type DoctorForm } from "../../validation/schemas";
import { getAdminDoctors, deleteDoctor } from "../../services/adminService";
import { getSpecializations } from "../../services/specializationService";
import type { Specialization } from "../../services/specializationService";
import type { Doctor } from "../../types";
import api from "../../services/api";

const DoctorsTable = () => {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [specializations, setSpecializations] = useState<Specialization[]>([]);
  const [loading, setLoading] = useState(true);
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const [showModal, setShowModal] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<DoctorForm>({
    resolver: zodResolver(doctorSchema),
  });

  useEffect(() => {
    Promise.all([getAdminDoctors(), getSpecializations()])
      .then(([docs, specs]) => {
        setDoctors(docs);
        setSpecializations(specs);
      })
      .finally(() => setLoading(false));
  }, []);

  const handleDelete = async (id: number) => {
    try {
      await deleteDoctor(id);
      setDoctors(doctors.filter((d) => d.id !== id));
      setConfirmId(null);
      toast.success("Лікаря видалено!");
    } catch {
      toast.error("Помилка при видаленні");
    }
  };

  const onSubmit = async (data: DoctorForm) => {
    try {
      await api.post("/doctors", {
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email,
        phone: data.phone,
        specializationId: Number(data.specializationId),
      });
      const updatedDoctors = await getAdminDoctors();
      setDoctors(updatedDoctors);
      setShowModal(false);
      reset();
      toast.success("Лікаря успішно додано!");
    } catch {
      toast.error("Помилка при додаванні лікаря");
    }
  };

  if (loading) return <p className="text-gray-500">Завантаження...</p>;

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Лікарі</h2>
        <button
          onClick={() => setShowModal(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
        >
          + Додати лікаря
        </button>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-8 w-full max-w-md shadow-xl">
            <h3 className="text-xl font-bold mb-6">Новий лікар</h3>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div>
                <input
                  type="text"
                  placeholder="Ім'я"
                  {...register("firstName")}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.firstName ? "border-red-500" : "border-gray-300"}`}
                />
                {errors.firstName && <p className="text-red-500 text-sm mt-1">{errors.firstName.message}</p>}
              </div>
              <div>
                <input
                  type="text"
                  placeholder="Прізвище"
                  {...register("lastName")}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.lastName ? "border-red-500" : "border-gray-300"}`}
                />
                {errors.lastName && <p className="text-red-500 text-sm mt-1">{errors.lastName.message}</p>}
              </div>
              <div>
                <input
                  type="email"
                  placeholder="Email"
                  {...register("email")}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.email ? "border-red-500" : "border-gray-300"}`}
                />
                {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>}
              </div>
              <div>
                <input
                  type="text"
                  placeholder="Телефон (+380XXXXXXXXX)"
                  {...register("phone")}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.phone ? "border-red-500" : "border-gray-300"}`}
                />
                {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone.message}</p>}
              </div>
              <div>
                <select
                  {...register("specializationId")}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.specializationId ? "border-red-500" : "border-gray-300"}`}
                >
                  <option value="">Оберіть спеціалізацію</option>
                  {specializations.map((s) => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
                {errors.specializationId && <p className="text-red-500 text-sm mt-1">{errors.specializationId.message}</p>}
              </div>
              <div className="flex gap-3 mt-6">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  {isSubmitting ? "Збереження..." : "Зберегти"}
                </button>
                <button
                  type="button"
                  onClick={() => { setShowModal(false); reset(); }}
                  className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300"
                >
                  Скасувати
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="text-left px-6 py-4 text-gray-500 font-medium">ID</th>
              <th className="text-left px-6 py-4 text-gray-500 font-medium">Ім'я</th>
              <th className="text-left px-6 py-4 text-gray-500 font-medium">Email</th>
              <th className="text-left px-6 py-4 text-gray-500 font-medium">Спеціалізація</th>
              <th className="text-left px-6 py-4 text-gray-500 font-medium">Телефон</th>
              <th className="text-left px-6 py-4 text-gray-500 font-medium">Дії</th>
            </tr>
          </thead>
          <tbody>
            {doctors.map((doctor) => (
              <tr key={doctor.id} className="border-b hover:bg-gray-50">
                <td className="px-6 py-4 text-gray-500">{doctor.id}</td>
                <td className="px-6 py-4 font-medium">
                  {doctor.firstName} {doctor.lastName}
                </td>
                <td className="px-6 py-4 text-gray-600">{doctor.email}</td>
                <td className="px-6 py-4">
                  <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm">
                    {doctor.specialization.name}
                  </span>
                </td>
                <td className="px-6 py-4 text-gray-600">{doctor.phone ?? "—"}</td>
                <td className="px-6 py-4">
                  {confirmId === doctor.id ? (
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleDelete(doctor.id)}
                        className="bg-red-500 text-white px-3 py-1 rounded-lg text-sm hover:bg-red-600"
                      >
                        Підтвердити
                      </button>
                      <button
                        onClick={() => setConfirmId(null)}
                        className="bg-gray-200 text-gray-700 px-3 py-1 rounded-lg text-sm"
                      >
                        Скасувати
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setConfirmId(doctor.id)}
                      className="text-red-500 hover:text-red-700 text-sm"
                    >
                      Видалити
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DoctorsTable;