import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { doctorSchema, type DoctorForm } from "../../validation/schemas";
import { getAdminDoctors, deleteDoctor } from "../../services/adminService";
import { getSpecializations } from "../../services/specializationService";
import type { Specialization } from "../../services/specializationService";
import type { Doctor } from "../../types";
import api from "../../services/api";
import DoctorSchedule from "../../components/DoctorSchedule";
import s from "../styles/DoctorsTable.module.scss";

const DoctorsTable = () => {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [specializations, setSpecializations] = useState<Specialization[]>([]);
  const [loading, setLoading] = useState(true);
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);

  {/* шВИДКИЙ ЗАПИС */}
  const [showQuickBooking, setShowQuickBooking] = useState(false);
  const [quickBookingSpec, setQuickBookingSpec] = useState("");
  const [filteredDoctors, setFilteredDoctors] = useState<Doctor[]>([]);
  const [bookingDate, setBookingDate] = useState(new Date().toISOString().split("T")[0]);
  const [editingDoctor, setEditingDoctor] = useState<Doctor | null>(null);

  const [editEducation, setEditEducation] = useState<{
    type: "EDUCATION" | "TRAINING";
    institution: string;
    degree: string;
    year: string;
  }[]>([]);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<DoctorForm>({
    resolver: zodResolver(doctorSchema),
  });

  useEffect(() => {
    Promise.all([getAdminDoctors(), getSpecializations()])
      .then(([docs, specs]) => {
        setDoctors(docs);
        setSpecializations(specs);
      })
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
  if (quickBookingSpec) {
    // Фільтруємо завантажених лікарів за ID спеціалізації
    const filtered = doctors.filter(d => d.specialization.id === Number(quickBookingSpec));
    setFilteredDoctors(filtered);
  } else {
    setFilteredDoctors([]);
  }
}, [quickBookingSpec, doctors]);

  const handleDelete = async (id: number) => {
    try {
      await deleteDoctor(id);
      setDoctors(doctors.filter((d) => d.id !== id));
      setConfirmId(null);
      toast.success("Лікаря видалено!");
    } catch {
      toast.error("Помилка при видаленні");
    }
  };

  const onSubmit = async (data: DoctorForm) => {
  try {
    await api.post("/auth/register", {
      firstName: data.firstName,
      lastName: data.lastName,
      email: data.email,
      password: data.password,
      role: "DOCTOR",
    });

    await api.post("/doctors", {
      firstName: data.firstName,
      lastName: data.lastName,
      email: data.email,
      phone: data.phone,
      specializationId: Number(data.specializationId),
    });

    const updatedDoctors = await getAdminDoctors();
    setDoctors(updatedDoctors);
    setShowModal(false);
    reset();
    toast.success("Лікаря успішно додано!");
  } catch (error: any) {
    console.error("ERROR:", error?.response?.data);
    toast.error(error?.response?.data?.message || "Помилка при додаванні лікаря");
  }
};

  const {
    register: registerEdit,
    handleSubmit: handleSubmitEdit,
    reset: resetEdit,
    formState: {isSubmitting: isSubmittingEdit },
  } = useForm<any>();

  const openEdit = (doctor: Doctor) => {
    setEditingDoctor(doctor);
    resetEdit({
      firstName: doctor.firstName,
      lastName: doctor.lastName,
      phone: doctor.phone || "",
      photoUrl: doctor.photoUrl || "",
      experience: doctor.experience ?? "",
      bio: doctor.bio || "",
      category: doctor.category || "",
    });
    setEditEducation(
      (doctor.education ?? []).map((e) => ({
        type: e.type,
        institution: e.institution,
        degree: e.degree || "",
        year: e.year ? String(e.year) : "",
      }))
    );
  };

  const onEditSubmit = async (data: any) => {
    try {
      const response = await api.patch(`/doctors/${editingDoctor!.id}`, {
        ...data,
        education: editEducation.map((e) => ({
          ...e,
          year: e.year ? Number(e.year) : null,
        })),
      });
      setDoctors(doctors.map((d) =>
        d.id === editingDoctor!.id ? response.data : d
      ));
      setEditingDoctor(null);
      toast.success("Лікаря оновлено!");
    } catch {
      toast.error("Помилка при оновленні");
    }
  };

  if (loading) return <p className="text-gray-500">Завантаження...</p>;

  return (
  <div className={s.wrap}>
    <div className={s.header}>
      <h2 className={s.title}>Лікарі</h2>
      <div className={s.headerBtns}>
        <button onClick={() => setShowQuickBooking(true)} className={s.btnGreen}>
          Швидкий запис
        </button>
        <button onClick={() => setShowModal(true)} className={s.btnBlue}>
          + Додати лікаря
        </button>
      </div>
    </div>

    {/* Модалка редагування */}
    {editingDoctor && (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl w-full max-w-2xl shadow-xl max-h-[90vh] overflow-y-auto">
          <div className="sticky top-0 bg-white p-6 border-b flex justify-between items-center">
            <h3 className="text-xl font-bold">Редагувати лікаря</h3>
            <button onClick={() => setEditingDoctor(null)} className="text-gray-400 hover:text-gray-600 text-2xl">✕</button>
          </div>
          <form onSubmit={handleSubmitEdit(onEditSubmit)} className="p-6 space-y-6">
            <div>
              <h4 className="font-semibold text-gray-700 mb-3">Основна інформація</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Ім'я</label>
                  <input type="text" {...registerEdit("firstName")}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Прізвище</label>
                  <input type="text" {...registerEdit("lastName")}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Телефон</label>
                  <input type="text" {...registerEdit("phone")} placeholder="+380XXXXXXXXX"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">URL фото</label>
                  <input type="text" {...registerEdit("photoUrl")} placeholder="/doctors/doctor-1.jpg"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Досвід (років)</label>
                  <input type="number" {...registerEdit("experience")} placeholder="10"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Категорія</label>
                  <select {...registerEdit("category")}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">Без категорії</option>
                    <option value="Вища категорія">Вища категорія</option>
                    <option value="Перша категорія">Перша категорія</option>
                    <option value="Друга категорія">Друга категорія</option>
                  </select>
                </div>
              </div>
              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">Про лікаря</label>
                <textarea {...registerEdit("bio")} rows={3} placeholder="Короткий опис..."
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none" />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-3">
                <h4 className="font-semibold text-gray-700">Освіта та тренінги</h4>
                <button type="button"
                  onClick={() => setEditEducation([...editEducation, { type: "EDUCATION", institution: "", degree: "", year: "" }])}
                  className="text-blue-600 text-sm hover:text-blue-800">
                  + Додати
                </button>
              </div>
              <div className="space-y-3">
                {editEducation.map((edu, index) => (
                  <div key={index} className="border border-gray-200 rounded-xl p-4 space-y-3">
                    <div className="flex justify-between items-center">
                      <select value={edu.type}
                        onChange={(e) => {
                          const updated = [...editEducation];
                          updated[index].type = e.target.value as "EDUCATION" | "TRAINING";
                          setEditEducation(updated);
                        }}
                        className="border border-gray-300 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="EDUCATION">Освіта</option>
                        <option value="TRAINING">Тренінг/Курс</option>
                      </select>
                      <button type="button"
                        onClick={() => setEditEducation(editEducation.filter((_, i) => i !== index))}
                        className="text-red-500 hover:text-red-700 text-sm">
                        Видалити
                      </button>
                    </div>
                    <input type="text" placeholder="Назва закладу / курсу" value={edu.institution}
                      onChange={(e) => {
                        const updated = [...editEducation];
                        updated[index].institution = e.target.value;
                        setEditEducation(updated);
                      }}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                    <div className="grid grid-cols-2 gap-3">
                      <input type="text" placeholder="Спеціальність / назва курсу" value={edu.degree}
                        onChange={(e) => {
                          const updated = [...editEducation];
                          updated[index].degree = e.target.value;
                          setEditEducation(updated);
                        }}
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                      <input type="number" placeholder="Рік" value={edu.year}
                        onChange={(e) => {
                          const updated = [...editEducation];
                          updated[index].year = e.target.value;
                          setEditEducation(updated);
                        }}
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <button type="submit" disabled={isSubmittingEdit}
                className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50">
                {isSubmittingEdit ? "Збереження..." : "Зберегти"}
              </button>
              <button type="button" onClick={() => setEditingDoctor(null)}
                className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg">
                Скасувати
              </button>
            </div>
          </form>
        </div>
      </div>
    )}

    {/* Модалка додавання */}
    {showModal && (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-xl">
          <h3 className="text-xl font-bold mb-6">Новий лікар</h3>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <input type="text" placeholder="Ім'я" {...register("firstName")}
                className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.firstName ? "border-red-500" : "border-gray-300"}`} />
              {errors.firstName && <p className="text-red-500 text-sm mt-1">{errors.firstName.message}</p>}
            </div>
            <div>
              <input type="text" placeholder="Прізвище" {...register("lastName")}
                className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.lastName ? "border-red-500" : "border-gray-300"}`} />
              {errors.lastName && <p className="text-red-500 text-sm mt-1">{errors.lastName.message}</p>}
            </div>
            <div>
              <input type="email" placeholder="Email" {...register("email")}
                className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.email ? "border-red-500" : "border-gray-300"}`} />
              {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>}
            </div>
            <div>
              <input type="password" placeholder="Пароль (мінімум 8 символів)" {...register("password")}
                className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.password ? "border-red-500" : "border-gray-300"}`} />
              {errors.password && <p className="text-red-500 text-sm mt-1">{errors.password.message}</p>}
            </div>
            <div>
              <input type="text" placeholder="Телефон (+380XXXXXXXXX)" {...register("phone")}
                className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.phone ? "border-red-500" : "border-gray-300"}`} />
              {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone.message}</p>}
            </div>
            <div>
              <select {...register("specializationId")}
                className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.specializationId ? "border-red-500" : "border-gray-300"}`}>
                <option value="">Оберіть спеціалізацію</option>
                {specializations.map((spec) => (
                  <option key={spec.id} value={spec.id}>{spec.name}</option>
                ))}
              </select>
              {errors.specializationId && <p className="text-red-500 text-sm mt-1">{errors.specializationId.message}</p>}
            </div>
            <div className="flex gap-3 mt-6">
              <button type="submit" disabled={isSubmitting}
                className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50">
                {isSubmitting ? "Збереження..." : "Зберегти"}
              </button>
              <button type="button" onClick={() => { setShowModal(false); reset(); }}
                className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg">
                Скасувати
              </button>
            </div>
          </form>
        </div>
      </div>
    )}

    {/* Модалка швидкого запису */}
    {showQuickBooking && (
      <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[60] p-4 backdrop-blur-sm">
        <div className="bg-gray-50 rounded-2xl w-full max-w-5xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
          <div className="bg-white p-6 border-b flex justify-between items-center">
            <h3 className="text-xl font-bold">Швидкий пошук вільного часу</h3>
            <button onClick={() => setShowQuickBooking(false)} className="text-gray-400 hover:text-gray-600 text-2xl">✕</button>
          </div>
          <div className="p-4 sm:p-6 bg-white border-b flex flex-wrap gap-4">
            <div className="flex-1 min-w-[200px]">
              <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Спеціалізація</label>
              <select className="w-full border rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-500"
                value={quickBookingSpec} onChange={(e) => setQuickBookingSpec(e.target.value)}>
                <option value="">Оберіть напрямок...</option>
                {specializations.map(spec => <option key={spec.id} value={spec.id}>{spec.name}</option>)}
              </select>
            </div>
            <div className="w-full sm:w-48">
              <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Дата</label>
              <input type="date" className="w-full border rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-500"
                value={bookingDate} onChange={(e) => setBookingDate(e.target.value)} />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
            {filteredDoctors.length > 0 ? (
              filteredDoctors.map(doc => (
                <div key={doc.id} className="bg-white border rounded-2xl p-4 sm:p-6 shadow-sm">
                  <div className="flex items-center gap-4 mb-4 border-b pb-4">
                    <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold flex-shrink-0">
                      {doc.firstName[0]}{doc.lastName[0]}
                    </div>
                    <h4 className="font-bold">{doc.firstName} {doc.lastName}</h4>
                  </div>
                  <DoctorSchedule doctor={doc} workDays={doc.workDays || [1,2,3,4,5]}
                    breakStart={doc.breakStart || "13:00"} breakEnd={doc.breakEnd || "14:00"}
                    endpoint="/appointments/admin" />
                </div>
              ))
            ) : (
              <div className="text-center py-16 text-gray-400 border-2 border-dashed rounded-2xl bg-white">
                {quickBookingSpec ? "Лікарів не знайдено" : "Оберіть спеціалізацію для пошуку"}
              </div>
            )}
          </div>
        </div>
      </div>
    )}

    {/* Модалка перегляду */}
    {selectedDoctor && (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl w-full max-w-4xl shadow-xl max-h-[95vh] overflow-y-auto">
          <div className="flex justify-between items-center p-6 border-b sticky top-0 bg-white z-10">
            <h3 className="text-xl font-bold">Картка лікаря та розклад</h3>
            <button onClick={() => setSelectedDoctor(null)} className="text-gray-400 hover:text-gray-600 text-2xl">✕</button>
          </div>
          <div className="p-4 sm:p-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
              <div className="lg:col-span-1 space-y-6">
                <div className="flex flex-col items-center text-center p-6 bg-gray-50 rounded-2xl">
                  <div className="w-20 h-20 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-2xl font-bold mb-4">
                    {selectedDoctor.firstName[0]}{selectedDoctor.lastName[0]}
                  </div>
                  <h4 className="font-bold text-lg">{selectedDoctor.firstName} {selectedDoctor.lastName}</h4>
                  <span className="mt-2 bg-blue-600 text-white px-4 py-1 rounded-full text-sm">
                    {selectedDoctor.specialization.name}
                  </span>
                </div>
                <div className="space-y-4 px-2">
                  <div>
                    <span className="text-xs text-gray-400 uppercase font-bold">Email</span>
                    <p className="text-gray-700 font-medium mt-1">{selectedDoctor.email}</p>
                  </div>
                  <div>
                    <span className="text-xs text-gray-400 uppercase font-bold">Телефон</span>
                    <p className="text-gray-700 font-medium mt-1">{selectedDoctor.phone ?? "—"}</p>
                  </div>
                </div>
              </div>
              <div className="lg:col-span-2 bg-white border border-gray-100 rounded-xl p-4 sm:p-6">
                <DoctorSchedule doctor={selectedDoctor} workDays={selectedDoctor.workDays}
                  breakStart={selectedDoctor.breakStart} breakEnd={selectedDoctor.breakEnd}
                  hideBooked={true} endpoint="/appointments/admin" />
              </div>
            </div>
          </div>
        </div>
      </div>
    )}

    {/* Таблиця — десктоп */}
    <div className={s.tableWrap}>
      <table className={s.table}>
        <thead className={s.thead}>
          <tr>
            <th className={s.th}>ID</th>
            <th className={s.th}>Ім'я</th>
            <th className={s.th}>Email</th>
            <th className={s.th}>Спеціалізація</th>
            <th className={s.th}>Телефон</th>
            <th className={s.th}>Дії</th>
          </tr>
        </thead>
        <tbody>
          {doctors.map((doctor) => (
            <tr key={doctor.id} className={s.tr}>
              <td className={`${s.td} ${s.tdGray}`}>{doctor.id}</td>
              <td className={s.td}>
                <p className={s.name}>{doctor.firstName} {doctor.lastName}</p>
              </td>
              <td className={`${s.td} ${s.tdGray}`}>{doctor.email}</td>
              <td className={s.td}>
                <span className={s.specBadge}>{doctor.specialization.name}</span>
              </td>
              <td className={`${s.td} ${s.tdGray}`}>{doctor.phone ?? "—"}</td>
              <td className={s.td}>
                <div className={s.actions}>
                  <button onClick={() => setSelectedDoctor(doctor)} className={s.btnView}>Переглянути</button>
                  <button onClick={() => openEdit(doctor)} className={s.btnEdit}>Редагувати</button>
                  {confirmId === doctor.id ? (
                    <>
                      <button onClick={() => handleDelete(doctor.id)} className={s.btnConfirmDelete}>Підтвердити</button>
                      <button onClick={() => setConfirmId(null)} className={s.btnCancelDelete}>Скасувати</button>
                    </>
                  ) : (
                    <button onClick={() => setConfirmId(doctor.id)} className={s.btnDelete}>Видалити</button>
                  )}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>

    {/* Картки — мобільний */}
    <div className={s.cards}>
      {doctors.map((doctor) => (
        <div key={doctor.id} className={s.card}>
          <div className={s.cardTop}>
            <div>
              <p className={s.cardName}>{doctor.firstName} {doctor.lastName}</p>
              <p className={s.cardSub}>{doctor.email}</p>
              <p className={s.cardSub}>{doctor.phone ?? "—"}</p>
            </div>
            <span className={s.specBadge}>{doctor.specialization.name}</span>
          </div>
          <div className={s.cardActions}>
            <button onClick={() => setSelectedDoctor(doctor)} className={`${s.cardActionBtn} ${s.cardActionView}`}>Переглянути</button>
            <button onClick={() => openEdit(doctor)} className={`${s.cardActionBtn} ${s.cardActionEdit}`}>Редагувати</button>
            <button onClick={() => setConfirmId(doctor.id)} className={`${s.cardActionBtn} ${s.cardActionDelete}`}>Видалити</button>
          </div>
        </div>
      ))}
    </div>
  </div>
);
};

export default DoctorsTable;