import { useEffect, useState } from "react";
import api from "../../services/api";
import toast from "react-hot-toast";
import s from "../styles/ReviewsTable.module.scss";

interface Review {
  id: number;
  rating: number;
  comment: string;
  isVisible: boolean;
  createdAt: string;
  user: { firstName: string; lastName: string };
  doctor: { firstName: string; lastName: string; specialization: { name: string } };
}

const ReviewsTable = () => {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get("/reviews/all")
      .then((res) => setReviews(res.data))
      .catch(() => toast.error("Помилка завантаження відгуків"))
      .finally(() => setLoading(false));
  }, []);

  const toggleVisibility = async (id: number, current: boolean) => {
    try {
      await api.patch(`/reviews/${id}/visibility`, { isVisible: !current });
      setReviews((prev) => prev.map((r) => r.id === id ? { ...r, isVisible: !current } : r));
      toast.success(current ? "Відгук приховано" : "Відгук опубліковано");
    } catch {
      toast.error("Помилка");
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await api.delete(`/reviews/${id}`);
      setReviews((prev) => prev.filter((r) => r.id !== id));
      toast.success("Відгук видалено");
    } catch {
      toast.error("Помилка при видаленні");
    }
  };

  if (loading) return <p className={s.stats}>Завантаження...</p>;

  return (
    <div className={s.wrap}>
      <div className={s.header}>
        <h2 className={s.title}>Відгуки</h2>
        <span className={s.stats}>
          Всього: {reviews.length} | Опубліковано: {reviews.filter(r => r.isVisible).length}
        </span>
      </div>

      {reviews.length === 0 ? (
        <div className={s.empty}>Відгуків ще немає</div>
      ) : (
        <div className={s.list}>
          {reviews.map((review) => (
            <div key={review.id} className={`${s.card} ${review.isVisible ? s.cardVisible : ""}`}>
              <div className={s.cardTop}>
                <div className={s.cardLeft}>
                  <div className={s.userRow}>
                    <div className={s.avatar}>
                      {review.user.firstName[0]}{review.user.lastName[0]}
                    </div>
                    <div>
                      <p className={s.userName}>{review.user.firstName} {review.user.lastName}</p>
                      <p className={s.userDate}>{new Date(review.createdAt).toLocaleDateString("uk-UA")}</p>
                    </div>
                    <div className={s.stars}>
                      {[1,2,3,4,5].map((star) => (
                        <span key={star} className={star <= review.rating ? s.starFilled : s.starEmpty}>★</span>
                      ))}
                      <span className={s.ratingNum}>{review.rating}/5</span>
                    </div>
                  </div>

                  <p className={s.comment}>{review.comment}</p>

                  <div className={s.doctorRow}>
                    <span>👨‍⚕️</span>
                    <span>{review.doctor.firstName} {review.doctor.lastName}</span>
                    <span className={s.doctorBadge}>{review.doctor.specialization.name}</span>
                  </div>
                </div>

                <div className={s.actions}>
                  <button
                    onClick={() => toggleVisibility(review.id, review.isVisible)}
                    className={`${s.btnToggle} ${review.isVisible ? s.btnHide : s.btnPublish}`}
                  >
                    {review.isVisible ? "Приховати" : "Опублікувати"}
                  </button>
                  <button onClick={() => handleDelete(review.id)} className={s.btnDelete}>
                    Видалити
                  </button>
                </div>
              </div>

              <div className={s.cardFooter}>
                <span className={`${s.statusBadge} ${review.isVisible ? s.statusVisible : s.statusHidden}`}>
                  {review.isVisible ? "✓ Опубліковано на сайті" : "○ Приховано"}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ReviewsTable;