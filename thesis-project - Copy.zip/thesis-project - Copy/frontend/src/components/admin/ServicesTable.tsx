import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import api from "../../services/api";
import toast from "react-hot-toast";
import type { Specialization } from "../../services/specializationService";
import { getSpecializations } from "../../services/specializationService";
import s from "../styles/ServicesTable.module.scss";

const schema = z.object({
  name: z.string().min(2, "Мінімум 2 символи"),
  description: z.string().optional(),
  price: z.string().optional(),
  duration: z.string().optional(),
  categoryId: z.string().min(1, "Оберіть категорію"),
  specializationId: z.string().min(1, "Оберіть спеціалізацію"),
});

type ServiceForm = z.infer<typeof schema>;

interface Category { id: number; name: string; }
interface Service {
  id: number;
  name: string;
  description: string | null;
  price: number | null;
  duration: number | null;
  category: Category;
  specialization: { id: number; name: string };
}

const ServicesTable = () => {
  const [services, setServices] = useState<Service[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [specializations, setSpecializations] = useState<Specialization[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [confirmId, setConfirmId] = useState<number | null>(null);

  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } =
    useForm<ServiceForm>({ resolver: zodResolver(schema) });

  useEffect(() => {
    Promise.all([
      api.get("/admin/services"),
      api.get("/admin/service-categories"),
      getSpecializations(),
    ]).then(([servRes, catRes, specs]) => {
      setServices(servRes.data);
      setCategories(catRes.data);
      setSpecializations(specs);
    }).finally(() => setLoading(false));
  }, []);

  const openCreate = () => {
    setEditingId(null);
    reset({ name: "", description: "", price: "", duration: "", categoryId: "", specializationId: "" });
    setShowModal(true);
  };

  const openEdit = (item: Service) => {
    setEditingId(item.id);
    reset({
      name: item.name,
      description: item.description || "",
      price: item.price?.toString() || "",
      duration: item.duration?.toString() || "",
      categoryId: item.category.id.toString(),
      specializationId: item.specialization.id.toString(),
    });
    setShowModal(true);
  };

  const onSubmit = async (data: ServiceForm) => {
    try {
      if (editingId) {
        const res = await api.put(`/admin/services/${editingId}`, data);
        setServices((prev) => prev.map((item) => item.id === editingId ? res.data : item));
        toast.success("Послугу оновлено!");
      } else {
        const res = await api.post("/admin/services", data);
        setServices((prev) => [...prev, res.data]);
        toast.success("Послугу додано!");
      }
      setShowModal(false);
      reset();
    } catch {
      toast.error("Помилка при збереженні");
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await api.delete(`/admin/services/${id}`);
      setServices((prev) => prev.filter((item) => item.id !== id));
      setConfirmId(null);
      toast.success("Послугу видалено!");
    } catch {
      toast.error("Помилка при видаленні");
    }
  };

  if (loading) return <p className={s.tdGray}>Завантаження...</p>;

  return (
    <div className={s.wrap}>
      <div className={s.header}>
        <h2 className={s.title}>Послуги</h2>
        <button onClick={openCreate} className={s.btnAdd}>+ Додати послугу</button>
      </div>

      {/* Модалка */}
      {showModal && (
        <div className={s.modal}>
          <div className={s.modalCard}>
            <h3 className={s.modalTitle}>{editingId ? "Редагувати послугу" : "Нова послуга"}</h3>
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className={s.formGroup}>
                <input placeholder="Назва послуги" {...register("name")}
                  className={`${s.input} ${errors.name ? s.inputError : ""}`} />
                {errors.name && <p className={s.errorMsg}>{errors.name.message}</p>}
              </div>
              <div className={s.formGroup}>
                <textarea placeholder="Опис" {...register("description")} rows={2} className={s.textarea} />
              </div>
              <div className={s.formRow}>
                <input placeholder="Ціна (грн)" type="number" {...register("price")} className={s.input} />
                <input placeholder="Тривалість (хв)" type="number" {...register("duration")} className={s.input} />
              </div>
              <div className={s.formGroup}>
                <select {...register("categoryId")}
                  className={`${s.select} ${errors.categoryId ? s.inputError : ""}`}>
                  <option value="">Оберіть категорію</option>
                  {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
                {errors.categoryId && <p className={s.errorMsg}>{errors.categoryId.message}</p>}
              </div>
              <div className={s.formGroup}>
                <select {...register("specializationId")}
                  className={`${s.select} ${errors.specializationId ? s.inputError : ""}`}>
                  <option value="">Оберіть спеціалізацію</option>
                  {specializations.map((spec) => <option key={spec.id} value={spec.id}>{spec.name}</option>)}
                </select>
                {errors.specializationId && <p className={s.errorMsg}>{errors.specializationId.message}</p>}
              </div>
              <div className={s.modalBtns}>
                <button type="submit" disabled={isSubmitting} className={s.btnSave}>
                  {editingId ? "Оновити" : "Зберегти"}
                </button>
                <button type="button" onClick={() => { setShowModal(false); reset(); }} className={s.btnCancelForm}>
                  Скасувати
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Таблиця — десктоп */}
      <div className={s.tableWrap}>
        <table className={s.table}>
          <thead className={s.thead}>
            <tr>
              <th className={s.th}>ID</th>
              <th className={s.th}>Назва</th>
              <th className={s.th}>Категорія</th>
              <th className={s.th}>Спеціалізація</th>
              <th className={s.th}>Ціна</th>
              <th className={s.th}>Тривалість</th>
              <th className={s.th}>Дії</th>
            </tr>
          </thead>
          <tbody>
            {services.map((item) => (
              <tr key={item.id} className={s.tr}>
                <td className={`${s.td} ${s.tdGray}`}>{item.id}</td>
                <td className={s.td}><span className={s.name}>{item.name}</span></td>
                <td className={`${s.td} ${s.tdGray}`}>{item.category.name}</td>
                <td className={s.td}>
                  <span className={s.specBadge}>{item.specialization.name}</span>
                </td>
                <td className={`${s.td} ${s.tdGray}`}>{item.price ? `${item.price} грн` : "—"}</td>
                <td className={`${s.td} ${s.tdGray}`}>{item.duration ? `${item.duration} хв` : "—"}</td>
                <td className={s.td}>
                  {confirmId === item.id ? (
                    <div className={s.actions}>
                      <button onClick={() => handleDelete(item.id)} className={s.btnConfirm}>Підтвердити</button>
                      <button onClick={() => setConfirmId(null)} className={s.btnCancelDel}>Скасувати</button>
                    </div>
                  ) : (
                    <div className={s.actions}>
                      <button onClick={() => openEdit(item)} className={s.btnEdit}>Редагувати</button>
                      <button onClick={() => setConfirmId(item.id)} className={s.btnDelete}>Видалити</button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Картки — мобільний */}
      <div className={s.cards}>
        {services.map((item) => (
          <div key={item.id} className={s.card}>
            <div className={s.cardTop}>
              <p className={s.cardName}>{item.name}</p>
              <span className={s.specBadge}>{item.specialization.name}</span>
            </div>
            <div className={s.cardMeta}>
              <span className={s.cardMetaItem}>🗂 {item.category.name}</span>
              {item.price && <span className={s.cardMetaItem}>💰 {item.price} грн</span>}
              {item.duration && <span className={s.cardMetaItem}>⏱ {item.duration} хв</span>}
            </div>
            <div className={s.cardActions}>
              <button onClick={() => openEdit(item)} className={s.cardBtnEdit}>Редагувати</button>
              <button onClick={() => setConfirmId(item.id)} className={s.cardBtnDelete}>Видалити</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ServicesTable;