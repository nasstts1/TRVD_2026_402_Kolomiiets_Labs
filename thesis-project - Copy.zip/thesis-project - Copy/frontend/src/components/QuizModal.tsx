import { useEffect, useState } from "react";
import api from "../services/api";
import { useNavigate } from "react-router-dom";
import s from "./styles/QuizModal.module.scss";

interface Option { id: number; text: string; order: number; }
interface Question { id: number; question: string; type: "SINGLE" | "MULTIPLE"; options: Option[]; }
interface Symptom { id: number; name: string; description?: string; questions: Question[]; }
interface RecommendResult {
  specializations: { id: number; name: string; score: number }[];
  doctors: { id: number; firstName: string; lastName: string; photoUrl: string | null; specialization: { id: number; name: string }; }[];
}
interface Props { onClose: () => void; }

const QuizModal = ({ onClose }: Props) => {
  const navigate = useNavigate();
  const [symptoms, setSymptoms] = useState<Symptom[]>([]);
  const [selectedSymptom, setSelectedSymptom] = useState<Symptom | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOptions, setSelectedOptions] = useState<number[]>([]);
  const [result, setResult] = useState<RecommendResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [step, setStep] = useState<"symptom" | "questions" | "result">("symptom");

  useEffect(() => {
    api.get("/quiz/symptoms").then((res) => setSymptoms(res.data)).finally(() => setLoading(false));
  }, []);

  const handleSymptomSelect = (symptom: Symptom) => {
    setSelectedSymptom(symptom);
    setCurrentQuestionIndex(0);
    setSelectedOptions([]);
    setStep("questions");
  };

  const currentQuestion = selectedSymptom?.questions[currentQuestionIndex];

  const handleOptionToggle = (optionId: number) => {
    if (currentQuestion?.type === "SINGLE") {
      setSelectedOptions((prev) => {
        const questionOptionIds = currentQuestion.options.map((o) => o.id);
        const filtered = prev.filter((id) => !questionOptionIds.includes(id));
        return [...filtered, optionId];
      });
    } else {
      setSelectedOptions((prev) =>
        prev.includes(optionId) ? prev.filter((id) => id !== optionId) : [...prev, optionId]
      );
    }
  };

  const isOptionSelected = (optionId: number) => selectedOptions.includes(optionId);

  const handleNext = async () => {
    if (!selectedSymptom) return;
    const isLast = currentQuestionIndex === selectedSymptom.questions.length - 1;
    if (isLast) {
      setSubmitting(true);
      try {
        const res = await api.post("/quiz/recommend", { selectedOptionIds: selectedOptions });
        setResult(res.data);
        setStep("result");
      } finally {
        setSubmitting(false);
      }
    } else {
      setCurrentQuestionIndex((prev) => prev + 1);
    }
  };

  const handleBack = () => {
    if (currentQuestionIndex === 0) {
      setStep("symptom");
      setSelectedSymptom(null);
    } else {
      setCurrentQuestionIndex((prev) => prev - 1);
    }
  };

  const progress = selectedSymptom
    ? Math.round(((currentQuestionIndex + 1) / selectedSymptom.questions.length) * 100)
    : 0;

  return (
    <div className={s.overlay}>
      <div className={s.modal}>
        <div className={s.modalHeader}>
          <div className={s.headerLeft}>
            <span className={s.headerIcon}>🩺</span>
            <h3 className={s.headerTitle}>Підібрати лікаря</h3>
          </div>
          <button onClick={onClose} className={s.closeBtn}>✕</button>
        </div>

        <div className={s.body}>
          {loading && <p className={s.loading}>Завантаження...</p>}

          {/* Крок 1 */}
          {!loading && step === "symptom" && (
            <div>
              <p className={s.stepDesc}>Оберіть симптом або проблему яка вас турбує:</p>
              <div className={s.symptomsGrid}>
                {symptoms.map((symptom) => (
                  <button key={symptom.id} onClick={() => handleSymptomSelect(symptom)} className={s.symptomBtn}>
                    <p className={s.symptomName}>{symptom.name}</p>
                    {symptom.description && <p className={s.symptomDesc}>{symptom.description}</p>}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Крок 2 */}
          {!loading && step === "questions" && currentQuestion && (
            <div>
              <div className={s.progressWrap}>
                <div className={s.progressTop}>
                  <span>{selectedSymptom?.name}</span>
                  <span>{currentQuestionIndex + 1} / {selectedSymptom?.questions.length}</span>
                </div>
                <div className={s.progressBar}>
                  <div className={s.progressFill} style={{ width: `${progress}%` }} />
                </div>
              </div>

              <h4 className={s.question}>{currentQuestion.question}</h4>

              <div className={s.options}>
                {currentQuestion.options.map((option) => (
                  <button
                    key={option.id}
                    onClick={() => handleOptionToggle(option.id)}
                    className={`${s.optionBtn} ${isOptionSelected(option.id) ? s.optionBtnActive : ""}`}
                  >
                    <div className={`
                      ${s.optionCheck}
                      ${currentQuestion.type === "SINGLE" ? s.optionCheckRound : s.optionCheckSquare}
                      ${isOptionSelected(option.id) ? s.optionCheckActive : ""}
                    `}>
                      {isOptionSelected(option.id) && <span>✓</span>}
                    </div>
                    {option.text}
                  </button>
                ))}
              </div>

              <div className={s.navBtns}>
                <button onClick={handleBack} className={s.btnBack}>← Назад</button>
                <button onClick={handleNext} disabled={submitting} className={s.btnNext}>
                  {submitting ? "Обробка..." : currentQuestionIndex === (selectedSymptom?.questions.length ?? 0) - 1 ? "Отримати результат" : "Далі →"}
                </button>
              </div>
            </div>
          )}

          {/* Крок 3 */}
          {step === "result" && result && (
            <div>
              <div className={s.resultHeader}>
                <p className={s.resultIcon}>✅</p>
                <h4 className={s.resultTitle}>Ваш результат</h4>
                <p className={s.resultDesc}>На основі ваших відповідей рекомендуємо:</p>
              </div>

              <div className={s.specList}>
                {result.specializations.map((spec, index) => (
                  <div key={spec.id} className={`${s.specItem} ${index === 0 ? s.specItemTop : ""}`}>
                    <div className={s.specLeft}>
                      <span className={`${s.specRank} ${index === 0 ? s.specRankTop : ""}`}>#{index + 1}</span>
                      <span className={s.specName}>{spec.name}</span>
                    </div>
                    {index === 0 && <span className={s.specBadge}>Рекомендовано</span>}
                  </div>
                ))}
              </div>

              {result.doctors.length > 0 && (
                <div>
                  <p className={s.doctorsTitle}>Наші фахівці:</p>
                  <div className={s.doctorsList}>
                    {result.doctors.map((doctor) => (
                      <div key={doctor.id} className={s.doctorCard}>
                        <div className={s.doctorCardTop}>
                          <div className={s.doctorAvatar}>
                            {doctor.photoUrl ? (
                              <img src={doctor.photoUrl} alt="" />
                            ) : (
                              `${doctor.firstName[0]}${doctor.lastName[0]}`
                            )}
                          </div>
                          <div>
                            <p className={s.doctorName}>{doctor.firstName} {doctor.lastName}</p>
                            <p className={s.doctorSpec}>{doctor.specialization.name}</p>
                          </div>
                        </div>
                        <div className={s.doctorCardBottom}>
                          <button onClick={() => { navigate(`/doctors/${doctor.id}`); onClose(); }} className={s.btnBook}>
                            Записатись
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className={s.navBtns}>
                <button onClick={() => { setStep("symptom"); setSelectedSymptom(null); setSelectedOptions([]); setResult(null); }} className={s.btnAgain}>
                  Пройти знову
                </button>
                <button onClick={onClose} className={s.btnClose}>Закрити</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default QuizModal;