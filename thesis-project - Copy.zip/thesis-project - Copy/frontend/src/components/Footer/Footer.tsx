import { Link } from "react-router-dom";
// Спробуй цей варіант:
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Globe 
} from "lucide-react";
import s from "../styles/Footer.module.scss";

const Footer = () => {
  return (
    <footer className={s.footer}>
      <div className={s.container}>
        
        <div className={s.grid}>

          {/* LOGO */}
          <div className={s.logoBlock}>
            <div className={s.logo}>
              <img src="/Logo.svg" alt="logo" />
            </div>

            <p className={s.text}>
              Інформаційно-довідкова система медичного закладу. Запис до лікарів онлайн — швидко, зрозуміло та зручно.
            </p>

            <div className={s.socials}>
              <a href="#" />
              <a href="#" />
              <a href="#"><Globe size={20} /></a>
            </div>
          </div>

          {/* NAV */}
          <div>
            <h3 className={s.title}>Навігація</h3>

            <ul className={s.list}>
              {["Лікарі", "Про нас", "Реєстрація", "Вхід"].map((item, i) => (
                <li key={i}>
                  <Link
                    to={
                      item === "Лікарі"
                        ? "/doctors"
                        : item === "Про нас"
                        ? "/about"
                        : item === "Реєстрація"
                        ? "/register"
                        : "/login"
                    }
                    className={s.link}
                  >
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* HELP */}
          <div>
            <h3 className={s.title}>Допомога</h3>

            <ul className={s.list}>
              <li><Link to="/all_services" className={s.link}>Всі послуги</Link></li>
              <li><Link to="/faq" className={s.link}>Поширені запитання</Link></li>
              <li><Link to="/privacy" className={s.link}>Політика конфіденційності</Link></li>
            </ul>
          </div>

          {/* CONTACTS */}
          <div>
            <h3 className={s.title}>Контакти</h3>

            <ul className={s.list}>
              <li className={s.contactItem}>
                <MapPin size={18} />
                м. Полтава, вул. Медична, 1
              </li>

              <li className={s.contactItem}>
                <Phone size={18} />
                +380 50 123 45 67
              </li>

              <li className={s.contactItem}>
                <Mail size={18} />
                info@medica.ua
              </li>

              <li className={s.contactItem}>
                <Clock size={18} />
                Пн-Пт: 8:00 - 20:00
              </li>
            </ul>
          </div>

        </div>

        {/* BOTTOM */}
        <div className={s.bottom}>
          <p>© 2026 Medica. Всі права захищені.</p>
          <span>UA / EN</span>
        </div>

      </div>
    </footer>
  );
};

export default Footer;