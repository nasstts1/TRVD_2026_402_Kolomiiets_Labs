import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import api from "../services/api";
import toast from "react-hot-toast";
import PasswordInput from "./PasswordInput";
import s from "./styles/ChangePasswordForm.module.scss";

const schema = z.object({
  currentPassword: z.string().min(1, "Введіть поточний пароль"),
  newPassword: z.string().min(8, "Мінімум 8 символів"),
  confirmPassword: z.string(),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Паролі не співпадають",
  path: ["confirmPassword"],
});

type ChangePasswordForm = z.infer<typeof schema>;

const ChangePasswordForm = () => {
  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } =
    useForm<ChangePasswordForm>({ resolver: zodResolver(schema) });

  const onSubmit = async (data: ChangePasswordForm) => {
    try {
      await api.patch("/users/password", {
        currentPassword: data.currentPassword,
        newPassword: data.newPassword,
      });
      reset();
      toast.success("Пароль змінено!");
    } catch {
      toast.error("Помилка. Перевірте поточний пароль.");
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className={s.form}>
      <div className={s.formGroup}>
        <label className={s.label}>Поточний пароль</label>
        <PasswordInput placeholder="Поточний пароль"
          error={!!errors.currentPassword} registration={register("currentPassword")} />
        {errors.currentPassword && <p className={s.errorMsg}>{errors.currentPassword.message}</p>}
      </div>
      <div className={s.formGroup}>
        <label className={s.label}>Новий пароль</label>
        <PasswordInput placeholder="Новий пароль"
          error={!!errors.newPassword} registration={register("newPassword")} />
        {errors.newPassword && <p className={s.errorMsg}>{errors.newPassword.message}</p>}
      </div>
      <div className={s.formGroup}>
        <label className={s.label}>Підтвердження паролю</label>
        <PasswordInput placeholder="Підтвердження паролю"
          error={!!errors.confirmPassword} registration={register("confirmPassword")} />
        {errors.confirmPassword && <p className={s.errorMsg}>{errors.confirmPassword.message}</p>}
      </div>
      <button type="submit" disabled={isSubmitting} className={s.btnSubmit}>
        {isSubmitting ? "Збереження..." : "Змінити пароль"}
      </button>
    </form>
  );
};

export default ChangePasswordForm;