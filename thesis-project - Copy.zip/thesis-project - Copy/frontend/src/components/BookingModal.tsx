import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import api from "../services/api";
import toast from "react-hot-toast";
import type { Doctor } from "../types";
import s from "./styles/BookingModal.module.scss";

const schema = z.object({
  firstName: z.string().min(2, "Мінімум 2 символи"),
  lastName: z.string().min(2, "Мінімум 2 символи"),
  phone: z.string().min(10, "Введіть номер телефону"),
  notes: z.string().optional(),
});

type BookingForm = z.infer<typeof schema>;

interface Props {
  doctor: Doctor;
  date: string;
  time: string;
  onClose: () => void;
  onSuccess: () => void;
  endpoint?: string;
}

const BookingModal = ({ doctor, date, time, onClose, onSuccess, endpoint }: Props) => {
  const { register, handleSubmit, formState: { errors, isSubmitting } } =
    useForm<BookingForm>({ resolver: zodResolver(schema) });

  const onSubmit = async (data: BookingForm) => {
    try {
      const [year, month, day] = date.split("-").map(Number);
      const [hours, minutes] = time.split(":").map(Number);
      const appointmentDate = new Date(year, month - 1, day, hours, minutes);

      await api.post(endpoint ?? "/appointments/guest", {
        doctorId: doctor.id,
        appointmentDate: appointmentDate.toISOString(),
        notes: data.notes || null,
        guestName: `${data.firstName} ${data.lastName}`,
        guestPhone: data.phone,
      });

      toast.success("Запис успішно створено!");
      onSuccess();
      onClose();
    } catch (error) {
      console.error("BOOKING ERROR:", error);
      toast.error("Помилка при створенні запису");
    }
  };

  return (
    <div className={s.overlay}>
      <div className={s.modal}>
        <div className={s.modalHeader}>
          <h3 className={s.modalTitle}>Підтвердження запису</h3>
          <button onClick={onClose} className={s.closeBtn}>✕</button>
        </div>

        <div className={s.modalBody}>
          {/* Інфо лікаря */}
          <div className={s.doctorInfo}>
            <div className={s.doctorRow}>
              <div className={s.doctorAvatar}>
                {doctor.firstName[0]}{doctor.lastName[0]}
              </div>
              <div>
                <p className={s.doctorName}>{doctor.firstName} {doctor.lastName}</p>
                <p className={s.doctorSpec}>{doctor.specialization.name}</p>
              </div>
            </div>
            <div className={s.doctorMeta}>
              <span>📅 {new Date(date).toLocaleDateString("uk-UA")}</span>
              <span>🕐 {time}</span>
            </div>
          </div>

          {/* Форма */}
          <form onSubmit={handleSubmit(onSubmit)}>
            <div className={s.formRow}>
              <div>
                <label className={s.label}>Ім'я</label>
                <input type="text" {...register("firstName")}
                  className={`${s.input} ${errors.firstName ? s.inputError : ""}`} />
                {errors.firstName && <p className={s.errorMsg}>{errors.firstName.message}</p>}
              </div>
              <div>
                <label className={s.label}>Прізвище</label>
                <input type="text" {...register("lastName")}
                  className={`${s.input} ${errors.lastName ? s.inputError : ""}`} />
                {errors.lastName && <p className={s.errorMsg}>{errors.lastName.message}</p>}
              </div>
            </div>

            <div className={s.formGroup}>
              <label className={s.label}>Телефон</label>
              <input type="tel" {...register("phone")} placeholder="+380XXXXXXXXX"
                className={`${s.input} ${errors.phone ? s.inputError : ""}`} />
              {errors.phone && <p className={s.errorMsg}>{errors.phone.message}</p>}
            </div>

            <div className={s.formGroup}>
              <label className={s.label}>Нотатки (необов'язково)</label>
              <textarea {...register("notes")} rows={3}
                placeholder="Опишіть причину звернення..."
                className={s.textarea} />
            </div>

            <div className={s.formBtns}>
              <button type="submit" disabled={isSubmitting} className={s.btnSubmit}>
                {isSubmitting ? "Зберігається..." : "Підтвердити запис"}
              </button>
              <button type="button" onClick={onClose} className={s.btnCancel}>
                Скасувати
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default BookingModal;