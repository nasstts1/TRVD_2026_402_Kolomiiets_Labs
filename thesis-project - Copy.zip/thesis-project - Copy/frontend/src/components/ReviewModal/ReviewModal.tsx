import { useState } from "react";
import api from "../../services/api";
import toast from "react-hot-toast";

interface Props {
  appointmentId: number;
  doctorName: string;
  onClose: () => void;
  onSuccess: () => void;
}

const ReviewModal = ({ appointmentId, doctorName, onClose, onSuccess }: Props) => {
  const [rating, setRating] = useState(0);
  const [hovered, setHovered] = useState(0);
  const [comment, setComment] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (rating === 0) {
      toast.error("Оберіть оцінку");
      return;
    }
    if (comment.trim().length < 10) {
      toast.error("Відгук має бути мінімум 10 символів");
      return;
    }

    try {
      setLoading(true);
      await api.post("/reviews", {
        appointmentId,
        rating,
        comment: comment.trim(),
      });
      toast.success("Відгук успішно надіслано!");
      onSuccess();
      onClose();
    } catch {
      toast.error("Помилка при надсиланні відгуку");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl">
        <div className="flex justify-between items-center p-6 border-b">
          <h3 className="text-xl font-bold">Залишити відгук</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-2xl">✕</button>
        </div>

        <div className="p-6 space-y-5">
          <div className="bg-blue-50 rounded-xl p-4">
            <p className="text-sm text-gray-500">Лікар</p>
            <p className="font-semibold">{doctorName}</p>
          </div>

          {/* Зірочки */}
          <div>
            <p className="text-sm font-medium text-gray-700 mb-2">Оцінка</p>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHovered(star)}
                  onMouseLeave={() => setHovered(0)}
                  className="text-3xl transition-transform hover:scale-110"
                >
                  <span className={star <= (hovered || rating) ? "text-yellow-400" : "text-gray-300"}>
                    ★
                  </span>
                </button>
              ))}
              {rating > 0 && (
                <span className="ml-2 text-sm text-gray-500 self-center">
                  {["", "Погано", "Задовільно", "Добре", "Дуже добре", "Відмінно"][rating]}
                </span>
              )}
            </div>
          </div>

          {/* Коментар */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Ваш відгук
            </label>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={4}
              placeholder="Розкажіть про свій досвід..."
              className="w-full border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
            />
            <p className="text-xs text-gray-400 mt-1">{comment.length} символів (мінімум 10)</p>
          </div>

          <div className="flex gap-3">
            <button
              onClick={handleSubmit}
              disabled={loading}
              className="flex-1 bg-blue-600 text-white py-3 rounded-xl hover:bg-blue-700 disabled:opacity-50 font-medium"
            >
              {loading ? "Надсилання..." : "Надіслати відгук"}
            </button>
            <button
              onClick={onClose}
              className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl hover:bg-gray-200 font-medium"
            >
              Скасувати
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReviewModal;