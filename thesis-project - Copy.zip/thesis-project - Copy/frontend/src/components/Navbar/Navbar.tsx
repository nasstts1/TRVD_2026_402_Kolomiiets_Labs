import { Link, useNavigate } from "react-router-dom";
import { useState, useEffect, useRef } from "react";
import { useAuth } from "../../context/AuthContext";
import { getServiceCategories } from "../../services/serviceService";
import type { ServiceCategory } from "../../services/serviceService";
import QuizModal from "./../QuizModal";
import s from "../styles/Navbar.module.scss";

const Navbar = () => {
  const { user, isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();

  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [servicesOpen, setServicesOpen] = useState(false);
  const [categories, setCategories] = useState<ServiceCategory[]>([]);
  const [showQuiz, setShowQuiz] = useState(false);

  const [mobileOpen, setMobileOpen] = useState(false);

  const servicesRef = useRef<HTMLDivElement | null>(null);
  const userRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    getServiceCategories().then(setCategories).catch(console.error);
  }, []);


  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => { document.body.style.overflow = ""; };
  }, [mobileOpen]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        servicesRef.current &&
        !servicesRef.current.contains(event.target as Node)
      ) {
        setServicesOpen(false);
      }
      if (
        userRef.current &&
        !userRef.current.contains(event.target as Node)
      ) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setServicesOpen(false);
        setDropdownOpen(false);
        setShowQuiz(false);
      }
    };
    document.addEventListener("keydown", handleEsc);
    return () => document.removeEventListener("keydown", handleEsc);
  }, []);

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <>
      <nav className={s.navbar}>
        {/* LOGO */}
        <Link to="/" className={s.logo} onClick={() => setMobileOpen(false)}>
          <img src="/Logo.svg" alt="logo" />
        </Link>

        {/* CENTER */}
        <div className={s.center}>
          {/* SERVICES */}
          <div className={s.services} ref={servicesRef}>
            <button
              className={s.navItem}
              onClick={() => {
                setServicesOpen((prev) => !prev);
                setDropdownOpen(false);
              }}
            >
              Послуги
              <span className={`${s.arrow} ${servicesOpen ? s.open : ""}`}>
                ▾
              </span>
            </button>

            {servicesOpen && (
              <div className={s.megaMenu}>
                <div className={s.megaIntro}>
                  <h3>Наші послуги</h3>
                  <p>Професійна медична допомога та сучасні методи лікування</p>
                </div>
                <div className={s.megaList}>
                  {categories.slice(0, 8).map((cat) => (
                    <Link
                      key={cat.id}
                      to={`/services/${cat.id}`}
                      className={s.megaLink}
                      onClick={() => setServicesOpen(false)}
                    >
                      {cat.name}
                    </Link>
                  ))}
                </div>
                <div className={s.megaSide}>
                  <p>Не знайшли потрібну послугу?</p>
                  <Link
                    to="/all_services"
                    className={s.megaBtn}
                    onClick={() => setServicesOpen(false)}
                  >
                    Всі послуги →
                  </Link>
                </div>
              </div>
            )}
          </div>

          <Link to="/doctors" className={s.navItem}>
            Лікарі
          </Link>

          <Link to="/about_us" className={s.navItem}>
            Про нас
          </Link>
        </div>

        {/* RIGHT */}
        <div className={s.right}>
          {isAuthenticated ? (
            <div className={s.userBox} ref={userRef}>
              <button
                onClick={() => {
                  setDropdownOpen((prev) => !prev);
                  setServicesOpen(false);
                }}
                className={s.userBtn}
              >
                {user?.firstName} {user?.lastName}
              </button>

              {dropdownOpen && (
                <div className={s.dropdown}>
                  {user?.role === "PATIENT" && (
                    <>
                      <Link to="/profile" className={s.dropdownItem}>
                        Мій профіль
                      </Link>
                      <Link to="/appointments" className={s.dropdownItem}>
                        Мої записи
                      </Link>
                      <Link to="/recommend" className={s.dropdownItem}>
                        Пошук за симптомами
                      </Link>
                    </>
                  )}
                  {(user?.role === "ADMIN" || user?.role === "DOCTOR") && (
                    <Link
                      to={user?.role === "ADMIN" ? "/admin" : "/doctor"}
                      className={s.dropdownItemHighlight}
                    >
                      Панель управління
                    </Link>
                  )}
                  <div className={s.divider} />
                  <button onClick={handleLogout} className={s.logout}>
                    Вийти
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className={s.auth}>
              <Link to="/login" className={s.login}>
                Login
              </Link>
              <Link to="/register" className={s.signup}>
                Sign Up
              </Link>
            </div>
          )}
        </div>

        <button
          className={s.burger}
          onClick={() => setMobileOpen((prev) => !prev)}
          aria-label="Меню"
        >
          <span className={`${s.burgerLine} ${mobileOpen ? s.burgerLineTop : ""}`} />
          <span className={`${s.burgerLine} ${mobileOpen ? s.burgerLineMid : ""}`} />
          <span className={`${s.burgerLine} ${mobileOpen ? s.burgerLineBot : ""}`} />
        </button>
      </nav>
      
      {mobileOpen && (
      <div className={s.mobileMenu}>
        <div className={s.mobileMenuInner}>
          <Link to="/doctors" className={s.mobileLink} onClick={() => setMobileOpen(false)}>Лікарі</Link>
          <Link to="/about_us" className={s.mobileLink} onClick={() => setMobileOpen(false)}>Про нас</Link>
          <Link to="/all_services" className={s.mobileLink} onClick={() => setMobileOpen(false)}>Послуги</Link>
          {categories.slice(0, 6).map((cat) => (
            <Link key={cat.id} to={`/services/${cat.id}`} className={s.mobileCatLink} onClick={() => setMobileOpen(false)}>
              {cat.name}
            </Link>
          ))}
          <Link to="/all_services" className={s.mobileAllServices} onClick={() => setMobileOpen(false)}>
            Всі послуги →
          </Link>
          <div className={s.mobileDivider} />
          {isAuthenticated ? (
            <>
              {user?.role === "PATIENT" && (
                <>
                  <Link to="/profile" className={s.mobileLink} onClick={() => setMobileOpen(false)}>Мій профіль</Link>
                  <Link to="/appointments" className={s.mobileLink} onClick={() => setMobileOpen(false)}>Мої записи</Link>
                </>
              )}
              {(user?.role === "ADMIN" || user?.role === "DOCTOR") && (
                <Link to={user?.role === "ADMIN" ? "/admin" : "/doctor"} className={s.mobileLink} onClick={() => setMobileOpen(false)}>
                  Панель управління
                </Link>
              )}
              <button onClick={() => { handleLogout(); setMobileOpen(false); }} className={s.mobileLogout}>
                Вийти
              </button>
            </>
          ) : (
            <div className={s.mobileAuth}>
              <Link to="/login" className={s.mobileAuthBtn} onClick={() => setMobileOpen(false)}>Увійти</Link>
              <Link to="/register" className={s.mobileAuthBtnPrimary} onClick={() => setMobileOpen(false)}>Реєстрація</Link>
            </div>
          )}
        </div>
      </div>
    )}

      {/* QUIZ MODAL */}
      {showQuiz && <QuizModal onClose={() => setShowQuiz(false)} />}
    </>
  );
};

export default Navbar;