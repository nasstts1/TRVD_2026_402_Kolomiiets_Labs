import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import { useAuth } from "../context/AuthContext";

const Navbar = () => {
  const { user, isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <nav className="w-full border-b border-gray-200 px-10 py-4 flex justify-between items-center relative">
      {/* Ліво — лого */}
      <Link to="/" className="flex items-center gap-2 text-blue-500 font-bold text-xl">
        <img src="/Logo.svg" alt="logo" className="h-8" />
      </Link>

      {/* Центр — навігація */}
      <div className="flex items-center gap-8">
        <Link to="/doctors" className="text-gray-600 hover:text-blue-600">Лікарі</Link>
        <Link to="/about" className="text-gray-600 hover:text-blue-600">Про нас</Link>
      </div>

      {/* Право — кнопки */}
      <div className="flex items-center gap-4 relative">
        {isAuthenticated ? (
          <div className="relative">
            <button
              onClick={() => setDropdownOpen(!dropdownOpen)}
              className="bg-blue-600/50 text-white px-5 py-2 rounded-full"
            >
              {user?.firstName} {user?.lastName}
            </button>

            {dropdownOpen && (
              <div className="absolute right-0 mt-2 w-52 bg-white rounded-xl shadow-lg border border-gray-100 z-50">
                {user?.role === "PATIENT" && (
                  <>
                    <Link
                      to="/profile"
                      onClick={() => setDropdownOpen(false)}
                      className="flex items-center gap-2 px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-t-xl"
                    >
                      👤 Мій профіль
                    </Link>
                    <Link
                      to="/appointments"
                      onClick={() => setDropdownOpen(false)}
                      className="flex items-center gap-2 px-4 py-3 text-gray-700 hover:bg-gray-50"
                    >
                      📅 Мої записи
                    </Link>
                    <Link
                      to="/recommend"
                      onClick={() => setDropdownOpen(false)}
                      className="flex items-center gap-2 px-4 py-3 text-gray-700 hover:bg-gray-50"
                    >
                      🔍 Пошук за симптомами
                    </Link>
                  </>
                )}
                {(user?.role === "ADMIN" || user?.role === "DOCTOR") && (
                  <Link
                    to={user?.role === "ADMIN" ? "/admin" : "/doctor"}
                    onClick={() => setDropdownOpen(false)}
                    className="flex items-center gap-2 px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-t-xl"
                  >
                    ⚙️ Панель управління
                  </Link>
                )}
                <div className="border-t border-gray-200 mx-2" />
                <button
                  onClick={() => { handleLogout(); setDropdownOpen(false); }}
                  className="flex items-center gap-2 px-4 py-3 text-gray-400 hover:bg-gray-50 rounded-b-xl w-full text-left"
                >
                  Вийти
                </button>
              </div>
            )}
          </div>
        ) : (
          <>
            <Link to="/login" className="text-gray-600 hover:text-blue-600">
              Login
            </Link>
            <Link
              to="/register"
              className="bg-blue-600 text-white px-5 py-2 rounded-full hover:bg-blue-700"
            >
              Sign Up
            </Link>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;