import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white mt-auto">
      <div className="max-w-7xl mx-auto px-10 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Лого і опис */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <img src="/Logo.svg" alt="logo" className="h-8" />
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              Інформаційно-довідкова система медичного закладу. Запис до лікарів онлайн, швидко і зручно.
            </p>
          </div>

          {/* Навігація */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Навігація</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/doctors" className="text-gray-400 hover:text-white text-sm transition">
                  Лікарі
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-400 hover:text-white text-sm transition">
                  Про нас
                </Link>
              </li>
              <li>
                <Link to="/register" className="text-gray-400 hover:text-white text-sm transition">
                  Реєстрація
                </Link>
              </li>
              <li>
                <Link to="/login" className="text-gray-400 hover:text-white text-sm transition">
                  Вхід
                </Link>
              </li>
            </ul>
          </div>

          {/* Контакти */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Контакти</h3>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li className="flex items-center gap-2">
                📍 м. Полтава, вул. Медична, 1
              </li>
              <li className="flex items-center gap-2">
                📞 +380 50 123 45 67
              </li>
              <li className="flex items-center gap-2">
                ✉️ info@medica.ua
              </li>
              <li className="flex items-center gap-2">
                🕐 Пн-Пт: 8:00 - 20:00
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-500 text-sm">
          © 2026 Medica. Всі права захищені.
        </div>
      </div>
    </footer>
  );
};

export default Footer;