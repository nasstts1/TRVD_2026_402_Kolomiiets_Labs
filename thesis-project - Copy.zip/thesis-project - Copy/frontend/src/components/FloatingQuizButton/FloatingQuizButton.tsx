import { useState } from "react";
import QuizModal from "../QuizModal";
import s from "../styles/FloatingQuizButton.module.scss";

const FloatingQuizButton = () => {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        className={s.floatingBtn}
        onClick={() => setOpen(true)}
      >
        <span className={s.icon}>🩺</span>
        <span>Підібрати лікаря</span>
      </button>

      {open && (
        <QuizModal onClose={() => setOpen(false)} />
      )}
    </>
  );
};

export default FloatingQuizButton;