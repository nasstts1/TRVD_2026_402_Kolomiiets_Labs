import { useNavigate } from "react-router-dom";
import type { Doctor } from "../types";

interface Props {
  doctor: Doctor;
}

const DoctorCard = ({ doctor }: Props) => {
  const navigate = useNavigate();

  return (
    <div className="relative group rounded-2xl overflow-hidden cursor-pointer shadow-md bg-gray-200 h-[420px]">
      {/* Фото */}
      <img
        src="/doctors_photo/01.webp"
        alt={`${doctor.firstName} ${doctor.lastName}`}
        className="w-full h-full object-cover object-top"
      />

      {/* Нижня плашка — завжди видна */}
      <div className="absolute bottom-0 left-0 right-0 bg-white/80 backdrop-blur-sm px-4 py-3 transition-all duration-300 group-hover:opacity-0">
        <h3 className="font-bold text-gray-800 text-lg">
          {doctor.lastName} {doctor.firstName}
        </h3>
        <p className="text-gray-500 text-sm">{doctor.specialization.name}</p>
      </div>

      {/* Плашка при наведенні — з низу до верху всієї картки */}
      <div className="absolute inset-0 bg-white/95 backdrop-blur-sm px-6 py-6 flex flex-col justify-end translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-in-out">
        <h3 className="font-bold text-gray-800 text-xl mb-1">
          {doctor.lastName} {doctor.firstName}
        </h3>
        <p className="text-blue-500 text-sm mb-3">{doctor.specialization.name}</p>
        <div className="flex justify-between items-center mb-4 text-sm text-gray-600">
          <span>Консультація</span>
          <span className="font-semibold">від 500 грн</span>
        </div>
        {doctor.phone && (
          <p className="text-gray-500 text-sm mb-4">📞 {doctor.phone}</p>
        )}
        <button
          onClick={() => navigate(`/doctors/${doctor.id}`)}
          className="w-full bg-blue-500 text-white py-3 rounded-full hover:bg-blue-600 transition font-medium"
        >
          Записатись на прийом
        </button>
      </div>
    </div>
  );
};

export default DoctorCard;