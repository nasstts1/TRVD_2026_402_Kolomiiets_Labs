import { useNavigate } from "react-router-dom";
import type { Doctor } from "../../types";
import s from "../styles/DoctorCard.module.scss";

interface Props {
  doctor: Doctor;
}

const DoctorCard = ({ doctor }: Props) => {
  const navigate = useNavigate();

  return (
    <div
      onClick={() => navigate(`/doctors/${doctor.id}`)}
      className={s.card}
    >
      {/* Спеціалізація зверху */}
      <div className={s.specBadge}>
        {doctor.specialization.name}
      </div>

      {/* Фото */}
      <div
        className={s.image}
        style={{
          backgroundImage: `url(${doctor.photoUrl || '/doctor-placeholder.png'})`,
        }}
      >
        <div className={s.overlay} />

        {/* Інфо знизу */}
        <div className={s.info}>
          <h3 className={s.name}>
            {doctor.firstName} {doctor.lastName}
          </h3>
          {doctor.experience && (
            <p className={s.experience}>
              Досвід: {doctor.experience} років
            </p>
          )}
          <div className={s.footer}>
            <span className={s.btn}>Детальніше →</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DoctorCard;