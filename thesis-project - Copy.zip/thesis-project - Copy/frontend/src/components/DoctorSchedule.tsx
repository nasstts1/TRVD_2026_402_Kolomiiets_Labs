import { useState } from "react";
import TimeSlotPicker from "./TimeSlotPicker";
import BookingModal from "./BookingModal";
import type { Doctor } from "../types";
import s from "./styles/DoctorSchedule.module.scss";

const DAYS = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Нд"];

interface Props {
  doctor: Doctor;
  workDays: number[];
  breakStart: string;
  breakEnd: string;
  hideBooked?: boolean;
  endpoint?: string;
}

const DoctorSchedule = ({ doctor, workDays, breakStart, breakEnd, endpoint }: Props) => {
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [showBooking, setShowBooking] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  const getNextDays = () => {
    const days = [];
    for (let i = 1; i <= 14; i++) {
      const date = new Date();
      date.setDate(date.getDate() + i);
      const dayOfWeek = date.getDay() === 0 ? 7 : date.getDay();
      if (workDays.includes(dayOfWeek)) days.push(date);
    }
    return days;
  };

  const availableDays = getNextDays();
  const formatDate = (date: Date) => date.toISOString().split("T")[0];
  const formatDisplayDate = (date: Date) => ({
    day: DAYS[date.getDay() === 0 ? 6 : date.getDay() - 1],
    date: date.getDate(),
    month: date.toLocaleString("uk-UA", { month: "short" }),
  });

  return (
    <div className={s.wrap}>
      <h3 className={s.title}>Розклад прийому</h3>

      <div className={s.workInfo}>
        <span className={s.workIcon}>🕐</span>
        <p className={s.workText}>
          Робочий час: <strong>09:00 — 18:00</strong> | Перерва: <strong>{breakStart} — {breakEnd}</strong>
        </p>
      </div>

      <p className={s.dateLabel}>Оберіть дату:</p>

      <div className={s.datesRow}>
        {availableDays.map((date) => {
          const formatted = formatDate(date);
          const display = formatDisplayDate(date);
          const isSelected = selectedDate === formatted;
          return (
            <button
              key={formatted}
              onClick={() => { setSelectedDate(formatted); setSelectedTime(null); }}
              className={`${s.dateBtn} ${isSelected ? s.dateBtnActive : ""}`}
            >
              <span className={s.dateDay}>{display.day}</span>
              <span className={s.dateNum}>{display.date}</span>
              <span className={s.dateMonth}>{display.month}</span>
            </button>
          );
        })}
      </div>

      {selectedDate && (
        <TimeSlotPicker
          key={refreshKey}
          doctorId={doctor.id}
          date={selectedDate}
          onSelect={setSelectedTime}
          selectedTime={selectedTime}
          onBook={(time) => { setSelectedTime(time); setShowBooking(true); }}
        />
      )}

      {showBooking && selectedTime && (
        <BookingModal
          doctor={doctor}
          date={selectedDate}
          time={selectedTime}
          onClose={() => { setShowBooking(false); setSelectedTime(null); }}
          onSuccess={() => setRefreshKey(k => k + 1)}
          endpoint={endpoint}
        />
      )}
    </div>
  );
};

export default DoctorSchedule;