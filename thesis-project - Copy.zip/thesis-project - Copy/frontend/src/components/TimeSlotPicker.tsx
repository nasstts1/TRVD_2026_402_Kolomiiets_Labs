import { useEffect, useState } from "react";
import api from "../services/api";

interface AppointmentInfo {
  id: number;
  guestName: string | null;
  guestPhone: string | null;
  user: { firstName: string; lastName: string; email: string; } | null;
  notes: string | null;
  status: string;
}

interface Props {
  doctorId: number;
  date: string;
  onSelect: (time: string) => void;
  selectedTime: string | null;
  onBook?: (time: string) => void;
}

const generateSlots = (breakStart: string, breakEnd: string) => {
  const slots = [];
  let hour = 9;
  let minute = 0;
  while (hour < 18) {
    const time = `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
    slots.push(time);
    minute += 30;
    if (minute >= 60) { minute = 0; hour++; }
  }
  return slots.filter((slot) => slot < breakStart || slot >= breakEnd);
};

const TimeSlotPicker = ({ doctorId, date, onSelect, selectedTime, onBook }: Props) => {
  const [bookedSlots, setBookedSlots] = useState<string[]>([]);
  const [breakStart, setBreakStart] = useState("13:00");
  const [breakEnd, setBreakEnd] = useState("14:00");
  const [loading, setLoading] = useState(true);
  const [appointmentInfo, setAppointmentInfo] = useState<AppointmentInfo | null>(null);

  useEffect(() => {
    if (!date) return;
    setLoading(true);
    Promise.all([
      api.get(`/doctors/${doctorId}`),
      api.get(`/appointments/booked?doctorId=${doctorId}&date=${date}`),
    ])
      .then(([doctorRes, bookedRes]) => {
        setBreakStart(doctorRes.data.breakStart);
        setBreakEnd(doctorRes.data.breakEnd);
        setBookedSlots(bookedRes.data);
      })
      .catch(() => setBookedSlots([]))
      .finally(() => setLoading(false));
  }, [doctorId, date]);

  const handleBookedClick = async (slot: string) => {
    try {
      const res = await api.get(`/appointments/slot?doctorId=${doctorId}&date=${date}&time=${slot}`);
      setAppointmentInfo(res.data);
    } catch {
      setAppointmentInfo(null);
    }
  };

  const slots = generateSlots(breakStart, breakEnd);

  if (loading) return <p className="text-gray-400 text-sm">Завантаження...</p>;

  return (
    <div>
      <p className="text-sm font-medium text-gray-700 mb-3">Оберіть час:</p>
      <div className="grid grid-cols-4 gap-2">
        {slots.map((slot) => {
          const isBooked = bookedSlots.includes(slot);
          const isSelected = selectedTime === slot;
          return (
            <button
              key={slot}
              type="button"
              onClick={() => {
                if (isBooked) {
                  handleBookedClick(slot);
                } else {
                  onSelect(slot);
                  onBook?.(slot);
                }
              }}
              className={`py-2 px-3 rounded-lg text-sm font-medium border transition ${
                isBooked
                  ? "border-gray-300 text-gray-400 bg-gray-100 cursor-pointer hover:bg-gray-200"
                  : isSelected
                  ? "border-blue-600 bg-blue-600 text-white"
                  : "border-blue-300 text-blue-600 hover:bg-blue-50"
              }`}
            >
              {slot}
            </button>
          );
        })}
      </div>

      {appointmentInfo && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[80]">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-xl">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-lg">Інформація про запис</h3>
              <button onClick={() => setAppointmentInfo(null)} className="text-gray-400 hover:text-gray-600 text-xl">✕</button>
            </div>
            <div className="space-y-3">
              <div className="bg-gray-50 rounded-xl p-4">
                <p className="text-xs text-gray-400 uppercase font-bold mb-2">Пацієнт</p>
                {appointmentInfo.guestName ? (
                  <>
                    <p className="font-semibold">{appointmentInfo.guestName}</p>
                    <p className="text-gray-500 text-sm">{appointmentInfo.guestPhone ?? "—"}</p>
                  </>
                ) : appointmentInfo.user ? (
                  <>
                    <p className="font-semibold">{appointmentInfo.user.firstName} {appointmentInfo.user.lastName}</p>
                    <p className="text-gray-500 text-sm">{appointmentInfo.user.email}</p>
                  </>
                ) : (
                  <p className="text-gray-500 text-sm">Інформація відсутня</p>
                )}
              </div>
              {appointmentInfo.notes && (
                <div className="bg-gray-50 rounded-xl p-4">
                  <p className="text-xs text-gray-400 uppercase font-bold mb-2">Нотатки</p>
                  <p className="text-gray-700 text-sm">{appointmentInfo.notes}</p>
                </div>
              )}
              <div className="bg-gray-50 rounded-xl p-4">
                <p className="text-xs text-gray-400 uppercase font-bold mb-2">Статус</p>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  appointmentInfo.status === "CONFIRMED" ? "bg-green-100 text-green-700"
                  : appointmentInfo.status === "CANCELLED" ? "bg-red-100 text-red-700"
                  : "bg-yellow-100 text-yellow-700"
                }`}>
                  {appointmentInfo.status === "CONFIRMED" ? "Підтверджено"
                    : appointmentInfo.status === "CANCELLED" ? "Скасовано"
                    : "Очікує"}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TimeSlotPicker;