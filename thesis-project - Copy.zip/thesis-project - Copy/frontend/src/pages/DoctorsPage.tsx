import { useEffect, useState } from "react";
import { getDoctors } from "../services/doctorService";
import { getSpecializations } from "../services/specializationService";
import type { Specialization } from "../services/specializationService";
import DoctorCard from "../components/DoctorCard";
import type { Doctor } from "../types";

const DoctorsPage = () => {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [specializations, setSpecializations] = useState<Specialization[]>([]);
  const [search, setSearch] = useState("");
  const [selectedSpec, setSelectedSpec] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([getDoctors(), getSpecializations()])
      .then(([docs, specs]) => {
        setDoctors(docs);
        setSpecializations(specs);
      })
      .finally(() => setLoading(false));
  }, []);

  const filtered = doctors.filter((d) => {
    const matchesSearch = `${d.firstName} ${d.lastName}`
      .toLowerCase()
      .includes(search.toLowerCase());
    const matchesSpec = selectedSpec
      ? d.specialization.id === selectedSpec
      : true;
    return matchesSearch && matchesSpec;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gray-100 py-12 text-center">
        <h1 className="text-5xl font-bold mb-8">Лікарі</h1>
        <div className="flex justify-center">
          <div className="flex bg-white rounded-full shadow px-4 py-2 w-full max-w-xl items-center gap-2">
            <select
              value={selectedSpec ?? ""}
              onChange={(e) => setSelectedSpec(e.target.value ? Number(e.target.value) : null)}
              className="text-gray-500 text-sm outline-none bg-transparent"
            >
              <option value="">Всі напрямки</option>
              {specializations.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
            <div className="w-px h-5 bg-gray-300" />
            <input
              type="text"
              placeholder="Для пошуку почніть вводити прізвище"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="flex-1 outline-none text-sm text-gray-700"
            />
            <span className="text-gray-400">🔍</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-10">
        {loading ? (
          <p className="text-center text-gray-500">Завантаження...</p>
        ) : filtered.length === 0 ? (
          <p className="text-center text-gray-500">Лікарів не знайдено</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filtered.map((doctor) => (
              <DoctorCard key={doctor.id} doctor={doctor} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default DoctorsPage;