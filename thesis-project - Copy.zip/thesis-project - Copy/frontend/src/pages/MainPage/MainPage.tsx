import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { getDoctors } from "../../services/doctorService";
import { getSpecializations } from "../../services/specializationService";
import type { Doctor } from "../../types";
import type { Specialization } from "../../services/specializationService";
import DoctorCard from "../../components/DoctorCard/DoctorCard";
import s from "./MainPage.module.scss";
import api from "../../services/api";
import toast from "react-hot-toast";
import { useAuth } from "../../context/AuthContext";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";

interface Review {
  id: number;
  rating: number;
  comment: string;
  createdAt: string;
  user: { firstName: string; lastName: string };
  doctor: { firstName: string; lastName: string; specialization: { name: string } };
}

interface AccordionItemProps {
  item: any;
  index: number;
}

const AccordionItem = ({ item, index }: AccordionItemProps) => {
  const [open, setOpen] = useState(false);

  return (
    <div className={`${s.accordionItem} ${open ? s.accordionItemOpen : ""}`}>
      <button
        className={s.accordionHeader}
        onClick={() => setOpen(!open)}
      >
        <span className={s.accordionNum}>
          {String(index + 1).padStart(2, "0")}
        </span>
        <span className={s.accordionTitle}>{item.name}</span>
        <span className={s.accordionArrow}>{open ? "−" : "+"}</span>
      </button>

      {open && (
        <div className={s.accordionBody}>
          {/* Фото зліва */}
          <div className={s.accordionImg}>
            {item.imageUrl ? (
              <img src={item.imageUrl} alt={item.name} />
            ) : (
              <div className={s.accordionImgPlaceholder}>🏥</div>
            )}
          </div>

          {/* Контент справа */}
          <div className={s.accordionContent}>
            {item.description && (
              <p className={s.accordionDesc}>{item.description}</p>
            )}

            {item.services && item.services.length > 0 && (
              <ul className={s.accordionServices}>
                {item.services.map((service: any) => (
                  <li key={service.id} className={s.accordionService}>
                    <span className={s.accordionServiceName}>{service.name}</span>
                    <span className={s.accordionServicePrice}>
                      {service.price ? `від ${service.price} грн` : "За запитом"}
                    </span>
                  </li>
                ))}
              </ul>
            )}

            <Link
              to={`/services/${item.id}`}
              className={s.accordionBtn}
            >
              Переглянути всі послуги →
            </Link>
          </div>
        </div>
      )}
    </div>
  );
};

const MainPage = () => {
  const { user, isAuthenticated } = useAuth();
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [specializations, setSpecializations] = useState<Specialization[]>([]);
  const [guestName, setGuestName] = useState(() =>
    user ? `${user.firstName} ${user.lastName}` : ""
  );
  const [guestPhone, setGuestPhone] = useState(() => user?.phone || "");
  const [agreed, setAgreed] = useState(false);
  const [bookingLoading, setBookingLoading] = useState(false);
  const [selectedSpec, setSelectedSpec] = useState("");
  const [filteredDoctors, setFilteredDoctors] = useState<Doctor[]>([]);
  const [selectedDoctorId, setSelectedDoctorId] = useState<number | null>(null);
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [bookedSlots, setBookedSlots] = useState<string[]>([]);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [doctorBreak, setDoctorBreak] = useState({ start: "13:00", end: "14:00" });
  const [categories, setCategories] = useState<any[]>([]);

  const [reviews, setReviews] = useState<Review[]>([]);

  useEffect(() => {
  getDoctors().then((data) => setDoctors(data.slice(0, 4)));
  getSpecializations().then((data) => setSpecializations(data.slice(0, 6)));
  api.get("/reviews/visible").then((res) => setReviews(res.data));
  api.get("/services/categories").then((res) => setCategories(res.data));
}, []);

  useEffect(() => {
    getDoctors().then((data) => setDoctors(data.slice(0, 4)));
    getSpecializations().then((data) => setSpecializations(data.slice(0, 6)));
  }, []);

  useEffect(() => {
    if (user) {
      setGuestName(`${user.firstName} ${user.lastName}`);
      setGuestPhone(user.phone || "");
    }
  }, [user]);

  useEffect(() => {
    if (selectedSpec) {
      const filtered = doctors.filter(
        (d) => d.specialization.id === Number(selectedSpec)
      );
      setFilteredDoctors(filtered);
      setSelectedDoctorId(null);
      setSelectedDate("");
      setSelectedTime(null);
    }
  }, [selectedSpec, doctors]);

  useEffect(() => {
    if (!selectedDoctorId || !selectedDate) return;
    setSlotsLoading(true);
    Promise.all([
      api.get(`/doctors/${selectedDoctorId}`),
      api.get(`/appointments/booked?doctorId=${selectedDoctorId}&date=${selectedDate}`),
    ])
      .then(([doctorRes, bookedRes]) => {
        setDoctorBreak({
          start: doctorRes.data.breakStart || "13:00",
          end: doctorRes.data.breakEnd || "14:00",
        });
        setBookedSlots(bookedRes.data);
      })
      .catch(() => setBookedSlots([]))
      .finally(() => setSlotsLoading(false));
  }, [selectedDoctorId, selectedDate]);

  const generateSlots = (breakStart: string, breakEnd: string) => {
    const slots = [];
    let hour = 9;
    let minute = 0;
    while (hour < 18) {
      const time = `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
      slots.push(time);
      minute += 30;
      if (minute >= 60) { minute = 0; hour++; }
    }
    return slots.filter((slot) => slot < breakStart || slot >= breakEnd);
  };

  const availableSlots = generateSlots(doctorBreak.start, doctorBreak.end)
    .filter((slot) => !bookedSlots.includes(slot));

  const handleQuickBook = async () => {
    if (!selectedDoctorId || !selectedDate || !selectedTime) {
      toast.error("Оберіть лікаря, дату та час");
      return;
    }
    if (!agreed) {
      toast.error("Підтвердіть згоду на обробку даних");
      return;
    }
    if (!guestName.trim() || !guestPhone.trim()) {
      toast.error("Заповніть ім'я та телефон");
      return;
    }

    try {
      setBookingLoading(true);
      const appointmentDate = `${selectedDate}T${selectedTime}:00.000Z`;

      if (isAuthenticated) {
        await api.post("/appointments", {
          doctorId: selectedDoctorId,
          appointmentDate,
        });
      } else {
        await api.post("/appointments/guest", {
          doctorId: selectedDoctorId,
          appointmentDate,
          guestName: guestName.trim(),
          guestPhone: guestPhone.trim(),
        });
      }

      toast.success("Запис успішно створено!");
      setAgreed(false);
      setSelectedSpec("");
      setSelectedDoctorId(null);
      setSelectedDate("");
      setSelectedTime(null);
      setFilteredDoctors([]);
      setBookedSlots([]);

      if (!isAuthenticated) {
        setGuestName("");
        setGuestPhone("");
      }
    } catch {
      toast.error("Помилка. Спробуйте ще раз");
    } finally {
      setBookingLoading(false);
    }
  };

  return (
    <div className={s.page}>
      {/* HERO */}
      <section className={s.hero}>
        {/* Фото на весь екран */}
        <img
          src="hero-section/portrait-fout-doctors-talking-white-uniform.jpg"
          alt="Клініка"
          className={s.heroBg}
        />

        {/* Темний градієнт знизу */}
        <div className={s.heroOverlay} />

        {/* Контент поверх фото */}
        <div className={s.heroInner}>

          {/* Зліва зверху — trusted badge */}
          <div className={s.heroTrusted}>
            <div className={s.heroAvatars}>
              <div className={s.heroAvatars}>
              <div className={s.heroAvatar}>
                <img src="/hero-section/avatar-1.png" alt="" />
              </div>
              <div className={s.heroAvatar}>
                <img src="/hero-section/avatar-2.png" alt="" />
              </div>
              <div className={s.heroAvatar}>
                <img src="/hero-section/avatar-3.png" alt="" />
              </div>
            </div>
            </div>
            <span>Довіряють 1000+ пацієнтів</span>
          </div>

          <div className={s.heroInfoCard}>
            <p className={s.heroCardLabel}>Графік роботи</p>
            <p className={s.heroInfoValue}>Пн–Пт: 8:00 – 20:00</p>
            <p className={s.heroInfoValue}>Сб: 9:00 – 16:00</p>
          </div>

          {/* Знизу зліва — заголовок і кнопки */}
          <div className={s.heroBottom}>
            <div className={s.heroContent}>
              <h1 className={s.heroTitle}>
                Турбота про здоров'я починається тут
              </h1>
              <p className={s.heroText}>
                Записуйтесь до перевірених лікарів онлайн —<br />
                швидко, зручно і без черг
              </p>
              <div className={s.heroButtons}>
                <a href="#booking" className={s.primaryBtn}>
                  Безкоштовна консультація 
                </a>
                <Link to="/doctors" className={s.ghostBtn}>
                  Наші лікарі 
                </Link>
              </div>
            </div>

            {/* Справа — дві плашки */}
            <div className={s.heroCards}>
              <div className={s.heroCard}>
                <p className={s.heroCardValue}>1000+</p>
                <p className={s.heroCardSub}>Задоволених пацієнтів</p>
              </div>
              <div className={s.heroCard}>
                <p className={s.heroCardValue}>20+</p>
                <p className={s.heroCardSub}>Спеціалістів</p>
              </div>
              <div className={s.heroCard}>
                <p className={s.heroCardValue}>24/7</p>
                <p className={s.heroCardSub}>Онлайн запис без черг</p>
              </div>
              <div className={s.heroCard}>
                <p className={s.heroCardValue}>4.9</p>
                <p className={s.heroCardSub}>Середня оцінка</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* TRUST BLOCK */}
      <section className={s.trustSection}>
        <div className={s.trustContainer}>

          {/* Заголовок */}
          <div className={s.trustHead}>
            
            {/* Ліва частина — бейдж + заголовок */}
            <div className={s.trustHeadLeft}>
              <div className={s.trustBadge}>
                <span>✦</span>
                <span>Чому обирають нас</span>
              </div>
              <h2 className={s.trustTitle}>
                Ми зробили запис до лікаря<br />
                <span className={s.trustTitleAccent}>простим і зручним.</span>
              </h2>
            </div>

            {/* Права частина — опис + кнопка */}
            <div className={s.trustHeadRight}>
              <p className={s.trustDesc}>
                Забудьте про черги і дзвінки. Все що вам потрібно — 
                кілька кліків і ваш запис підтверджено.
              </p>
              <a href="#booking" className={s.trustCta}>
                Записатись →
              </a>
            </div>
          </div>

          {/* Картки */}
            <div className={s.trustCards}>
              <div className={s.trustCard}>
                <span className={s.trustNum}>01.</span>
                <div className={s.trustCardHoverImg}>
                  <img src="/hero-section/cover-card-1.jpg" alt="" />
                </div>
                <div className={s.trustCardBottom}>
                  <div className={s.trustCardIcon}>
                    <img src="/hero-section/Lightning.png" alt="" />
                  </div>
                  <h3 className={s.trustCardTitle}>Запис онлайн 24/7</h3>
                  <p className={s.trustCardDesc}>
                    Без дзвінків і очікування. Обирайте лікаря і час у будь-який момент.
                  </p>
                </div>
              </div>

              <div className={s.trustCard}>
                <span className={s.trustNum}>02.</span>
                <div className={s.trustCardHoverImg}>
                  <img src="/hero-section/cover-card-2.jpg" alt="" />
                </div>
                <div className={s.trustCardBottom}>
                  <div className={s.trustCardIcon}>
                    <img src="/hero-section/Email.png" alt="" />
                  </div>
                  <h3 className={s.trustCardTitle}>Підтвердження на пошту</h3>
                  <p className={s.trustCardDesc}>
                    Одразу після запису ви отримаєте лист з деталями прийому — лікар, дата і час.
                  </p>
                </div>
              </div>

              <div className={s.trustCard}>
                <span className={s.trustNum}>03.</span>
                <div className={s.trustCardHoverImg}>
                  <img src="/hero-section/cover-card-3.jpg" alt="" />
                </div>
                <div className={s.trustCardBottom}>
                  <div className={s.trustCardIcon}>
                    <img src="/hero-section/Chat.png" alt="" />
                  </div>
                  <h3 className={s.trustCardTitle}>Нагадування за день</h3>
                  <p className={s.trustCardDesc}>
                    Ми нагадаємо про прийом заздалегідь — щоб ви нічого не пропустили.
                  </p>
                </div>
              </div>

              <div className={s.trustCard}>
                <span className={s.trustNum}>04.</span>
                <div className={s.trustCardHoverImg}>
                  <img src="/hero-section/cover-card-4.jpg" alt="" />
                </div>
                <div className={s.trustCardBottom}>
                  <div className={s.trustCardIcon}>
                    <img src="/hero-section/Close Square.png" alt="" />
                  </div>
                  <h3 className={s.trustCardTitle}>Скасування в один клік</h3>
                  <p className={s.trustCardDesc}>
                    Плани змінились? Скасуйте запис в особистому кабінеті без зайвих дій.
                  </p>
                </div>
              </div>
            </div>
        </div>
      </section>

      {/* SERVICES */}
      <section className={s.servicesSection}> 
        <div className={s.servicesContainer}>

          {/* Заголовок */}
          <div className={s.servicesHead}>
            <div className={s.serviseTag}>
              <div className={s.trustBadge}>
                <span>✦</span>
                <span>Що ми лікуємо</span>
              </div>
              <h2 className={s.servicesTitle}>Наші послуги</h2>
            </div>
            <div className={s.servicesHeadRight}>
              <p className={s.servicesDesc}>
                Широкий спектр медичних послуг для всієї родини — від консультацій до комплексних обстежень
              </p>
              <Link to="/all_services" className={s.servicesAllBtn}>
                Всі послуги →
              </Link>
            </div>
          </div>

          <div className={s.accordion}>
            {categories.map((item: any, index: number) => (
              <AccordionItem key={item.id} item={item} index={index} />
            ))}
          </div>

        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className={s.stepsSection}>
        <div className={s.stepsContainer}>
          <div className={s.stepsHead}>
            <span className={s.sectionBadge}>Як це працює</span>
            <h2 className={s.stepsTitle}>Три кроки до запису</h2>
          </div>

          <div className={s.stepsTimeline}>
            {/* Лінія */}
            <div className={s.stepsLine} />

            {/* Кроки */}
            {[
              {
                num: "01",
                title: "Оберіть лікаря або введіть симптоми",
                desc: "Знайдіть потрібного спеціаліста за іменем, спеціалізацією або скористайтесь пошуком за симптомами.",
                icon: "🔍",
              },
              {
                num: "02",
                title: "Оберіть зручний час",
                desc: "Перегляньте доступні слоти і виберіть час який підходить саме вам.",
                icon: "📅",
              },
              {
                num: "03",
                title: "Отримайте підтвердження",
                desc: "На вашу пошту надійде підтвердження запису з усіма деталями прийому.",
                icon: "✉️",
              },
            ].map((step) => (
              <div key={step.num} className={s.step}>
                {/* Контент зверху */}
                <div className={s.stepContent}>
                  <span className={s.stepNum}>{step.num}</span>
                  <h3 className={s.stepTitle}>{step.title}</h3>
                  <p className={s.stepDesc}>{step.desc}</p>
                </div>

                {/* Точка на лінії */}
                <div className={s.stepDot}>
                  <span className={s.stepIcon}>{step.icon}</span>
                </div>
              </div>
            ))}
          </div>

          <div className={s.stepsAction}>
            <a href="#booking" className={s.stepsCta}>
              Записатись зараз →
            </a>
          </div>
        </div>
      </section>

      {/* PROMOTIONS */}
      <section className={s.promoSection}>
        <div className={s.promoContainer}>
          <div className={s.promoHead}>
            <div>
              <span className={s.promoBadge}>Вигідні пропозиції</span>
              <h2 className={s.promoHeadTitle}>Акції та знижки</h2>
              <p className={s.promoHeadDesc}>Дбаємо про ваше здоров'я і ваш бюджет</p>
            </div>
          </div>

          <div className={s.promoGrid}>
            <div className={s.promoCard}>
              <p className={s.promoLabel}>Обмежена пропозиція</p>
              <h3 className={s.promoCardTitle}>Знижка 30%</h3>
              <p className={s.promoCardDesc}>На першу консультацію для нових пацієнтів</p>
              <Link to="/register" className={s.promoCardBtn}>Детальніше →</Link>
            </div>

            <div className={s.promoCard}>
              <p className={s.promoLabel}>Для нових пацієнтів</p>
              <h3 className={s.promoCardTitle}>Безкоштовний прийом</h3>
              <p className={s.promoCardDesc}>Перша консультація терапевта безкоштовно</p>
              <Link to="/register" className={s.promoCardBtn}>Детальніше →</Link>
            </div>

            <div className={s.promoCard}>
              <p className={s.promoLabel}>Сімейна програма</p>
              <h3 className={s.promoCardTitle}>Check-up</h3>
              <p className={s.promoCardDesc}>Комплексне обстеження всієї родини зі знижкою</p>
              <Link to="/register" className={s.promoCardBtn}>Детальніше →</Link>
            </div>
          </div>
        </div>
      </section>

      {/* DOCTORS */}
      <section className={s.doctorsSection}>
        <div className={s.doctorsContainer}>
          <div className={s.doctorsHead}>
            <div className={s.doctorsHeadLeft}>
              <div className={s.trustBadge}>
                <span>✦</span>
                <span>Наша команда</span>
              </div>
              <h2 className={s.doctorsTitle}>Наші лікарі</h2>
            </div>
            <div className={s.doctorsHeadRight}>
              <p className={s.doctorsDesc}>
                Спеціалісти з досвідом від 10 років, які щодня допомагають пацієнтам
              </p>
              <Link to="/doctors" className={s.doctorsAllBtn}>
                Переглянути всіх →
              </Link>
            </div>
          </div>

          <div className={s.doctorsGrid}>
            {doctors.map((doctor) => (
              <DoctorCard key={doctor.id} doctor={doctor} />
            ))}
          </div>
        </div>
      </section>

      {/* QUICK BOOKING */}
      <section className={s.bookingSection} id="booking">
        <div className={s.container}>
          <div className={s.bookingCard}>
            <div className={s.bookingLeft}>
              <h2 className={s.bookingTitle}>
                Запишіться до лікаря вже сьогодні
              </h2>
              <p className={s.bookingSubtitle}>
                Залиште свої контактні дані і адміністратор зв'яжеться з вами протягом 30 хвилин
              </p>
            </div>

            <div className={s.bookingRight}>
              <select
                className={s.bookingInput}
                value={selectedSpec}
                onChange={(e) => setSelectedSpec(e.target.value)}
              >
                <option value="">Оберіть спеціалізацію</option>
                {specializations.map((item) => (
                  <option key={item.id} value={item.id}>{item.name}</option>
                ))}
              </select>

              {filteredDoctors.length > 0 && (
                <select
                  className={s.bookingInput}
                  value={selectedDoctorId ?? ""}
                  onChange={(e) => {
                    setSelectedDoctorId(Number(e.target.value));
                    setSelectedDate("");
                    setSelectedTime(null);
                  }}
                >
                  <option value="">Оберіть лікаря</option>
                  {filteredDoctors.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.firstName} {d.lastName}
                    </option>
                  ))}
                </select>
              )}

              {selectedDoctorId && (
                <input
                  type="date"
                  className={s.bookingInput}
                  value={selectedDate}
                  min={new Date().toISOString().split("T")[0]}
                  onChange={(e) => {
                    setSelectedDate(e.target.value);
                    setSelectedTime(null);
                  }}
                />
              )}

              {selectedDate && (
                <div>
                  {slotsLoading ? (
                    <p className={s.slotsLoading}>Завантаження...</p>
                  ) : availableSlots.length === 0 ? (
                    <p className={s.slotsLoading}>Немає вільних слотів на цей день</p>
                  ) : (
                    <div className={s.slots}>
                      {availableSlots.map((slot) => (
                        <button
                          key={slot}
                          type="button"
                          onClick={() => setSelectedTime(slot)}
                          className={`${s.slot} ${selectedTime === slot ? s.slotActive : ""}`}
                        >
                          {slot}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Поля завжди видимі — readonly для авторизованих */}
              <input
                type="text"
                placeholder="Ваше ім'я"
                className={s.bookingInput}
                value={guestName}
                onChange={(e) => setGuestName(e.target.value)}
                readOnly={isAuthenticated}
              />
              <input
                type="tel"
                placeholder="Ваш номер"
                className={s.bookingInput}
                value={guestPhone}
                onChange={(e) => setGuestPhone(e.target.value)}
                readOnly={isAuthenticated}
              />

              <label className={s.checkboxLabel}>
                <input
                  type="checkbox"
                  checked={agreed}
                  onChange={(e) => setAgreed(e.target.checked)}
                  className={s.checkbox}
                />
                <span>Згоден на обробку персональних даних</span>
              </label>

              <button
                className={s.bookingBtn}
                onClick={handleQuickBook}
                disabled={bookingLoading}
              >
                {bookingLoading ? "Відправляємо..." : "Відправити"}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* WHY US */}
      <section className={s.sectionWhite}>
        <div className={s.container}>
          <div className={s.sectionHead}>
            <span className={s.sectionBadge}>Наші переваги</span>
            <h2 className={s.sectionTitle}>Чому обирають нас</h2>
          </div>
          <div className={s.gridWhy}>
            {[
              { icon: "👨‍⚕️", title: "Досвідчені лікарі", desc: "Спеціалісти з досвідом понад 10 років" },
              { icon: "🏥", title: "Сучасне обладнання", desc: "Новітні технології діагностики" },
              { icon: "📅", title: "Зручний запис", desc: "Онлайн запис 24/7" },
              { icon: "💊", title: "Комплексне лікування", desc: "Повний спектр медичних послуг" },
            ].map((item) => (
              <div key={item.title} className={s.advantageCard}>
                <div className={s.advantageIcon}>{item.icon}</div>
                <h3 className={s.cardTitle}>{item.title}</h3>
                <p className={s.cardText}>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* REVIEWS */}
      {reviews.length > 0 && (
        <section className={s.sectionGray}>
          <div className={s.container}>
            <div className={s.reviewsHead}>
              <div>
                <span className={s.sectionBadge}>Відгуки пацієнтів</span>
                <h2 className={s.sectionTitle}>Більше ніж просто слова подяки</h2>
              </div>
            </div>

            <div className={s.reviewsSlider}>
              <Swiper
                modules={[Navigation, Pagination]}
                spaceBetween={24}
                slidesPerView={1}
                navigation={{
                  nextEl: ".reviews-next",
                  prevEl: ".reviews-prev",
                }}
                pagination={{ clickable: true }}
                breakpoints={{
                  640: { slidesPerView: 2 },
                  1024: { slidesPerView: 3 },
                }}
                className={s.swiper}
              >
                {reviews.map((review) => (
                  <SwiperSlide key={review.id}>
                    <div className={s.reviewCard}>
                      <div className={s.reviewHeader}>
                        <div>
                          <p className={s.reviewName}>
                            {review.user.firstName} {review.user.lastName}
                          </p>
                          <p className={s.reviewDate}>
                            {new Date(review.createdAt).toLocaleDateString("uk-UA")}
                          </p>
                        </div>
                        <div className={s.reviewRating}>
                          <span className={s.reviewRatingNumber}>{review.rating}</span>
                          <div className={s.reviewStars}>
                            {[1, 2, 3, 4, 5].map((star) => (
                              <span
                                key={star}
                                className={star <= review.rating ? s.starFilled : s.starEmpty}
                              >
                                ★
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>

                      <p className={s.reviewComment}>{review.comment}</p>

                      <div className={s.reviewDoctor}>
                        <span>👨‍⚕️</span>
                        <span>{review.doctor.firstName} {review.doctor.lastName}</span>
                        <span className={s.reviewSpec}>{review.doctor.specialization.name}</span>
                      </div>
                    </div>
                  </SwiperSlide>
                ))}
              </Swiper>

              {/* Стрілки навігації */}
              <div className={s.reviewsNav}>
                <button className={`reviews-prev ${s.navBtn}`}>‹</button>
                <button className={`reviews-next ${s.navBtn}`}>›</button>
              </div>
            </div>

            <div className={s.center}>
              <Link to="/register" className={s.primaryBtnWide}>
                Записатися на прийом
              </Link>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};

export default MainPage;