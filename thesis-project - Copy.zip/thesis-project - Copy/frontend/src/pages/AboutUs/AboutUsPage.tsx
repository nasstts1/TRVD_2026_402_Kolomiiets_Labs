import { Link } from "react-router-dom";
import { useState } from "react";
import { CheckCircle, Clock, Users, Award, Calendar, MessageCircle } from "lucide-react";
import s from "./About.module.scss";

const AboutUsPage = () => {
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  return (
    <div className={s.page}>

      {/* HERO */}
      <section className={s.hero}>
        <div className={s.container}>
          <div className={s.heroGrid}>
            <div className={s.heroContent}>
              <span className={s.badge}>Про клініку</span>
              <h1 className={s.title}>
                Турбота про здоров'я{" "}
                <span className={s.titleAccent}>без стресу</span>{" "}
                і складнощів
              </h1>
              <p className={s.subtitle}>
                Ми поєднуємо сучасну медицину, досвід лікарів і зрозумілий підхід,
                щоб ви отримали допомогу швидко та без зайвих переживань.
              </p>
              <div className={s.heroButtons}>
                <a href="#booking" className={s.primaryBtn}>
                  Записатися на прийом
                </a>
                <Link to="/doctors" className={s.secondaryBtn}>
                  Обрати лікаря →
                </Link>
              </div>
            </div>
            <div className={s.heroVisual}>
              <img src="/hero-section/about-hero.jpg" alt="Клініка" className={s.heroImg} />
            </div>
          </div>
        </div>
      </section>

      {/* WHY US */}
      <section className={s.sectionWhite}>
        <div className={s.container}>
          <div className={s.sectionHead}>
            <div className={s.sectionHeadLeft}>
              <span className={s.sectionBadge}>✦ Наші переваги</span>
              <h2 className={s.sectionTitle}>Чому пацієнти обирають нас</h2>
            </div>
            <p className={s.sectionDesc}>
              Ми думаємо про кожну деталь — від першого запису до завершення лікування
            </p>
          </div>
          <div className={s.grid3}>
            {[
              { title: "Без зайвих кроків", desc: "Запис онлайн за кілька хвилин без дзвінків і черг.", icon: <Clock size={22} /> },
              { title: "Зрозумілою мовою", desc: "Ми пояснюємо діагноз і лікування просто і зрозуміло.", icon: <MessageCircle size={22} /> },
              { title: "Лікарі з досвідом", desc: "Спеціалісти з багаторічною практикою у своїй галузі.", icon: <Users size={22} /> },
              { title: "Сучасна діагностика", desc: "Точні обстеження на новітньому обладнанні.", icon: <CheckCircle size={22} /> },
              { title: "Прозорі ціни", desc: "Жодних прихованих платежів — ви знаєте вартість заздалегідь.", icon: <Award size={22} /> },
              { title: "Турбота після прийому", desc: "Ми залишаємося на зв'язку і супроводжуємо вас.", icon: <Calendar size={22} /> },
            ].map((item, idx) => (
              <div key={idx} className={s.featureCard}>
                <div className={s.featureIcon}>{item.icon}</div>
                <h3 className={s.featureTitle}>{item.title}</h3>
                <p className={s.featureDesc}>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* HOW WE WORK */}
      <section className={s.darkSection}>
        <div className={s.container}>
          <div className={s.darkGrid}>
            <div>
              <span className={s.darkBadge}>Наш підхід</span>
              <h2 className={s.darkTitle}>Як ми працюємо з вашим здоров'ям</h2>
              <p className={s.darkSubtitle}>
                Ми не просто лікуємо симптоми — ми розбираємось у причині проблеми
                і будуємо план лікування разом з пацієнтом.
              </p>
              <div className={s.steps}>
                {[
                  { n: "01", t: "Розуміємо ситуацію", d: "Уважно вислуховуємо пацієнта і збираємо повну картину." },
                  { n: "02", t: "Діагностика", d: "Призначаємо необхідні обстеження на сучасному обладнанні." },
                  { n: "03", t: "Пояснюємо", d: "Розповідаємо про результати простими і зрозумілими словами." },
                  { n: "04", t: "Лікування і контроль", d: "Призначаємо курс і контролюємо результат." },
                ].map((step, i) => (
                  <div key={i} className={s.step}>
                    <span className={s.stepNum}>{step.n}</span>
                    <div>
                      <h4 className={s.stepTitle}>{step.t}</h4>
                      <p className={s.stepDesc}>{step.d}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className={s.darkImgWrap}>
              <img src="/hero-section/about-approach.jpg" alt="" className={s.darkImg} />
            </div>
          </div>
        </div>
      </section>

      {/* STATS */}
      <section className={s.sectionGray}>
        <div className={s.container}>
          <div className={s.statsGrid}>
            {[
              { val: "10+", label: "років досвіду" },
              { val: "15 000+", label: "пацієнтів" },
              { val: "20+", label: "лікарів" },
              { val: "4.9★", label: "середня оцінка" },
            ].map((stat, i) => (
              <div key={i} className={s.statItem}>
                <div className={s.statValue}>{stat.val}</div>
                <div className={s.statLabel}>{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PROCESS */}
      <section className={s.sectionWhite}>
        <div className={s.container}>
          <div className={s.sectionHead}>
            <div className={s.sectionHeadLeft}>
              <span className={s.sectionBadge}>✦ Процес</span>
              <h2 className={s.sectionTitle}>Що вас чекає після запису</h2>
            </div>
          </div>
          <div className={s.processGrid}>
            {[
              { n: "01", t: "Запис", d: "Обираєте лікаря і зручний час онлайн" },
              { n: "02", t: "Підтвердження", d: "Отримуєте лист на пошту з деталями" },
              { n: "03", t: "Прийом", d: "Приходите до клініки або онлайн" },
              { n: "04", t: "Лікування", d: "Отримуєте план і необхідні призначення" },
              { n: "05", t: "Результат", d: "Відстежуєте динаміку разом з лікарем" },
            ].map((step, i) => (
              <div key={i} className={s.processStep}>
                <div className={s.processNum}>{step.n}</div>
                <div>  
                  <h4 className={s.processTitle}>{step.t}</h4>
                  <p className={s.processDesc}>{step.d}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className={s.sectionGray}>
        <div className={s.container}>
          <div className={s.sectionHead}>
            <div className={s.sectionHeadLeft}>
              <span className={s.sectionBadge}>✦ FAQ</span>
              <h2 className={s.sectionTitle}>Поширені запитання</h2>
            </div>
          </div>
          <div className={s.faqList}>
            {[
              { q: "Чи потрібно направлення для запису?", a: "Ні, направлення не потрібне. Ви можете записатись до будь-якого спеціаліста самостійно через сайт." },
              { q: "Як швидко можна потрапити на прийом?", a: "Зазвичай запис доступний вже сьогодні або наступного дня. Точний час залежить від розкладу конкретного лікаря." },
              { q: "Чи можна записатись без реєстрації?", a: "Так, ми надаємо можливість гостьового запису — достатньо вказати ім'я і номер телефону." },
              { q: "Чи приходить підтвердження на пошту?", a: "Так, після запису ви отримаєте email з деталями прийому, а за день до візиту — нагадування." },
            ].map((faq, i) => (
              <div key={i} className={s.faqItem}>
                <button
                  className={s.faqBtn}
                  onClick={() => setActiveFaq(activeFaq === i ? null : i)}
                >
                  <span>{faq.q}</span>
                  <span className={s.faqArrow}>{activeFaq === i ? "−" : "+"}</span>
                </button>
                {activeFaq === i && (
                  <div className={s.faqAnswer}>{faq.a}</div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className={s.ctaSection}>
        <div className={s.container}>
          <div className={s.ctaCard}>
            <h2 className={s.ctaTitle}>Не відкладайте турботу про здоров'я</h2>
            <p className={s.ctaDesc}>Запис займе 2 хвилини — і ваш лікар вже чекає</p>
            <a href="/doctors" className={s.ctaBtn}>Записатися →</a>
          </div>
        </div>
      </section>

    </div>
  );
};

export default AboutUsPage;