import { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import api from "../services/api";
import toast from "react-hot-toast";

type Tab = "info" | "security";

const PatientProfilePage = () => {
  const { user, login } = useAuth();
  const [activeTab, setActiveTab] = useState<Tab>("info");
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({
    firstName: user?.firstName ?? "",
    lastName: user?.lastName ?? "",
    phone: user?.phone ?? "",
  });
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [passwordLoading, setPasswordLoading] = useState(false);

  const handleSave = async () => {
    try {
      const response = await api.patch("/users/me", form);
      login(response.data, localStorage.getItem("token")!);
      setEditing(false);
      toast.success("Профіль оновлено!");
    } catch {
      toast.error("Помилка при збереженні");
    }
  };

  const handlePasswordChange = async () => {
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast.error("Паролі не співпадають");
      return;
    }
    if (passwordForm.newPassword.length < 8) {
      toast.error("Пароль має бути мінімум 8 символів");
      return;
    }
    try {
      setPasswordLoading(true);
      await api.patch("/users/me/password", {
        currentPassword: passwordForm.currentPassword,
        newPassword: passwordForm.newPassword,
      });
      toast.success("Пароль змінено!");
      setPasswordForm({ currentPassword: "", newPassword: "", confirmPassword: "" });
    } catch {
      toast.error("Невірний поточний пароль");
    } finally {
      setPasswordLoading(false);
    }
  };

  const tabs: { key: Tab; label: string; icon: string }[] = [
    { key: "info", label: "Особисті дані", icon: "👤" },
    { key: "security", label: "Безпека", icon: "🔒" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-5xl mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold mb-8">Мій профіль</h1>

        <div className="flex gap-8">
          {/* Бокове меню */}
          <div className="w-64 flex-shrink-0 space-y-2">
            {/* Аватар */}
            <div className="bg-white rounded-2xl p-6 shadow-sm text-center mb-4">
              <div className="w-20 h-20 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-2xl font-bold mx-auto mb-3">
                {user?.firstName[0]}{user?.lastName[0]}
              </div>
              <p className="font-semibold">{user?.firstName} {user?.lastName}</p>
              <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs mt-1 inline-block">
                Пацієнт
              </span>
            </div>

            {/* Вкладки */}
            <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
              {tabs.map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={`w-full flex items-center gap-3 px-4 py-3 text-left text-sm transition ${
                    activeTab === tab.key
                      ? "bg-blue-50 text-blue-600 font-medium border-l-2 border-blue-600"
                      : "text-gray-600 hover:bg-gray-50"
                  }`}
                >
                  <span>{tab.icon}</span>
                  <span>{tab.label}</span>
                </button>
              ))}

              <div className="border-t border-gray-100">
                <Link
                  to="/appointments"
                  className="w-full flex items-center gap-3 px-4 py-3 text-left text-sm text-gray-600 hover:bg-gray-50 transition"
                >
                  <span>📅</span>
                  <span>Мої записи</span>
                </Link>
              </div>
            </div>
          </div>

          {/* Контент */}
          <div className="flex-1">

            {/* Особисті дані */}
            {activeTab === "info" && (
              <div className="bg-white rounded-2xl p-8 shadow-sm">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-bold">Особисті дані</h2>
                  {editing ? (
                    <div className="flex gap-3">
                      <button
                        onClick={handleSave}
                        className="bg-blue-600 text-white px-5 py-2 rounded-lg hover:bg-blue-700 text-sm"
                      >
                        Зберегти
                      </button>
                      <button
                        onClick={() => {
                          setEditing(false);
                          setForm({
                            firstName: user?.firstName ?? "",
                            lastName: user?.lastName ?? "",
                            phone: user?.phone ?? "",
                          });
                        }}
                        className="border border-gray-300 text-gray-600 px-5 py-2 rounded-lg hover:bg-gray-50 text-sm"
                      >
                        Скасувати
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setEditing(true)}
                      className="bg-blue-600 text-white px-5 py-2 rounded-lg hover:bg-blue-700 text-sm"
                    >
                      Редагувати
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Ім'я</label>
                    <input
                      type="text"
                      value={form.firstName}
                      onChange={(e) => setForm({ ...form, firstName: e.target.value })}
                      disabled={!editing}
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 disabled:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Прізвище</label>
                    <input
                      type="text"
                      value={form.lastName}
                      onChange={(e) => setForm({ ...form, lastName: e.target.value })}
                      disabled={!editing}
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 disabled:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Телефон</label>
                    <input
                      type="tel"
                      value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      disabled={!editing}
                      placeholder="+380XXXXXXXXX"
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 disabled:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                    <input
                      type="email"
                      value={user?.email ?? ""}
                      disabled
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 bg-gray-50"
                    />
                    <p className="text-xs text-gray-400 mt-1">Email не можна змінити</p>
                  </div>
                </div>
              </div>
            )}

            {/* Безпека */}
            {activeTab === "security" && (
              <div className="bg-white rounded-2xl p-8 shadow-sm">
                <h2 className="text-xl font-bold mb-6">Зміна паролю</h2>
                <div className="space-y-4 max-w-md">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Поточний пароль
                    </label>
                    <input
                      type="password"
                      value={passwordForm.currentPassword}
                      onChange={(e) => setPasswordForm({ ...passwordForm, currentPassword: e.target.value })}
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Новий пароль
                    </label>
                    <input
                      type="password"
                      value={passwordForm.newPassword}
                      onChange={(e) => setPasswordForm({ ...passwordForm, newPassword: e.target.value })}
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Підтвердження паролю
                    </label>
                    <input
                      type="password"
                      value={passwordForm.confirmPassword}
                      onChange={(e) => setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })}
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <button
                    onClick={handlePasswordChange}
                    disabled={passwordLoading}
                    className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50"
                  >
                    {passwordLoading ? "Збереження..." : "Змінити пароль"}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PatientProfilePage;