import { useState } from "react";
import { useAuth } from "../../context/AuthContext";
import api from "../../services/api";
import toast from "react-hot-toast";
import s from "./AdminProfilePage.module.scss";

const AdminProfilePage = () => {
  const { user, login } = useAuth();
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({
    firstName: user?.firstName ?? "",
    lastName: user?.lastName ?? "",
    email: user?.email ?? "",
  });

  const handleSave = async () => {
    try {
      const response = await api.patch("/users/me", form);
      login(response.data, localStorage.getItem("token")!);
      setEditing(false);
      toast.success("Профіль оновлено!");
    } catch {
      toast.error("Помилка при збереженні");
    }
  };

  return (
    <div className={s.page}>
      <div className={s.header}>
        <h2 className={s.title}>Мій профіль</h2>
        {editing ? (
          <div className={s.headerBtns}>
            <button onClick={handleSave} className={s.saveBtn}>Зберегти</button>
            <button onClick={() => setEditing(false)} className={s.cancelBtn}>Скасувати</button>
          </div>
        ) : (
          <button onClick={() => setEditing(true)} className={s.editBtn}>Редагувати</button>
        )}
      </div>

      <div className={s.card}>
        <div className={s.userInfo}>
          <div className={s.avatar}>
            {user?.firstName[0]}{user?.lastName[0]}
          </div>
          <div>
            <p className={s.userName}>{user?.firstName} {user?.lastName}</p>
            <span className={s.userRole}>Адміністратор</span>
          </div>
        </div>

        <div className={s.formGrid}>
          <div className={s.formGroup}>
            <label className={s.label}>Ім'я</label>
            <input
              type="text"
              value={form.firstName}
              onChange={(e) => setForm({ ...form, firstName: e.target.value })}
              disabled={!editing}
              className={s.input}
            />
          </div>
          <div className={s.formGroup}>
            <label className={s.label}>Прізвище</label>
            <input
              type="text"
              value={form.lastName}
              onChange={(e) => setForm({ ...form, lastName: e.target.value })}
              disabled={!editing}
              className={s.input}
            />
          </div>
          <div className={`${s.formGroup} ${s.formGroupFull}`}>
            <label className={s.label}>Email</label>
            <input
              type="email"
              value={form.email}
              disabled
              className={s.input}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminProfilePage;