import { useEffect, useState } from "react";
import api from "./../services/api";
import type { Appointment } from "./../types";
import ReviewModal from "./../components/ReviewModal/ReviewModal";

const statusLabel: Record<string, { label: string; color: string }> = {
  PENDING: { label: "Очікує", color: "bg-yellow-100 text-yellow-700" },
  CONFIRMED: { label: "Підтверджено", color: "bg-green-100 text-green-700" },
  CANCELLED: { label: "Скасовано", color: "bg-red-100 text-red-700" },
};

const MyAppointmentsPage = () => {
  const [reviewAppointment, setReviewAppointment] = useState<Appointment | null>(null);
  const [reviewedIds, setReviewedIds] = useState<number[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
  api.get("/appointments/my")
    .then((res) => {
      setAppointments(res.data);
      // одразу відмічаємо записи які вже мають відгук
      const alreadyReviewed = res.data
        .filter((a: Appointment) => a.hasReview)
        .map((a: Appointment) => a.id);
      setReviewedIds(alreadyReviewed);
    })
    .catch(() => setAppointments([]))
    .finally(() => setLoading(false));
}, []);

  const handleCancel = async (id: number) => {
    try {
      await api.delete(`/appointments/${id}`);
      setAppointments((prev) => prev.filter((a) => a.id !== id));
    } catch {
      alert("Помилка при скасуванні");
    }
  };

  const isPast = (date: string) => new Date(date) < new Date();

  const upcoming = appointments.filter((a) => !isPast(a.appointmentDate) && a.status !== "CANCELLED");
  const past = appointments.filter((a) => isPast(a.appointmentDate) || a.status === "CANCELLED");

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <p className="text-gray-500">Завантаження...</p>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 py-10">
      <div className="max-w-4xl mx-auto px-4">
        <h1 className="text-3xl font-bold mb-8">Мої записи</h1>

        {appointments.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center shadow-sm">
            <p className="text-4xl mb-4">📅</p>
            <p className="text-gray-500 text-lg">У вас ще немає записів</p>
          </div>
        ) : (
          <>
            {/* Майбутні записи */}
            {upcoming.length > 0 && (
              <div className="mb-10">
                <h2 className="text-xl font-semibold mb-4 text-gray-700">Майбутні записи</h2>
                <div className="space-y-4">
                  {upcoming.map((a) => (
                    <div key={a.id} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                      <div className="flex justify-between items-start">
                        <div className="flex gap-4">
                          <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-sm flex-shrink-0">
                            {a.doctor.firstName[0]}{a.doctor.lastName[0]}
                          </div>
                          <div>
                            <p className="font-semibold text-lg">
                              {a.doctor.firstName} {a.doctor.lastName}
                            </p>
                            {a.doctor.specialization && (
                              <p className="text-blue-600 text-sm">{a.doctor.specialization.name}</p>
                            )}
                            <div className="flex gap-4 mt-2 text-sm text-gray-500">
                              <span>📅 {new Date(a.appointmentDate).toLocaleDateString("uk-UA", { timeZone: "UTC" })}</span>
                              <span>🕐 {new Date(a.appointmentDate).toLocaleTimeString("uk-UA", { hour: "2-digit", minute: "2-digit", timeZone: "UTC" })}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-3">
                          <span className={`px-3 py-1 rounded-full text-sm font-medium ${statusLabel[a.status].color}`}>
                            {statusLabel[a.status].label}
                          </span>
                          {a.status !== "CANCELLED" && (
                            <button
                              onClick={() => handleCancel(a.id)}
                              className="text-red-500 hover:text-red-700 text-sm"
                            >
                              Скасувати
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Минулі записи */}
            {past.length > 0 && (
              <div>
                <h2 className="text-xl font-semibold mb-4 text-gray-700">Історія записів</h2>
                <div className="space-y-4">
                  {past.map((a) => (
                    <div key={a.id} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 opacity-75">
                      <div className="flex justify-between items-start">
                        <div className="flex gap-4">
                          <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center text-gray-500 font-bold text-sm flex-shrink-0">
                            {a.doctor.firstName[0]}{a.doctor.lastName[0]}
                          </div>
                          <div>
                            <p className="font-semibold text-lg">
                              {a.doctor.firstName} {a.doctor.lastName}
                            </p>
                            {a.doctor.specialization && (
                              <p className="text-gray-500 text-sm">{a.doctor.specialization.name}</p>
                            )}
                            <div className="flex gap-4 mt-2 text-sm text-gray-400">
                              <span>📅 {new Date(a.appointmentDate).toLocaleDateString("uk-UA", { timeZone: "UTC" })}</span>
                              <span>🕐 {new Date(a.appointmentDate).toLocaleTimeString("uk-UA", { hour: "2-digit", minute: "2-digit", timeZone: "UTC" })}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-3">
                          <span className={`px-3 py-1 rounded-full text-sm font-medium ${statusLabel[a.status].color}`}>
                            {statusLabel[a.status].label}
                          </span>
                          {/* Кнопка відгуку — додамо пізніше */}
                          {isPast(a.appointmentDate) && a.status !== "CANCELLED" && !reviewedIds.includes(a.id) && (
                            <button
                              onClick={() => setReviewAppointment(a)}
                              className="text-blue-500 hover:text-blue-700 text-sm"
                            >
                              Залишити відгук
                            </button>
                          )}
                          {reviewedIds.includes(a.id) && (
                            <span className="text-green-500 text-sm">✓ Відгук залишено</span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
        {reviewAppointment && (
          <ReviewModal
            appointmentId={reviewAppointment.id}
            doctorName={`${reviewAppointment.doctor.firstName} ${reviewAppointment.doctor.lastName}`}
            onClose={() => setReviewAppointment(null)}
            onSuccess={() => {
              setReviewedIds((prev) => [...prev, reviewAppointment.id]);
              setReviewAppointment(null);
            }}
          />
        )}
      </div>
    </div>
  );
};

export default MyAppointmentsPage;