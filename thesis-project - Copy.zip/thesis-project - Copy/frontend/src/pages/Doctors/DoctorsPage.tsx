import { useEffect, useState } from "react";
import { getDoctors } from "../../services/doctorService";
import { getSpecializations } from "../../services/specializationService";
import type { Specialization } from "../../services/specializationService";
import DoctorCard from "../../components/DoctorCard/DoctorCard";
import type { Doctor } from "../../types";
import s from "./Doctors.module.scss";

const getPageSize = () => window.innerWidth >= 768 ? 12 : 6;

const DoctorsPage = () => {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [specializations, setSpecializations] = useState<Specialization[]>([]);
  const [search, setSearch] = useState("");
  const [selectedSpec, setSelectedSpec] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(getPageSize);

  useEffect(() => {
    Promise.all([getDoctors(), getSpecializations()])
      .then(([docs, specs]) => {
        setDoctors(docs);
        setSpecializations(specs);
      })
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    setCurrentPage(1);
  }, [search, selectedSpec]);

  useEffect(() => {
    const handleResize = () => setPageSize(getPageSize());
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const filtered = doctors.filter((d) => {
    const matchesSearch = `${d.firstName} ${d.lastName}`
      .toLowerCase()
      .includes(search.toLowerCase());
    const matchesSpec = selectedSpec
      ? d.specialization.id === selectedSpec
      : true;
    return matchesSearch && matchesSpec;
  });

  const totalPages = Math.ceil(filtered.length / pageSize);
  const paginated = filtered.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  return (
    <div className={s.page}>

      {/* HEADER */}
      <div className={s.header}>
        <h1 className={s.title}>Лікарі</h1>

        <div className={s.searchWrap}>
          
          {/* SELECT */}
          <select
            value={selectedSpec ?? ""}
            onChange={(e) =>
              setSelectedSpec(e.target.value ? Number(e.target.value) : null)
            }
            className={s.select}
          >
            <option value="">Всі напрямки</option>
            {specializations.map((sItem) => (
              <option key={sItem.id} value={sItem.id}>
                {sItem.name}
              </option>
            ))}
          </select>

          <div className={s.divider} />

          {/* INPUT */}
          <input
            type="text"
            placeholder="Для пошуку почніть вводити прізвище"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className={s.input}
          />

          <span className={s.icon}>🔍</span>
        </div>
      </div>

      {/* CONTENT */}
      <div className={s.container}>
        {loading ? (
          <p className={s.message}>Завантаження...</p>
        ) : filtered.length === 0 ? (
          <p className={s.message}>Лікарів не знайдено</p>
        ) : (
          <>
            <div className={s.grid}>
              {paginated.map((doctor) => (
                <DoctorCard key={doctor.id} doctor={doctor} />
              ))}
            </div>

            {totalPages > 1 && (
              <div className={s.pagination}>
                <button
                  className={s.pageBtn}
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                >
                  ←
                </button>

                {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                  <button
                    key={page}
                    onClick={() => setCurrentPage(page)}
                    className={`${s.pageBtn} ${currentPage === page ? s.pageBtnActive : ""}`}
                  >
                    {page}
                  </button>
                ))}

                <button
                  className={s.pageBtn}
                  onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  disabled={currentPage === totalPages}
                >
                  →
                </button>
              </div>
            )}
          </>
        )}
      </div>

    </div>
  );
};

export default DoctorsPage;