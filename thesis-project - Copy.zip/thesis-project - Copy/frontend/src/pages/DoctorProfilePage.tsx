  import { useState, useEffect } from "react";
  import { useAuth } from "../context/AuthContext";
  import api from "../services/api";
  import toast from "react-hot-toast";
  import ChangePasswordForm from "../components/ChangePasswordForm";
  import DoctorSchedule from "../components/DoctorSchedule";
  

  const tabs = ["Інформація", "Розклад", "Пацієнти", "Безпека"];

  const DoctorProfilePage = () => {
    const { user } = useAuth();
    const [activeTab, setActiveTab] = useState("Інформація");
    const [doctor, setDoctor] = useState<any>(null);
    const [loading, setLoading] = useState(true);
    const [editing, setEditing] = useState(false);
    const [form, setForm] = useState({
      firstName: "",
      lastName: "",
      phone: "",
      email: "",
    });

    useEffect(() => {
      // знаходимо лікаря за email користувача
      api.get("/doctors").then((res) => {
        const found = res.data.find((d: any) => d.email === user?.email);
        if (found) {
          setDoctor(found);
          setForm({
            firstName: found.firstName,
            lastName: found.lastName,
            phone: found.phone ?? "",
            email: found.email,
          });
        }
      }).finally(() => setLoading(false));
    }, [user]);

    const handleSave = async () => {
      try {
        await api.patch(`/doctors/${doctor.id}`, form);
        setDoctor({ ...doctor, ...form });
        setEditing(false);
        toast.success("Профіль оновлено!");
      } catch {
        toast.error("Помилка при збереженні");
      }
    };

    if (loading) return <div className="p-8 text-gray-500">Завантаження...</div>;
    if (!doctor) return <div className="p-8 text-gray-500">Профіль не знайдено</div>;

    return (
      <div className="min-h-screen pt-20  bg-gray-50">
        {/* Верхній блок з аватаркою */}
        <div className="bg-white border-b">
          <div className="max-w-5xl mx-auto px-8 py-8">
            <h1 className="text-2xl font-bold mb-6 pb-2 border-b border-gray-200">
              Профіль лікаря
            </h1>
            <div className="flex items-center gap-6 mb-6">
              {/* Аватарка */}
              <div className="relative">
                <div className="w-20 h-20 rounded-full bg-blue-100 flex items-center justify-center border-2 border-gray-200 text-blue-600 text-2xl font-bold">
                  {doctor.firstName[0]}{doctor.lastName[0]}
                </div>
              </div>
              <div className="flex-1">
                <h2 className="text-xl font-semibold">
                  {doctor.firstName} {doctor.lastName}
                </h2>
                <p className="text-gray-500">{doctor.specialization.name}</p>
              </div>
              <div className="flex gap-3">
                {editing ? (
                  <>
                    <button
                      onClick={handleSave}
                      className="bg-blue-600 text-white px-5 py-2 rounded-lg hover:bg-blue-700"
                    >
                      Зберегти
                    </button>
                    <button
                      onClick={() => setEditing(false)}
                      className="border border-gray-300 text-gray-600 px-5 py-2 rounded-lg hover:bg-gray-50"
                    >
                      Скасувати
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => setEditing(true)}
                    className="bg-blue-600 text-white px-5 py-2 rounded-lg hover:bg-blue-700"
                  >
                    Редагувати
                  </button>
                )}
              </div>
            </div>

            {/* Нижній навбар */}
            <div className="flex gap-8 border-t border-gray-200 pt-4">
              {tabs.map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`pb-2 text-sm font-medium transition border-b-2 ${
                    activeTab === tab
                      ? "border-blue-600 text-blue-600"
                      : "border-transparent text-gray-500 hover:text-gray-700"
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Контент */}
        <div className="max-w-5xl mx-auto px-8 py-8">

          {/* Інформація */}
          {activeTab === "Інформація" && (
            <div className="bg-white rounded-2xl p-8 shadow-sm">
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Ім'я</label>
                  <input
                    type="text"
                    value={form.firstName}
                    onChange={(e) => setForm({ ...form, firstName: e.target.value })}
                    disabled={!editing}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 disabled:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Прізвище</label>
                  <input
                    type="text"
                    value={form.lastName}
                    onChange={(e) => setForm({ ...form, lastName: e.target.value })}
                    disabled={!editing}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 disabled:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                  <input
                    type="email"
                    value={form.email}
                    disabled
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 bg-gray-50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Телефон</label>
                  <input
                    type="text"
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    disabled={!editing}
                    placeholder="+380XXXXXXXXX"
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 disabled:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Спеціалізація</label>
                  <input
                    type="text"
                    value={doctor.specialization.name}
                    disabled
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 bg-gray-50"
                  />
                </div>
              </div>
            </div>
          )}  

          {/* Розклад */}
          {activeTab === "Розклад" && (
              <div className="bg-white rounded-2xl p-8 shadow-sm">
                <DoctorSchedule
                  doctor={doctor}  // ← передаємо весь об'єкт
                  workDays={doctor.workDays}
                  breakStart={doctor.breakStart}
                  breakEnd={doctor.breakEnd}
                />
              </div>
            )}

          {/* Пацієнти */}
          {activeTab === "Пацієнти" && (
            <div className="bg-white rounded-2xl p-8 shadow-sm">
              <p className="text-gray-500">Список пацієнтів — незабаром</p>
            </div>
          )}

          {activeTab === "Безпека" && (
            <div className="bg-white rounded-2xl p-8 shadow-sm">
              <h3 className="text-lg font-semibold mb-6">Зміна паролю</h3>
              <ChangePasswordForm />
            </div>
          )}
        </div>
      </div>
    );
  };

  export default DoctorProfilePage;