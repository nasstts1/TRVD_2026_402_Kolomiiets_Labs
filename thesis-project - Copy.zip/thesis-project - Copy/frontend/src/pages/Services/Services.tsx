import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getServiceCategories } from "../../services/serviceService";
import type { ServiceCategory } from "../../services/serviceService";
import s from "./Services.module.scss";

const ServicesPage = () => {
  const [categories, setCategories] = useState<ServiceCategory[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getServiceCategories()
      .then(setCategories)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className={s.loading}>Завантаження...</div>;

  return (
    <div className={s.page}>
      <section className={s.section}>
        <div className={s.container}>
          <div className={s.head}>
            <span className={s.badge}>Що ми лікуємо</span>
            <h2 className={s.title}>Наші послуги</h2>
            <p className={s.text}>
              Ми надаємо широкий спектр медичних послуг для всієї родини
            </p>
          </div>

          <div className={s.grid}>
            {categories.map((cat) => (
              <Link
                key={cat.id}
                to={`/services/${cat.id}`}
                className={s.card}
              >
                {/* Фото або заглушка */}
                <div className={s.cardImage}>
                  {cat.imageUrl ? (
                    <img src={cat.imageUrl} alt={cat.name} />
                  ) : (
                    <div className={s.cardImagePlaceholder}>🏥</div>
                  )}
                </div>

                <div className={s.cardBody}>
                  <h3 className={s.cardTitle}>{cat.name}</h3>
                  <p className={s.cardText}>
                    {cat.description ?? "Консультація та лікування"}
                  </p>
                  <span className={s.cardLink}>Детальніше →</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default ServicesPage;