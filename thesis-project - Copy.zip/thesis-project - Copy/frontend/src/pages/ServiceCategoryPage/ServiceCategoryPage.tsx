import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getServicesByCategory } from "../../services/serviceService";
import type { Service } from "../../services/serviceService";
import { getDoctors } from "../../services/doctorService";
import type { Doctor } from "../../types";
import DoctorCard from "../../components/DoctorCard/DoctorCard";
import s from "./ServiceCategoryPage.module.scss";

const ServiceCategoryPage = () => {
  const { id } = useParams<{ id: string }>();
  const [services, setServices] = useState<Service[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [openId, setOpenId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    Promise.all([
      getServicesByCategory(Number(id)),
      getDoctors(),
    ]).then(([servs, docs]) => {
      setServices(servs);
      const specIds = servs
        .filter((s) => s.specialization)
        .map((s) => s.specialization!.id);
      if (specIds.length > 0) {
        setDoctors(docs.filter((d) => specIds.includes(d.specialization.id)));
      }
    }).finally(() => setLoading(false));
  }, [id]);

  const categoryName = services[0]?.category?.name ?? "Послуги";

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "CONSULTATION": return "Консультація";
      case "PROCEDURE": return "Процедура";
      case "LABORATORY": return "Аналізи";
      case "CHECKUP": return "Чек-ап";
      default: return type;
    }
  };

  const getTypeClass = (type: string) => {
    switch (type) {
      case "CONSULTATION": return s.typeConsultation;
      case "PROCEDURE": return s.typeProcedure;
      case "LABORATORY": return s.typeLaboratory;
      case "CHECKUP": return s.typeCheckup;
      default: return s.typeDefault;
    }
  };

  if (loading) return <div className={s.loading}>Завантаження...</div>;

  return (
    <div className={s.page}>
      {/* Hero */}
      <div className={s.hero}>
        <div className={s.heroInner}>
          <span className={s.heroBadge}>Наші послуги</span>
          <h1 className={s.heroTitle}>{categoryName}</h1>
        </div>
      </div>

      <div className={s.content}>
        {/* Список послуг */}
        <h2 className={s.sectionTitle}>Перелік послуг</h2>
        <div className={s.servicesList}>
          {services.map((service) => (
            <div key={service.id} className={s.serviceCard}>
              <button
                onClick={() => setOpenId(openId === service.id ? null : service.id)}
                className={s.serviceHeader}
              >
                <div className={s.serviceHeaderLeft}>
                  <span className={`${s.typeBadge} ${getTypeClass(service.serviceType)}`}>
                    {getTypeLabel(service.serviceType)}
                  </span>
                  <span className={s.serviceName}>{service.name}</span>
                </div>
                <div className={s.serviceHeaderRight}>
                  {service.duration && (
                    <span className={s.serviceDuration}>{service.duration} хв</span>
                  )}
                  <span className={s.serviceArrow}>
                    {openId === service.id ? "−" : "+"}
                  </span>
                </div>
              </button>

              {openId === service.id && (
                <div className={s.serviceBody}>
                  <div className={s.serviceBodyInner}>
                    {service.imageUrl && (
                      <img src={service.imageUrl} alt={service.name} className={s.serviceImg} />
                    )}
                    <div className={s.serviceInfo}>
                      <p className={s.serviceDesc}>
                        {service.description ?? "Детальна інформація про послугу"}
                      </p>
                      <div className={s.serviceMeta}>
                        {service.price && <span>💰 Ціна: від {service.price} грн</span>}
                        {service.duration && <span>⏱ Тривалість: {service.duration} хв</span>}
                        {service.specialization && <span>🏥 {service.specialization.name}</span>}
                      </div>
                      {service.requiresBooking ? (
                        <button className={s.bookBtn}>Записатись</button>
                      ) : (
                        <button className={s.leaveBtn}>Залишити заявку</button>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Лікарі */}
        {doctors.length > 0 && (
          <div>
            <h2 className={s.sectionTitle}>Лікарі напрямку</h2>
            <div className={s.doctorsGrid}>
              {doctors.map((doctor) => (
                <DoctorCard key={doctor.id} doctor={doctor} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ServiceCategoryPage;