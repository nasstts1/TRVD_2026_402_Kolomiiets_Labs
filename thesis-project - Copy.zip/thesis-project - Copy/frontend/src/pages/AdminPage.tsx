import { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { useNavigate, Link } from "react-router-dom";
import DoctorsTable from "../components/admin/DoctorsTable";
import UsersTable from "../components/admin/UsersTable";
import AppointmentsTable from "../components/admin/AppointmentsTable";
import SpecializationsTable from "../components/admin/SpecializationsTable";
import DoctorProfilePage from "./DoctorProfilePage";


const AdminPage = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("doctors");

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Бокове меню */}
      <div className="w-64 bg-gray-900 text-white flex flex-col">
        <div className="p-6">
          <h1 className="text-2xl font-bold">
            {user?.role === "ADMIN" ? "Admin" : "Лікар"}
          </h1>
        </div>

        <nav className="flex-1 px-4 space-y-2">
          {user?.role === "ADMIN" && (
            <>
              <button
                onClick={() => setActiveTab("doctors")}
                className={`w-full text-left px-4 py-3 rounded-lg ${activeTab === "doctors" ? "bg-blue-600" : "hover:bg-gray-800"}`}
              >
                Лікарі
              </button>
              <button
                onClick={() => setActiveTab("users")}
                className={`w-full text-left px-4 py-3 rounded-lg ${activeTab === "users" ? "bg-blue-600" : "hover:bg-gray-800"}`}
              >
                Користувачі
              </button>
              <button
                onClick={() => setActiveTab("appointments")}
                className={`w-full text-left px-4 py-3 rounded-lg ${activeTab === "appointments" ? "bg-blue-600" : "hover:bg-gray-800"}`}
              >
                Записи
              </button>
              <button
                onClick={() => setActiveTab("specializations")}
                className={`w-full text-left px-4 py-3 rounded-lg ${activeTab === "specializations" ? "bg-blue-600" : "hover:bg-gray-800"}`}
              >
                Спеціалізації
              </button>
            </>
          )}

          {user?.role === "DOCTOR" && (
            <>
              <button
                onClick={() => setActiveTab("profile")}
                className={`w-full text-left px-4 py-3 rounded-lg ${activeTab === "profile" ? "bg-blue-600" : "hover:bg-gray-800"}`}
              >
                Мій профіль
              </button>
              <button
                onClick={() => setActiveTab("appointments")}
                className={`w-full text-left px-4 py-3 rounded-lg ${activeTab === "appointments" ? "bg-blue-600" : "hover:bg-gray-800"}`}
              >
                Мої записи
              </button>
            </>
          )}
        </nav>

        <div className="p-4 border-t border-gray-700 space-y-2">
          <p className="text-sm text-gray-400">{user?.firstName} {user?.lastName}</p>
          <Link
            to="/doctors"
            className="w-full text-left px-4 py-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg flex items-center gap-2"
          >
            ← На сайт
          </Link>
          <button
            onClick={handleLogout}
            className="w-full text-left px-4 py-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg"
          >
            Вийти
          </button>
        </div>
      </div>

      {/* Основний контент */}
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          <h2 className="text-3xl font-bold mb-6">
            Привіт, {user?.firstName}! 👋
          </h2>
          <div className="bg-white rounded-2xl p-6 shadow-sm">
            {activeTab === "doctors" && <DoctorsTable />}
            {activeTab === "users" && <UsersTable />}
            {activeTab === "appointments" && <AppointmentsTable />}
            {activeTab === "specializations" && <SpecializationsTable />}
            {activeTab === "profile" && <DoctorProfilePage />}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminPage;