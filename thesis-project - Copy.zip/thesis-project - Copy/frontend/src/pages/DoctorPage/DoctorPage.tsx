import { useEffect, useState, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "../../services/api";
import type { Doctor } from "../../types";
import { useAuth } from "../../context/AuthContext";
import toast from "react-hot-toast";
import s from "./DoctorPage.module.scss";

const DoctorPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAuth();
  const [doctor, setDoctor] = useState<Doctor | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"info" | "reviews">("info");
  const bookingRef = useRef<HTMLDivElement>(null);

  const scrollToBooking = () => {
    bookingRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  // Форма запису
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [bookedSlots, setBookedSlots] = useState<string[]>([]);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [doctorBreak, setDoctorBreak] = useState({ start: "13:00", end: "14:00" });
  const [guestName, setGuestName] = useState(() => user ? `${user.firstName} ${user.lastName}` : "");
  const [guestPhone, setGuestPhone] = useState(() => user?.phone || "");
  const [agreed, setAgreed] = useState(false);
  const [bookingLoading, setBookingLoading] = useState(false);

    // Скрол на початок при завантаженні
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    if (!id) return;
    api.get(`/doctors/${id}`)
      .then((res) => {
        setDoctor(res.data);
        setDoctorBreak({
          start: res.data.breakStart || "13:00",
          end: res.data.breakEnd || "14:00",
        });
      })
      .catch(() => navigate("/doctors"))
      .finally(() => setLoading(false));
  }, [id]);

  useEffect(() => {
    if (!id || !selectedDate) return;
    setSlotsLoading(true);
    api.get(`/appointments/booked?doctorId=${id}&date=${selectedDate}`)
      .then((res) => setBookedSlots(res.data))
      .catch(() => setBookedSlots([]))
      .finally(() => setSlotsLoading(false));
  }, [id, selectedDate]);

  const generateSlots = (breakStart: string, breakEnd: string) => {
    const slots = [];
    let hour = 9, minute = 0;
    while (hour < 18) {
      const time = `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
      slots.push(time);
      minute += 30;
      if (minute >= 60) { minute = 0; hour++; }
    }
    return slots.filter((slot) => slot < breakStart || slot >= breakEnd);
  };

  const availableSlots = generateSlots(doctorBreak.start, doctorBreak.end)
    .filter((slot) => !bookedSlots.includes(slot));

  const handleBook = async () => {
    if (!selectedDate || !selectedTime) {
      toast.error("Оберіть дату та час");
      return;
    }
    if (!agreed) {
      toast.error("Підтвердіть згоду на обробку даних");
      return;
    }
    if (!isAuthenticated && (!guestName.trim() || !guestPhone.trim())) {
      toast.error("Заповніть ім'я та телефон");
      return;
    }

    try {
      setBookingLoading(true);
      const appointmentDate = `${selectedDate}T${selectedTime}:00.000Z`;

      if (isAuthenticated) {
        await api.post("/appointments", {
          doctorId: Number(id),
          appointmentDate,
        });
      } else {
        await api.post("/appointments/guest", {
          doctorId: Number(id),
          appointmentDate,
          guestName: guestName.trim(),
          guestPhone: guestPhone.trim(),
        });
      }

      toast.success("Запис успішно створено!");
      setSelectedDate("");
      setSelectedTime(null);
      setAgreed(false);
      setBookedSlots([]);
      if (!isAuthenticated) {
        setGuestName("");
        setGuestPhone("");
      }
    } catch {
      toast.error("Помилка. Спробуйте ще раз");
    } finally {
      setBookingLoading(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <p className="text-gray-500">Завантаження...</p>
    </div>
  );

  if (!doctor) return null;

  const educationList = (doctor.education ?? []).filter((e) => e.type === "EDUCATION");
  const trainingList = (doctor.education ?? []).filter((e) => e.type === "TRAINING");
  const visibleReviews = (doctor.reviews ?? []).filter((r) => r.isVisible);
  const avgRating = visibleReviews.length
    ? (visibleReviews.reduce((sum, r) => sum + r.rating, 0) / visibleReviews.length).toFixed(1)
    : null;

  

  return (
  <div className={s.page}>
    {/* Hero */}
    <div className={s.hero}>
      <div className={s.heroInner}>
        <div className={s.heroTop}>
          {/* Фото */}
          <div className={s.photo}>
            {doctor.photoUrl ? (
              <img src={doctor.photoUrl} alt="" />
            ) : (
              `${doctor.firstName[0]}${doctor.lastName[0]}`
            )}
          </div>

          {/* Інфо */}
          <div className={s.info}>
            <div className={s.badges}>
              <span className={s.badge}>{doctor.specialization.name}</span>
              {doctor.category && (
                <span className={s.badgeGray}>{doctor.category}</span>
              )}
            </div>

            <h1 className={s.name}>
              {doctor.firstName} {doctor.lastName}
            </h1>

            <div className={s.meta}>
              {doctor.experience && (
                <span> Досвід: <strong>{doctor.experience} років</strong></span>
              )}
              {avgRating && (
                <span> Рейтинг: <strong>{avgRating}</strong> ({visibleReviews.length} відгуків)</span>
              )}
              {doctor.phone && (
                <strong>{doctor.phone}</strong>
              )}
            </div>

            {doctor.bio && <p className={s.bio}>{doctor.bio}</p>}
          </div>

          <button onClick={scrollToBooking} className={s.bookBtn}>
            Записатись
          </button>
        </div>

        {/* Вкладки */}
        <div className={s.tabs}>
          {[
            { key: "info", label: "Про лікаря" },
            { key: "reviews", label: `Відгуки${visibleReviews.length > 0 ? ` (${visibleReviews.length})` : ""}` },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key as any)}
              className={`${s.tab} ${activeTab === tab.key ? s.tabActive : ""}`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>
    </div>

    {/* Контент */}
    <div className={s.content}>

      {/* Про лікаря */}
      {activeTab === "info" && (
        <>
          {educationList.length > 0 && (
            <div className={s.card}>
              <h2 className={s.cardTitle}>Освіта</h2>
              <ul className={s.eduList}>
                {educationList.map((e) => (
                  <li key={e.id} className={s.eduItem}>
                    <span className={s.eduIcon}>🎓</span>
                    <div>
                      <p className={s.eduName}>{e.institution}</p>
                      {e.degree && <p className={s.eduDegree}>{e.degree}</p>}
                      {e.year && <p className={s.eduYear}>{e.year} р.</p>}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {trainingList.length > 0 && (
            <div className={s.card}>
              <h2 className={s.cardTitle}>Тренінги та курси</h2>
              <ul className={s.eduList}>
                {trainingList.map((e) => (
                  <li key={e.id} className={s.eduItem}>
                    <span className={s.eduIcon}>📋</span>
                    <div>
                      <p className={s.eduName}>{e.institution}</p>
                      {e.degree && <p className={s.eduDegree}>{e.degree}</p>}
                      {e.year && <p className={s.eduYear}>{e.year} р.</p>}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {educationList.length === 0 && trainingList.length === 0 && (
            <div className={`${s.card} ${s.emptyState}`}>
              Інформація про освіту ще не додана
            </div>
          )}
        </>
      )}

      {/* Відгуки */}
      {activeTab === "reviews" && (
        <>
          {visibleReviews.length === 0 ? (
            <div className={s.emptyState}>
              <p className={s.emptyIcon}>💬</p>
              <p>Відгуків ще немає</p>
            </div>
          ) : (
            visibleReviews.map((review) => (
              <div key={review.id} className={s.reviewCard}>
                <div className={s.reviewTop}>
                  <div className={s.reviewUser}>
                    <div className={s.reviewAvatar}>
                      {review.user.firstName[0]}{review.user.lastName[0]}
                    </div>
                    <div>
                      <p className={s.reviewName}>{review.user.firstName} {review.user.lastName}</p>
                      <p className={s.reviewDate}>{new Date(review.createdAt).toLocaleDateString("uk-UA")}</p>
                    </div>
                  </div>
                  <div className={s.reviewStars}>
                    {[1,2,3,4,5].map((star) => (
                      <span key={star} className={star <= review.rating ? s.starFilled : s.starEmpty}>★</span>
                    ))}
                  </div>
                </div>
                <p className={s.reviewComment}>{review.comment}</p>
              </div>
            ))
          )}
        </>
      )}

      {/* Форма запису */}
      <div ref={bookingRef} className={s.bookingCard}>
        <div className={s.bookingLeft}>
          <h2 className={s.bookingTitle}>Записатись до лікаря</h2>
          <p className={s.bookingSubtitle}>
            Залиште свої контактні дані і адміністратор зв'яжеться з вами протягом 30 хвилин
          </p>
          <div className={s.bookingDoctorCard}>
            <p className={s.bookingDoctorName}>{doctor.firstName} {doctor.lastName}</p>
            <p className={s.bookingDoctorSpec}>{doctor.specialization.name}</p>
          </div>
        </div>

        <div className={s.bookingRight}>
          <input
            type="date"
            className={s.bookingInput}
            value={selectedDate}
            min={new Date().toISOString().split("T")[0]}
            onChange={(e) => { setSelectedDate(e.target.value); setSelectedTime(null); }}
          />

          {selectedDate && (
            <div>
              {slotsLoading ? (
                <p className={s.slotsMsg}>Завантаження...</p>
              ) : availableSlots.length === 0 ? (
                <p className={s.slotsMsg}>Немає вільних слотів на цей день</p>
              ) : (
                <div className={s.slots}>
                  {availableSlots.map((slot) => (
                    <button
                      key={slot}
                      type="button"
                      onClick={() => setSelectedTime(slot)}
                      className={`${s.slot} ${selectedTime === slot ? s.slotActive : ""}`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          <input type="text" placeholder="Ваше ім'я" className={s.bookingInput}
            value={guestName} onChange={(e) => setGuestName(e.target.value)} readOnly={isAuthenticated} />
          <input type="tel" placeholder="Ваш номер" className={s.bookingInput}
            value={guestPhone} onChange={(e) => setGuestPhone(e.target.value)} readOnly={isAuthenticated} />

          <label className={s.checkboxLabel}>
            <input type="checkbox" checked={agreed} onChange={(e) => setAgreed(e.target.checked)} className={s.checkbox} />
            <span>Згоден на обробку персональних даних</span>
          </label>

          <button onClick={handleBook} disabled={bookingLoading} className={s.bookingBtn}>
            {bookingLoading ? "Відправляємо..." : "Записатись"}
          </button>
        </div>
      </div>
    </div>
  </div>
);
};

export default DoctorPage;