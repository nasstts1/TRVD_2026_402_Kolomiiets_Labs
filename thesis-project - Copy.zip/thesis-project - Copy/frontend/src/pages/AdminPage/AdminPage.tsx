import { useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { useNavigate, Link } from "react-router-dom";
import DoctorsTable from "../../components/admin/DoctorsTable";
import UsersTable from "../../components/admin/UsersTable";
import AppointmentsTable from "../../components/admin/AppointmentsTable";
import SpecializationsTable from "../../components/admin/SpecializationsTable";
import DoctorProfilePage from "./..//DoctorProfilePage";
import AdminProfilePage from "../AdminProfilePage/AdminProfilePage";
import DoctorAppointmentsTable from "../../components/admin/DoctorAppointmentsTable";
import ServiceCategoriesTable from "../../components/admin/ServiceCategoriesTable";
import ServicesTable from "../../components/admin/ServicesTable";
import ReviewsTable from "../../components/admin/ReviewsTable";
import AnalyticsDashboard from "../../components/admin/AnalyticsDashboard";
import s from "./AdminPage.module.scss";

const AdminPage = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState(
    user?.role === "DOCTOR" ? "profile" : "analytics"
  );
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    setSidebarOpen(false);
  };

  const adminTabs = [
    { key: "analytics", label: "Аналітика" },
    { key: "doctors", label: "Лікарі" },
    { key: "users", label: "Користувачі" },
    { key: "appointments", label: "Записи" },
    { key: "serviceCategories", label: "Категорії послуг" },
    { key: "services", label: "Послуги" },
    { key: "specializations", label: "Спеціалізації" },
    { key: "reviews", label: "Відгуки" },
    { key: "profile", label: "Мій профіль" },
  ];

  const doctorTabs = [
    { key: "profile", label: "Мій профіль" },
    { key: "appointments", label: "Мої записи" },
  ];

  const tabs = user?.role === "ADMIN" ? adminTabs : doctorTabs;

  const getTitle = () => {
    return tabs.find(t => t.key === activeTab)?.label ?? "Панель";
  };

  return (
    <div className={s.layout}>
      {/* Overlay для мобільного */}
      {sidebarOpen && (
        <div className={s.overlay} onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`${s.sidebar} ${sidebarOpen ? s.sidebarOpen : ""}`}>
        <div className={s.sidebarHead}>
          <p className={s.sidebarTitle}>
            {user?.role === "ADMIN" ? "Admin Panel" : "Кабінет лікаря"}
          </p>
        </div>

        <nav className={s.nav}>
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => handleTabChange(tab.key)}
              className={`${s.navBtn} ${activeTab === tab.key ? s.navBtnActive : ""}`}
            >
              {tab.label}
            </button>
          ))}
        </nav>

        <div className={s.sidebarFooter}>
          <p className={s.sidebarUser}>{user?.firstName} {user?.lastName}</p>
          <Link to="/doctors" className={s.sidebarLink}>
            ← На сайт
          </Link>
          <button onClick={handleLogout} className={s.sidebarLogout}>
            Вийти
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className={s.main}>
        {/* Topbar — тільки мобільний */}
        <div className={s.topbar}>
          <button
            className={s.burgerBtn}
            onClick={() => setSidebarOpen(true)}
          >
            <span className={s.burgerLine} />
            <span className={s.burgerLine} />
            <span className={s.burgerLine} />
          </button>
          <span className={s.topbarTitle}>{getTitle()}</span>
          <div style={{ width: 40 }} />
        </div>

        <div className={s.content}>
          <h2 className={s.contentTitle}>
            Привіт, {user?.firstName}!
          </h2>
          <div className={s.contentCard}>
            {activeTab === "doctors" && user?.role === "ADMIN" && <DoctorsTable />}
            {activeTab === "users" && user?.role === "ADMIN" && <UsersTable />}
            {activeTab === "specializations" && user?.role === "ADMIN" && <SpecializationsTable />}
            {activeTab === "appointments" && user?.role === "ADMIN" && <AppointmentsTable />}
            {activeTab === "appointments" && user?.role === "DOCTOR" && <DoctorAppointmentsTable />}
            {activeTab === "profile" && user?.role === "ADMIN" && <AdminProfilePage />}
            {activeTab === "profile" && user?.role === "DOCTOR" && <DoctorProfilePage />}
            {activeTab === "serviceCategories" && <ServiceCategoriesTable />}
            {activeTab === "services" && <ServicesTable />}
            {activeTab === "reviews" && user?.role === "ADMIN" && <ReviewsTable />}
            {activeTab === "analytics" && user?.role === "ADMIN" && <AnalyticsDashboard />}
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminPage;